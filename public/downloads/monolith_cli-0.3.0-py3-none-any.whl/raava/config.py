"""Configuration management for the Monolith CLI."""

import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "monolith"
CONFIG_FILE = CONFIG_DIR / "config.toml"

VALID_KEYS = {"api_url", "timeout", "output", "api_key"}

_defaults = {
    "api_url": "http://ubuntu-server.local:8400",
    "timeout": 30,
    "output": "table",
    "api_key": "",
}


def _load_config() -> dict:
    if not CONFIG_FILE.exists():
        return dict(_defaults)
    try:
        import tomllib
        with open(CONFIG_FILE, "rb") as f:
            data = tomllib.load(f)
        merged = dict(_defaults)
        merged.update(data)
        return merged
    except Exception:
        return dict(_defaults)


def _save_config(data: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        CONFIG_DIR.chmod(0o700)
    except OSError:
        pass
    lines = []
    for k, v in data.items():
        # bool must be checked before int (bool is subclass of int)
        if isinstance(v, bool):
            lines.append(f"{k} = {'true' if v else 'false'}")
        elif isinstance(v, int):
            lines.append(f"{k} = {v}")
        elif isinstance(v, float):
            lines.append(f"{k} = {v}")
        elif isinstance(v, str):
            # Escape backslashes and quotes for valid TOML
            escaped = v.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k} = "{escaped}"')
        else:
            lines.append(f'{k} = "{v}"')
    CONFIG_FILE.write_text("\n".join(lines) + "\n")
    try:
        CONFIG_FILE.chmod(0o600)
    except OSError:
        pass


_config = _load_config()


def get(key: str, default=None):
    env_key = f"RAAVA_{key.upper()}"
    env_val = os.environ.get(env_key)
    if env_val is not None:
        return env_val
    return _config.get(key, default)


def set_value(key: str, value: str):
    # Type coercion
    if value.lower() in ("true", "false"):
        value = value.lower() == "true"
    else:
        try:
            value = int(value)
        except ValueError:
            try:
                value = float(value)
            except ValueError:
                pass
    _config[key] = value
    _save_config(_config)


def delete_key(key: str) -> bool:
    if key in _config and key not in _defaults:
        del _config[key]
        _save_config(_config)
        return True
    elif key in _config:
        _config[key] = _defaults[key]
        _save_config(_config)
        return True
    return False


def all_config() -> dict:
    return dict(_config)
