"""Monolith Fleet CLI — manage LXC containers and AI agents."""

import sys

import httpx
import typer

from raava import display
from raava.client import APIError

__version__ = "0.3.0"

app = typer.Typer(
    name="monolith",
    help="Monolith Fleet CLI — manage containers, agents, and infrastructure.",
    no_args_is_help=False,
    rich_markup_mode="rich",
    context_settings={"help_option_names": ["--help", "-h"]},
)


def _run_app(args: list[str] | None = None):
    return app(prog_name="monolith", args=args, standalone_mode=False)


def _stdin_is_interactive() -> bool:
    stream = getattr(sys, "stdin", None)
    return bool(stream and stream.isatty())


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    json_output: bool = typer.Option(False, "--json", "-j", help="Output raw JSON"),
    api_url: str | None = typer.Option(
        None,
        "--api-url",
        envvar=["MONOLITH_API_URL", "RAAVA_API_URL"],
        help="API base URL override",
    ),
    timeout: int | None = typer.Option(
        None, "--timeout", help="Request timeout in seconds"
    ),
    version: bool = typer.Option(
        False, "--version", "-V", help="Show version and exit"
    ),
):
    if version:
        typer.echo(f"monolith {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        if json_output or not _stdin_is_interactive():
            typer.echo(ctx.get_help())
            raise typer.Exit()
        if api_url is not None:
            from raava import config

            config._config["api_url"] = api_url
        if timeout is not None:
            from raava import config

            config._config["timeout"] = timeout
        from raava.repl import run_repl

        run_repl(app, version=__version__)
        raise typer.Exit()
    if json_output:
        display.set_json_mode(True)
    if api_url is not None:
        from raava import config

        config._config["api_url"] = api_url
    if timeout is not None:
        from raava import config

        config._config["timeout"] = timeout


# Register command groups
from raava.commands import (
    agent,
    cfg,
    chat,
    containers,
    deploy,
    doctor,
    files,
    fleet,
    git,
    health,
    hermes,
    logs_cmd,
    manifest,
    messaging,
    metrics,
    migrations,
    provision,
    reconcile,
    runtime,
    services,
    sessions,
    snapshots,
    status,
    stream,
    system,
    tenants,
    init,
    wizard,
)

app.add_typer(fleet.app, name="fleet", help="Fleet-wide health, alerts, stats, audit")
app.add_typer(containers.app, name="containers", help="Container lifecycle management")
app.add_typer(agent.app, name="agent", help="Agent process inside a container")
app.add_typer(health.app, name="health", help="Container health metrics")
app.add_typer(snapshots.app, name="snapshots", help="LXD snapshot management")
app.add_typer(files.app, name="files", help="File operations inside containers")
app.add_typer(git.app, name="git", help="Git operations inside containers")
app.add_typer(provision.app, name="provision", help="Template-based agent provisioning")
app.add_typer(sessions.app, name="sessions", help="WebSocket terminal sessions")
app.add_typer(tenants.app, name="tenants", help="Tenant and business unit management")
app.add_typer(metrics.app, name="metrics", help="Token usage and utilization metrics")
app.add_typer(system.app, name="system", help="Container system introspection")
app.add_typer(stream.app, name="stream", help="Real-time SSE streams")
app.add_typer(cfg.app, name="config", help="CLI configuration")
app.add_typer(
    chat.app, name="chat", help="Chat with the fleet agent (interactive or one-shot)"
)
app.add_typer(doctor.app, name="doctor", help="Stack-aware diagnostic checks")
app.add_typer(reconcile.app, name="reconcile", help="DB/provider state reconciliation")
app.add_typer(runtime.app, name="runtime", help="Runtime config updates")
app.add_typer(services.app, name="services", help="Stack-aware service operations")
app.add_typer(messaging.app, name="messaging", help="Messaging integrations")
app.add_typer(
    migrations.app, name="migrations", help="Hermes/OpenClaw migration workflows"
)
app.add_typer(hermes.app, name="hermes", help="Hermes maintenance operations")
app.add_typer(manifest.app, name="manifest", help="Agent manifest management")
app.command("deploy", help="Deploy a fleet by provisioning N agents.")(deploy.deploy)
app.command("status", help="Show concise fleet-wide agent status.")(status.status)
app.command("logs", help="Fetch log output for a named agent.")(logs_cmd.logs)

# Wire `monolith agent init` as a subcommand of the existing `agent` group.
agent.app.add_typer(init.app, name="init", help="Interactive wizard to configure Hermes on a container")

# Wire `monolith agent create --wizard` directly as a command on the agent group.
# We import the function and register it directly so the invocation is
# `monolith agent create --wizard` (not a nested sub-group).
agent.app.command("create", help="Create a new agent (use --wizard for interactive setup)")(wizard.create)


def cli():
    """Entry point with global error handling."""
    try:
        _run_app()
    except APIError as e:
        display.print_error(f"API error (HTTP {e.status}): {e.detail}")
        raise SystemExit(1)
    except httpx.ConnectError:
        display.print_error("Cannot connect to the Monolith API. Is the server running?")
        raise SystemExit(1)
    except httpx.TimeoutException:
        display.print_error(
            "Request timed out. Try increasing --timeout or check server status."
        )
        raise SystemExit(1)
    except httpx.HTTPError as e:
        display.print_error(f"HTTP error: {e}")
        raise SystemExit(1)
