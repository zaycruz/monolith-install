"""Agent-first CLI and MCP contract helpers."""

from __future__ import annotations

import copy
from typing import Any


CONTRACT_VERSION = "agent-cli-contract/v1"

_INVESTIGATION_TOOLS = [
    "target_resolve",
    "messaging_discord_config",
    "config_inventory",
    "hermes_config_inventory",
    "hermes_skill_enablement",
    "hermes_plugin_inventory",
    "cron_job_inventory",
    "incident_bundle",
    "metrics_cloud_snapshot",
    "metrics_vm_snapshot",
    "metrics_runtime_snapshot",
    "metrics_agent_rca_bundle",
]

_WORKFLOWS: dict[str, dict[str, Any]] = {
    "orient": {
        "intent": "orient",
        "summary": "Discover fleet state before choosing any mutation path.",
        "tools": [
            "agent_contract",
            "fleet_summary",
            "fleet_health_compact",
            "fleet_agents_compact",
            "drift_scan",
        ],
        "cli": [
            "monolith agentic contract",
            "monolith --json status",
            "monolith --json fleet health",
        ],
        "required_before_write": [],
    },
    "triage": {
        "intent": "triage",
        "summary": "Diagnose an unhealthy agent with compact context first.",
        "tools": [
            "triage_agent",
            "metrics_agent_rca_bundle",
            "container_view",
            "agent_logs_compact",
            "container_health",
            "metrics_vm_snapshot",
            "metrics_runtime_snapshot",
            "fleet_audit",
        ],
        "cli": [
            "monolith agentic workflows triage --format toon",
            "monolith --json agent status <container_id>",
            "monolith --json agent logs <container_id>",
        ],
        "required_before_write": ["operator intent", "target container_id"],
    },
    "staged_write": {
        "intent": "staged_write",
        "summary": "Use proposal-first tools and API-owned Fleet Manager execution.",
        "tools": [
            "policy_diff",
            "rollback_plan",
            "staging_gate",
            "fleet_manager_action_create",
            "fleet_manager_action_approve",
            "fleet_manager_action_execute",
        ],
        "cli": [
            "monolith agentic workflows staged_write --format toon",
            "monolith --json harness diff-proposal ...",
        ],
        "required_before_write": [
            "tenant_id",
            "environment",
            "target_kind",
            "target_id",
            "policy_diff",
            "rollback_plan",
            "verification_plan",
            "staging_evidence for production",
        ],
    },
    "provision": {
        "intent": "provision",
        "summary": "Queue approved provisioning through the durable Fleet Manager path.",
        "tools": [
            "proposal_provision_start",
            "fleet_manager_action_create",
            "fleet_manager_action_approve",
            "fleet_manager_action_execute",
            "provision_status",
            "provision_worker_run_once",
        ],
        "cli": [
            "monolith agentic workflows provision --format toon",
            "monolith --json provision status <job_id>",
            "monolith --json provision worker-run-once --job-id <job_id>",
        ],
        "required_before_write": [
            "tenant_id",
            "environment",
            "template",
            "agent_name",
            "agent_role",
            "owner_approval for high risk",
            "stop_conditions for high risk",
        ],
    },
    "hermes_ops": {
        "intent": "hermes_ops",
        "summary": "Inspect Hermes runtime wiring before diagnosing messaging or skill behavior.",
        "tools": [
            "target_resolve",
            "config_inventory",
            "messaging_discord_config",
            "system_env",
            "system_connections",
            "files_list",
            "file_read",
            "agent_logs_compact",
            "fleet_audit",
        ],
        "cli": [
            "monolith agentic workflows hermes_ops --format toon",
            "monolith --json messaging discord <container_id>",
            "monolith --json system env <container_id>",
            "monolith --json system connections <container_id>",
        ],
        "required_before_write": [
            "exact container_id",
            "tenant_id",
            "current Hermes config snapshot",
            "current messaging gateway config snapshot",
            "skill/plugin enablement snapshot",
            "cron/job schedule snapshot",
            "operator intent for config mutation",
        ],
    },
}

_OPERATIONAL_GAPS = [
    {
        "capability": "target_resolve",
        "summary": "Resolve tenant, runtime, aliases, and offboarded/deleted state without guessing.",
        "needs": [
            "Exact-by-default lookup for container IDs and names.",
            "Ambiguity set when a name matches multiple runtimes.",
            "Tenant status included with every target resolution.",
        ],
        "owner": "cli_mcp",
    },
    {
        "capability": "config_inventory",
        "summary": "Aggregate runtime config, env, messaging, manifests, and redacted secret presence.",
        "needs": [
            "Hermes env/config files and runtime config in one response.",
            "Discord, Telegram, Gmail, Slack, and future channel config slots.",
            "Config source/provenance when the API exposes it.",
        ],
        "owner": "cli_mcp_plus_api_provenance",
    },
    {
        "capability": "hermes_config_inventory",
        "summary": "Expose Hermes-specific operator state without requiring raw file spelunking.",
        "needs": [
            "Runtime identity, mode, model/provider, workspace, memory paths, and data dirs.",
            "Gateway toggles, channel bindings, allowed users, mention policy, and home channels.",
            "Agent prompt/profile paths, active system instruction source, and loaded env overlays.",
            "Last config reload/restart timestamps and effective-vs-pending diff.",
        ],
        "owner": "cli_mcp",
    },
    {
        "capability": "hermes_skill_enablement",
        "summary": "Show which Hermes skills are installed, enabled, disabled, shadowed, or failing load.",
        "needs": [
            "Installed skill inventory with source path, version/hash, enabled state, and load errors.",
            "Per-skill required secrets/env vars as presence-only redacted checks.",
            "Skill routing triggers and conflict/shadowing diagnostics.",
        ],
        "owner": "cli_mcp_plus_api_if_not_exposed",
    },
    {
        "capability": "hermes_plugin_inventory",
        "summary": "Show plugin and connector availability for a runtime.",
        "needs": [
            "Installed plugins, enabled connectors, auth state, and unavailable/misconfigured connectors.",
            "MCP servers or app connectors exposed to Hermes with transport and health status.",
            "Plugin capability map so agents know whether to use native tools, MCP, or CLI fallback.",
        ],
        "owner": "cli_mcp_plus_api_if_not_exposed",
    },
    {
        "capability": "cron_job_inventory",
        "summary": "Expose scheduled jobs that can explain surprise messages, restarts, or background work.",
        "needs": [
            "System cron, user crontab, supervisor timers, systemd timers, and app-level schedules.",
            "Next/last run times, last exit status, log pointer, and owning config file.",
            "Redacted command preview with secret values removed.",
        ],
        "owner": "cli_mcp",
    },
    {
        "capability": "incident_bundle",
        "summary": "Precompute the context needed to investigate one unhealthy or surprising runtime.",
        "needs": [
            "Target resolution, health, logs, config inventory, env checks, cron/jobs, and recent audit.",
            "Messaging gateway status and channel-specific config.",
            "Skill/plugin enablement and recent config or code changes.",
        ],
        "owner": "cli_mcp",
    },
]

_API_TICKETS = [
    {
        "title": "Expose local AXI helper parity from API-hosted MCP",
        "area": "services/api/services/fleet_agent.py",
        "reason": (
            "The local monolith-mcp surface has agent_contract, proposal, "
            "Fleet Manager, compact workflow, and AXI helper tools. API-hosted "
            "agent sessions should receive the same first-class agent contract."
        ),
        "acceptance": [
            "API-hosted MCP exposes agent_contract and workflow guide tools.",
            "API-hosted MCP exposes Fleet Manager proposal, approval, and execute helpers.",
            "Parity eval treats local and hosted MCP surfaces as equivalent for AXI flows.",
        ],
    },
    {
        "title": "Extract provision orchestration out of router-private helpers",
        "area": "services/api/routers/provision.py",
        "reason": (
            "Fleet Manager durable provision execution currently reuses private "
            "router helpers. A public provision service would reduce coupling."
        ),
        "acceptance": [
            "Shared provision service owns request preparation, validation, job payloads, and run scheduling.",
            "Router and Fleet Manager executor both call the shared service.",
            "Existing provision and Fleet Manager tests remain green.",
        ],
    },
    {
        "title": "Publish API capability manifest for agent clients",
        "area": "Fleet API",
        "reason": (
            "The CLI/MCP can describe the current agent contract locally, but "
            "the authoritative API should eventually advertise supported gates, "
            "executors, and write policies directly."
        ),
        "acceptance": [
            "Read-only endpoint returns supported tools, gates, executors, and disabled write paths.",
            "MCP agent_contract can include live API policy data when available.",
            "Manifest is tenant-aware and redacts unavailable capabilities.",
        ],
    },
    {
        "title": "Expose redacted config provenance for Hermes runtimes",
        "area": "Fleet API runtime/config services",
        "issue_ref": "#14",
        "reason": (
            "CLI/MCP can aggregate visible config, but agents need authoritative "
            "source/provenance for Hermes env, messaging, skills, plugins, and "
            "secret presence without reading raw secrets."
        ),
        "acceptance": [
            "Read-only endpoint returns effective Hermes config with source labels and redacted values.",
            "Messaging gateway config includes Discord channel bindings and provider-specific status.",
            "Secrets are represented as presence, source, and last-rotation metadata only.",
        ],
    },
    {
        "title": "Expose Hermes skill, plugin, and schedule inventory",
        "area": "Fleet API runtime diagnostics",
        "issue_ref": "#14",
        "reason": (
            "Agents investigating unexpected behavior need to know which skills, "
            "plugins, connectors, MCP servers, cron entries, and app schedules are active."
        ),
        "acceptance": [
            "Runtime diagnostics include installed/enabled skills and plugin connectors with load errors.",
            "Runtime diagnostics include cron, systemd timer, supervisor, and app-level schedule summaries.",
            "Inventory is read-only, tenant-scoped, and safe for MCP exposure.",
        ],
    },
]


def agent_contract() -> dict[str, Any]:
    """Return the machine-readable agent contract for this CLI/MCP surface."""
    return {
        "ok": True,
        "schema_version": CONTRACT_VERSION,
        "primary_user": "agent",
        "secondary_user": "human_operator",
        "preferred_surfaces": [
            "monolith-mcp",
            "monolith --json",
            "interactive human CLI",
        ],
        "default_policy": {
            "api_authoritative": True,
            "direct_writes": "blocked_by_default",
            "direct_write_override_env": "MONOLITH_MCP_ALLOW_DIRECT_WRITES",
            "raw_api_writes": "not_exposed_in_mcp",
            "write_route": "fleet_manager_action_first",
            "agent_ops_policy_gate": "required_for_writes",
            "toon_usage": "context_projection_only",
        },
        "required_gates": [
            "agent_ops_policy_gate",
            "policy_diff",
            "rollback_plan",
            "staging_gate",
        ],
        "trusted_write_wrappers": [
            "change_request_create",
            "fleet_manager_action_create",
        ],
        "first_read_tools": [
            "fleet_summary",
            "fleet_health_compact",
            "fleet_agents_compact",
            "container_view",
            "agent_logs_compact",
            "metrics_agent_rca_bundle",
        ],
        "workflow_tools": [
            "triage_agent",
            "drift_scan",
            "rollout_plan",
            "rollback_readiness",
        ],
        "implemented_investigation_tools": list(_INVESTIGATION_TOOLS),
        "planned_agent_tools": list(_INVESTIGATION_TOOLS),
        "write_tools_guarded": [
            "agent_restart",
            "container_update",
            "provision_start",
            "snapshot_create",
            "tenant_create",
        ],
        "avoid_by_default": [
            "api_post",
            "api_patch",
            "api_put",
            "api_delete",
            "MONOLITH_MCP_ALLOW_DIRECT_WRITES=1",
        ],
        "not_exposed_mcp_tools": [
            "api_post",
            "api_patch",
            "api_put",
            "api_delete",
            "sessions_list",
            "session_kill",
            "terminal_session_create",
            "terminal_sessions_list",
            "terminal_session_messages",
            "terminal_session_close",
        ],
        "recommended_sequence": [
            "Call agent_contract or agent_workflow_guide.",
            "Use compact read tools to establish target state.",
            "For Hermes or messaging incidents, collect config, skill/plugin, and schedule inventory before restarting.",
            "For writes, validate Agent Ops policy gate, policy_diff, rollback_plan, and staging_gate evidence.",
            "Submit fleet_manager_action_create.",
            "Execute only after explicit approval via fleet_manager_action_approve.",
            "Poll or inspect results with the returned action/job identifiers.",
        ],
        "operational_gap_backlog": operational_gaps(),
        "api_enhancement_tickets": api_tickets(),
    }


def workflow_guide(intent: str | None = None) -> dict[str, Any]:
    """Return workflow guidance for one intent or the full workflow map."""
    if intent:
        key = intent.strip().lower().replace("-", "_")
        workflow = _WORKFLOWS.get(key)
        if not workflow:
            return {
                "ok": False,
                "schema_version": CONTRACT_VERSION,
                "message": f"Unknown workflow intent: {intent}",
                "available_intents": sorted(_WORKFLOWS),
            }
        return {
            "ok": True,
            "schema_version": CONTRACT_VERSION,
            "workflow": copy.deepcopy(workflow),
        }

    return {
        "ok": True,
        "schema_version": CONTRACT_VERSION,
        "workflows": [copy.deepcopy(_WORKFLOWS[key]) for key in sorted(_WORKFLOWS)],
    }


def api_tickets() -> list[dict[str, Any]]:
    """Return API enhancement tickets that the CLI cannot implement locally."""
    return copy.deepcopy(_API_TICKETS)


def operational_gaps() -> list[dict[str, Any]]:
    """Return CLI/MCP operational gaps needed for robust agent investigation."""
    return copy.deepcopy(_OPERATIONAL_GAPS)
