"""Agent-first read-only diagnostics assembled from existing Fleet API endpoints."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

GetFn = Callable[[str, dict | None], Any]

SENSITIVE_TOKENS = (
    "api_key",
    "apikey",
    "auth",
    "bearer",
    "client_secret",
    "cookie",
    "credential",
    "discord_token",
    "key",
    "password",
    "private",
    "secret",
    "slack_token",
    "telegram_token",
    "token",
    "webhook",
)

HERMES_CONFIG_PATHS = [
    "/home/agent/.config/hermes",
    "/home/agent/.hermes",
    "/opt/hermes",
    "/app/config",
    "/etc/hermes",
]

HERMES_SKILL_PATHS = [
    "/home/agent/.codex/skills",
    "/home/agent/.agents/skills",
    "/opt/hermes/skills",
    "/app/skills",
]

HERMES_PLUGIN_PATHS = [
    "/home/agent/.codex/plugins",
    "/home/agent/.agents/plugins",
    "/opt/hermes/plugins",
    "/app/plugins",
]

CRON_PATHS = [
    "/etc/crontab",
    "/etc/cron.d",
    "/var/spool/cron/crontabs",
    "/home/agent/.config/hermes/schedules.json",
    "/home/agent/.config/hermes/cron.json",
]


def _safe(label: str, fn: Callable[[], Any]) -> dict[str, Any]:
    try:
        return {"ok": True, "label": label, "value": fn()}
    except Exception as exc:
        status = getattr(exc, "status", None)
        detail = getattr(exc, "detail", None)
        result: dict[str, Any] = {
            "ok": False,
            "label": label,
            "error": str(detail or exc),
        }
        if status is not None:
            result["status_code"] = status
        return result


def _containers_from_payload(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        value = payload.get("containers") or payload.get("items") or payload.get("agents") or []
    else:
        value = payload
    return [item for item in value if isinstance(item, dict)] if isinstance(value, list) else []


def _tenant_id(row: dict[str, Any]) -> str | None:
    return row.get("tenant_id") or row.get("tenant")


def _name_fields(row: dict[str, Any]) -> list[str]:
    values = [
        row.get("id"),
        row.get("name"),
        row.get("agent_name"),
        row.get("hostname"),
        row.get("container_name"),
    ]
    return [str(value) for value in values if value not in (None, "")]


def _redact_value(key: str, value: Any) -> Any:
    lowered = key.lower()
    if any(token in lowered for token in SENSITIVE_TOKENS):
        if value in (None, "", [], {}):
            return value
        return "<redacted:present>"
    if isinstance(value, dict):
        return {str(k): _redact_value(str(k), v) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact_value(key, item) for item in value]
    return value


def redact(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _redact_value(str(k), v) for k, v in value.items()}
    if isinstance(value, list):
        return [redact(item) for item in value]
    return value


def _project_container(row: dict[str, Any]) -> dict[str, Any]:
    health = row.get("health") if isinstance(row.get("health"), dict) else {}
    return {
        "id": row.get("id"),
        "tenant_id": _tenant_id(row),
        "agent_name": row.get("agent_name") or row.get("name"),
        "status": row.get("status"),
        "agent_status": health.get("agent_status") or row.get("agent_status"),
        "model": row.get("model"),
        "ip": row.get("ip"),
    }


def target_resolve(
    get: GetFn,
    query: str,
    *,
    tenant: str | None = None,
    include_deleted: bool = False,
) -> dict[str, Any]:
    """Resolve a runtime target exactly, returning ambiguity instead of guessing."""
    normalized_query = (query or "").strip()
    containers_result = _safe("containers_list", lambda: get("/containers", None))
    containers = _containers_from_payload(containers_result.get("value"))
    if tenant:
        containers = [row for row in containers if _tenant_id(row) == tenant]
    if not include_deleted:
        containers = [row for row in containers if row.get("status") != "deleted"]

    lowered = normalized_query.lower()
    exact = [
        row for row in containers
        if any(field.lower() == lowered for field in _name_fields(row))
    ]
    contains = [
        row for row in containers
        if row not in exact and any(lowered in field.lower() for field in _name_fields(row))
    ] if lowered else []

    tenant_result = None
    if tenant:
        tenant_result = _safe("tenant_show", lambda: get(f"/tenants/{tenant}", None))
        if not tenant_result["ok"]:
            tenant_result = _safe("tenants_list", lambda: get("/tenants", None))

    resolved = exact[0] if len(exact) == 1 else None
    if not containers_result["ok"]:
        status = "unavailable"
    elif resolved:
        status = "resolved"
    elif exact:
        status = "ambiguous"
    else:
        status = "not_found"
    return {
        "ok": containers_result["ok"] and bool(resolved),
        "status": status,
        "query": normalized_query,
        "tenant_filter": tenant,
        "include_deleted": include_deleted,
        "resolved": _project_container(resolved) if resolved else None,
        "exact_matches": [_project_container(row) for row in exact],
        "contains_matches": [_project_container(row) for row in contains[:10]],
        "total_candidates": len(containers),
        "tenant_probe": tenant_result,
        "errors": [containers_result] if not containers_result["ok"] else [],
        "help": [
            "Use resolved.id for subsequent reads only when status is resolved.",
            "If ambiguous, retry with the exact container id and tenant.",
        ],
    }


def messaging_discord_config(get: GetFn, container_id: str) -> dict[str, Any]:
    result = _safe(
        "messaging_discord_config",
        lambda: get(f"/containers/{container_id}/messaging/discord", None),
    )
    return {
        "ok": result["ok"],
        "container_id": container_id,
        "config": redact(result.get("value")) if result["ok"] else None,
        "error": None if result["ok"] else result,
    }


def config_inventory(get: GetFn, container_id: str) -> dict[str, Any]:
    calls = {
        "container": _safe("container_detail", lambda: get(f"/containers/{container_id}", None)),
        "runtime_config": _safe("runtime_config", lambda: get(f"/containers/{container_id}/runtime-config", None)),
        "env": _safe("system_env", lambda: get(f"/containers/{container_id}/system/env", None)),
        "connections": _safe("system_connections", lambda: get(f"/containers/{container_id}/system/connections", None)),
        "discord": _safe("messaging_discord_config", lambda: get(f"/containers/{container_id}/messaging/discord", None)),
    }
    available = [name for name, result in calls.items() if result["ok"]]
    missing = [name for name, result in calls.items() if not result["ok"]]
    return {
        "ok": bool(available),
        "container_id": container_id,
        "summary": f"{len(available)} config sections available, {len(missing)} unavailable.",
        "sections": {name: redact(result.get("value")) for name, result in calls.items() if result["ok"]},
        "unavailable": {name: result for name, result in calls.items() if not result["ok"]},
        "provenance": {
            "status": "partial",
            "note": "CLI/MCP aggregates existing read endpoints; authoritative value provenance requires Fleet API support.",
        },
        "help": [
            f"hermes_config_inventory(container_id='{container_id}')",
            f"incident_bundle(container_id='{container_id}')",
        ],
    }


def _inspect_paths(get: GetFn, container_id: str, paths: list[str], *, read_files: bool = False) -> list[dict[str, Any]]:
    inspected = []
    for path in paths:
        endpoint = f"/containers/{container_id}/files/{path.lstrip('/')}" if read_files else f"/containers/{container_id}/files"
        params = None if read_files else {"path": path}
        result = _safe(path, lambda endpoint=endpoint, params=params: get(endpoint, params))
        inspected.append({
            "path": path,
            "kind": "file" if read_files else "directory",
            "ok": result["ok"],
            "value": redact(result.get("value")) if result["ok"] else None,
            "error": None if result["ok"] else result,
        })
    return inspected


def hermes_config_inventory(get: GetFn, container_id: str) -> dict[str, Any]:
    base = config_inventory(get, container_id)
    path_inventory = _inspect_paths(get, container_id, HERMES_CONFIG_PATHS)
    present_paths = [item["path"] for item in path_inventory if item["ok"]]
    return {
        "ok": base["ok"] or bool(present_paths),
        "container_id": container_id,
        "summary": f"Hermes config inventory found {len(present_paths)} candidate config paths.",
        "config_inventory": base,
        "candidate_paths": path_inventory,
        "expected_sections": [
            "runtime identity",
            "model/provider",
            "prompt/profile source",
            "messaging gateway toggles",
            "workspace and memory paths",
            "effective-vs-pending diff",
        ],
    }


def hermes_skill_enablement(get: GetFn, container_id: str) -> dict[str, Any]:
    paths = _inspect_paths(get, container_id, HERMES_SKILL_PATHS)
    present = [item for item in paths if item["ok"]]
    return {
        "ok": bool(present),
        "container_id": container_id,
        "summary": f"{len(present)} candidate skill directories readable.",
        "skill_paths": paths,
        "provenance": "Directory inventory only; enabled/disabled/load-error parity needs runtime support when not encoded on disk.",
    }


def hermes_plugin_inventory(get: GetFn, container_id: str) -> dict[str, Any]:
    paths = _inspect_paths(get, container_id, HERMES_PLUGIN_PATHS)
    present = [item for item in paths if item["ok"]]
    return {
        "ok": bool(present),
        "container_id": container_id,
        "summary": f"{len(present)} candidate plugin directories readable.",
        "plugin_paths": paths,
        "provenance": "Directory inventory only; connector auth and health need provider/runtime status endpoints when unavailable on disk.",
    }


def cron_job_inventory(get: GetFn, container_id: str) -> dict[str, Any]:
    directory_paths = [path for path in CRON_PATHS if not path.endswith((".json", "crontab"))]
    file_paths = [path for path in CRON_PATHS if path not in directory_paths]
    dirs = _inspect_paths(get, container_id, directory_paths)
    files = _inspect_paths(get, container_id, file_paths, read_files=True)
    readable = [item for item in dirs + files if item["ok"]]
    return {
        "ok": bool(readable),
        "container_id": container_id,
        "summary": f"{len(readable)} cron or schedule locations readable.",
        "directories": dirs,
        "files": files,
        "limitations": [
            "No command execution is used.",
            "Next/last run timestamps require runtime scheduler or API support when not present in files.",
        ],
    }


def incident_bundle(
    get: GetFn,
    container_id: str,
    *,
    tenant: str | None = None,
    log_lines: int = 40,
) -> dict[str, Any]:
    target = target_resolve(get, container_id, tenant=tenant)
    resolved_id = (
        target.get("resolved", {}).get("id")
        if isinstance(target.get("resolved"), dict)
        else None
    ) or container_id
    config = config_inventory(get, resolved_id)
    hermes_config = hermes_config_inventory(get, resolved_id)
    skills = hermes_skill_enablement(get, resolved_id)
    plugins = hermes_plugin_inventory(get, resolved_id)
    cron = cron_job_inventory(get, resolved_id)
    audit_params = {
        "hours": 24,
        "limit": 25,
        "container_id": resolved_id,
    }
    if tenant:
        audit_params["tenant"] = tenant
    calls = {
        "target": {"ok": bool(target.get("ok")), "value": target},
        "container": _safe("container_detail", lambda: get(f"/containers/{resolved_id}", None)),
        "health": _safe("container_health", lambda: get(f"/containers/{resolved_id}/health", None)),
        "agent": _safe("agent_status", lambda: get(f"/containers/{resolved_id}/agent", None)),
        "logs": _safe("agent_logs", lambda: get(f"/containers/{resolved_id}/agent/logs", {"lines": log_lines})),
        "config": {"ok": bool(config.get("ok")), "value": config},
        "hermes_config": {"ok": bool(hermes_config.get("ok")), "value": hermes_config},
        "skills": {"ok": bool(skills.get("ok")), "value": skills},
        "plugins": {"ok": bool(plugins.get("ok")), "value": plugins},
        "cron": {"ok": bool(cron.get("ok")), "value": cron},
        "fleet_audit_context": _safe("fleet_audit_context", lambda: get("/fleet/audit", audit_params)),
    }
    unavailable = {name: result for name, result in calls.items() if not result["ok"]}
    return {
        "ok": len(unavailable) < len(calls),
        "container_id": resolved_id,
        "tenant": tenant,
        "summary": f"Incident bundle assembled with {len(calls) - len(unavailable)} sections available.",
        "sections": {name: redact(result.get("value")) for name, result in calls.items() if result["ok"]},
        "unavailable": unavailable,
        "next_checks": [
            "Confirm target.status is resolved before mutating anything.",
            "Check config.discord, skills, plugins, and cron before restarting Hermes.",
            "Route any mutation through Fleet Manager proposal tools.",
        ],
    }
