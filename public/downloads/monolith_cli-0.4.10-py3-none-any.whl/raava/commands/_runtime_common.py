"""Shared helpers for Monolith runtime command groups."""

from __future__ import annotations

from raava import client, display


def container_rows() -> list[dict]:
    data = client.get("/containers")
    rows = data.get("containers", []) if isinstance(data, dict) else []
    return [row for row in rows if row.get("status") != "deleted"]


def runtime_columns() -> list[tuple[str, str]]:
    return [
        ("ID", "id"),
        ("Tenant", "tenant"),
        ("Agent", "agent_name"),
        ("Status", "status"),
        ("Provider", "provider"),
        ("Host", "host"),
        ("Zone", "zone"),
        ("IP", "ip"),
    ]


def print_lines(data: dict) -> None:
    if display.is_json_mode():
        display.print_json(data)
        return
    for line in data.get("lines", []):
        display.console.print(line)


def success_or_json(data: dict, message: str) -> None:
    if display.is_json_mode():
        display.print_json(data)
        return
    display.print_success(message)
