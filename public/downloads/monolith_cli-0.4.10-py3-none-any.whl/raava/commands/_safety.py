"""Operator safety notices for deprecated direct-write command paths."""

from __future__ import annotations

from raava import display


def warn_deprecated_direct_write(command: str, replacement: str) -> None:
    display.print_warning(
        f"{command} uses a deprecated direct Fleet API write path. "
        f"Prefer {replacement}; keep this command for operator break-glass only."
    )
