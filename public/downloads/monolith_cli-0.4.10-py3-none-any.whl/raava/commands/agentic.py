"""Agent-first CLI contract commands."""

from __future__ import annotations

import typer

from raava import agent_contract, agent_diagnostics, client, display

OutputFormat = str

app = typer.Typer(
    no_args_is_help=True,
    help="Machine-readable agent contract, workflow guidance, and API ticket handoff.",
)


def _scalar(value) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float, str)):
        return str(value)
    return repr(value)


def _render_toon(data: dict, indent: int = 0) -> str:
    lines: list[str] = []
    prefix = "  " * indent
    for key, value in data.items():
        if isinstance(value, dict):
            lines.append(f"{prefix}{key}:")
            lines.append(_render_toon(value, indent + 1))
            continue
        if isinstance(value, list):
            lines.append(f"{prefix}{key}:")
            for item in value:
                if isinstance(item, dict):
                    lines.append(f"{prefix}  -")
                    lines.append(_render_toon(item, indent + 2))
                else:
                    lines.append(f"{prefix}  - {_scalar(item)}")
            continue
        lines.append(f"{prefix}{key}: {_scalar(value)}")
    return "\n".join(line for line in lines if line)


def _emit(data: dict, output_format: OutputFormat = "json"):
    if display.is_json_mode() or output_format == "json":
        display.print_json(data)
        return
    if output_format == "toon":
        display.console.print(_render_toon(data))
        return
    display.print_error("format must be one of: json, toon")
    raise typer.Exit(1)


def _client_get(path: str, params: dict | None = None):
    return client.get(path, params=params, resolve_containers=False)


@app.command("contract")
def contract(
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    )
):
    """Print the agent-first CLI/MCP contract."""
    _emit(agent_contract.agent_contract(), output_format)


@app.command("workflows")
def workflows(
    intent: str | None = typer.Argument(
        None,
        help="Optional workflow intent: orient, triage, staged_write, provision.",
    ),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Print agent workflow guidance."""
    _emit(agent_contract.workflow_guide(intent), output_format)


@app.command("api-tickets")
def api_tickets(
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    )
):
    """Print API enhancement tickets that should not be solved in the CLI."""
    _emit(
        {
            "ok": True,
            "schema_version": agent_contract.CONTRACT_VERSION,
            "tickets": agent_contract.api_tickets(),
        },
        output_format,
    )


@app.command("target-resolve")
def target_resolve(
    query: str = typer.Argument(..., help="Exact runtime id/name/alias to resolve."),
    tenant: str | None = typer.Option(None, "--tenant", help="Restrict resolution to one tenant."),
    include_deleted: bool = typer.Option(
        False,
        "--include-deleted",
        help="Include deleted runtimes in candidate output.",
    ),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Resolve a runtime target exactly without fuzzy guessing."""
    _emit(
        agent_diagnostics.target_resolve(
            _client_get,
            query,
            tenant=tenant,
            include_deleted=include_deleted,
        ),
        output_format,
    )


@app.command("config-inventory")
def config_inventory(
    container_id: str = typer.Argument(..., help="Exact container ID."),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Aggregate runtime config, env, messaging, and connectivity facts."""
    _emit(agent_diagnostics.config_inventory(_client_get, container_id), output_format)


@app.command("hermes-config")
def hermes_config(
    container_id: str = typer.Argument(..., help="Exact container ID."),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Inspect Hermes-specific config and candidate config paths."""
    _emit(agent_diagnostics.hermes_config_inventory(_client_get, container_id), output_format)


@app.command("hermes-skills")
def hermes_skills(
    container_id: str = typer.Argument(..., help="Exact container ID."),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Inspect Hermes skill enablement evidence available through read endpoints."""
    _emit(agent_diagnostics.hermes_skill_enablement(_client_get, container_id), output_format)


@app.command("hermes-plugins")
def hermes_plugins(
    container_id: str = typer.Argument(..., help="Exact container ID."),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Inspect Hermes plugin and connector evidence available through read endpoints."""
    _emit(agent_diagnostics.hermes_plugin_inventory(_client_get, container_id), output_format)


@app.command("cron-inventory")
def cron_inventory(
    container_id: str = typer.Argument(..., help="Exact container ID."),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Inspect cron, timer, and app schedule locations without executing commands."""
    _emit(agent_diagnostics.cron_job_inventory(_client_get, container_id), output_format)


@app.command("incident-bundle")
def incident_bundle(
    container_id: str = typer.Argument(..., help="Exact container ID or unambiguous runtime name."),
    tenant: str | None = typer.Option(None, "--tenant", help="Restrict target resolution to one tenant."),
    log_lines: int = typer.Option(40, "--log-lines", min=1, max=200, help="Agent log lines to request."),
    output_format: OutputFormat = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json or toon. JSON remains authoritative.",
    ),
):
    """Build one investigation bundle for an agent/runtime incident."""
    _emit(
        agent_diagnostics.incident_bundle(
            _client_get,
            container_id,
            tenant=tenant,
            log_lines=log_lines,
        ),
        output_format,
    )
