"""Tenant-scoped agent inventory and VM attach commands."""

from __future__ import annotations

import shlex
import subprocess

import typer

from raava import client, display
from raava.client import APIError

app = typer.Typer(no_args_is_help=True)

DEFAULT_WORKDIR = "/home/agent/hermes-agent"
_VALID_VIA = {"auto", "ssh", "gcloud"}
_VALID_ASSISTANTS = {"codex", "claude"}
_PROVIDER_DEFAULT_USERS = {
    "aws": "ubuntu",
    "gce": "raava",
    "gcp": "raava",
    "lxd": "agent",
}


def _provider(row: dict) -> str:
    return str(row.get("provider") or "lxd").lower()


def _default_user(row: dict) -> str:
    return _PROVIDER_DEFAULT_USERS.get(_provider(row), "agent")


def _target_text(row: dict) -> str:
    return str(row.get("ip") or row.get("host") or row.get("hostname") or "")


def _gcp_project(row: dict) -> str:
    return str(
        row.get("gcp_project")
        or row.get("gcp_project_id")
        or row.get("gce_project")
        or row.get("project_id")
        or ""
    ).strip()


def _agent_rows(
    *,
    tenant: str | None = None,
    status: str | None = None,
    unit: str | None = None,
) -> list[dict]:
    params: dict[str, str] = {}
    if tenant:
        params["tenant"] = tenant
    if status:
        params["status"] = status
    if unit:
        params["unit"] = unit
    data = client.get("/fleet/agents", params=params)
    rows = data.get("containers", []) if isinstance(data, dict) else []
    for row in rows:
        display.enrich_health(row)
        row["tenant"] = row.get("tenant") or row.get("tenant_id") or tenant or ""
        row["unit"] = row.get("unit") or row.get("unit_id") or unit or ""
        row["_target"] = _target_text(row)
        health = row.get("health") or {}
        row["_agent_status"] = health.get("agent_status", "unknown") if health else "unknown"
    return rows


def _resolve_agent_row(rows: list[dict], target: str) -> dict:
    needle = target.strip().lower()
    if not needle:
        raise APIError(400, "Agent target is required")

    def keys(row: dict) -> list[str]:
        return [
            str(row.get("id") or ""),
            str(row.get("agent_name") or ""),
            str(row.get("tenant_id") or ""),
            str(row.get("unit_id") or ""),
        ]

    exact = [row for row in rows if needle in {key.lower() for key in keys(row) if key}]
    if len(exact) == 1:
        return exact[0]
    if len(exact) > 1:
        matches = ", ".join(str(row.get("id")) for row in exact[:8])
        raise APIError(400, f"Ambiguous agent {target}. Matches: {matches}")

    prefix = [
        row
        for row in rows
        if any(key.lower().startswith(needle) for key in keys(row) if key)
    ]
    if len(prefix) == 1:
        return prefix[0]
    if len(prefix) > 1:
        matches = ", ".join(str(row.get("id")) for row in prefix[:8])
        raise APIError(400, f"Ambiguous agent {target}. Matches: {matches}")

    contains = [
        row
        for row in rows
        if any(needle in key.lower() for key in keys(row) if key)
    ]
    if len(contains) == 1:
        return contains[0]
    if len(contains) > 1:
        matches = ", ".join(str(row.get("id")) for row in contains[:8])
        raise APIError(400, f"Ambiguous agent {target}. Matches: {matches}")

    raise APIError(404, f"No agent matching {target}")


def _remote_command(
    *,
    workdir: str | None = DEFAULT_WORKDIR,
    command: str | None = None,
    assistant: str | None = None,
) -> str:
    if command and assistant:
        raise APIError(400, "Use either --command or --assistant, not both")
    if assistant and assistant not in _VALID_ASSISTANTS:
        raise APIError(
            400,
            f"--assistant must be one of: {', '.join(sorted(_VALID_ASSISTANTS))}",
        )

    if command:
        payload = command
    elif assistant:
        payload = f"exec {shlex.quote(assistant)}"
    else:
        payload = "exec ${SHELL:-/bin/bash} -l"

    if not workdir:
        return payload

    quoted = shlex.quote(workdir)
    return f"cd {quoted} 2>/dev/null || cd /home/agent 2>/dev/null || cd ~; {payload}"


def build_attach_command(
    row: dict,
    *,
    via: str = "auto",
    user: str | None = None,
    identity: str | None = None,
    port: int | None = None,
    workdir: str | None = DEFAULT_WORKDIR,
    command: str | None = None,
    assistant: str | None = None,
    ssh_args: list[str] | None = None,
) -> list[str]:
    """Build the native attach command for a resolved agent row."""
    if via not in _VALID_VIA:
        raise APIError(400, f"--via must be one of: {', '.join(sorted(_VALID_VIA))}")

    provider = _provider(row)
    selected = via
    if selected == "auto":
        selected = "gcloud" if provider in {"gce", "gcp"} and row.get("zone") else "ssh"

    selected_user = user or _default_user(row)
    remote = _remote_command(workdir=workdir, command=command, assistant=assistant)

    if selected == "gcloud":
        instance = str(row.get("gce_instance_id") or row.get("id") or "").strip()
        if not instance:
            raise APIError(400, "Resolved agent has no VM instance name")
        target = f"{selected_user}@{instance}" if selected_user else instance
        cmd = ["gcloud", "compute", "ssh", target]
        project = _gcp_project(row)
        zone = str(row.get("zone") or "").strip()
        if project:
            cmd.extend(["--project", project])
        if zone:
            cmd.extend(["--zone", zone])
        if remote:
            cmd.extend(["--ssh-flag=-t", "--command", remote])
        return cmd

    host = str(row.get("ip") or row.get("host") or row.get("hostname") or "").strip()
    if not host:
        raise APIError(
            400,
            "Resolved agent has no SSH target host. Try `monolith agents list --tenant <tenant>` first.",
        )

    cmd = ["ssh"]
    if remote:
        cmd.append("-t")
    if identity:
        cmd.extend(["-i", identity])
    if port:
        cmd.extend(["-p", str(port)])
    cmd.extend(ssh_args or [])
    cmd.append(f"{selected_user}@{host}" if selected_user else host)
    if remote:
        cmd.append(remote)
    return cmd


def _resolved_agent(target: str, tenant: str | None, unit: str | None) -> dict:
    rows = _agent_rows(tenant=tenant, unit=unit)
    if not rows:
        scope = f" tenant {tenant}" if tenant else ""
        raise APIError(404, f"No agents found for{scope or ' current scope'}")
    row = _resolve_agent_row(rows, target)
    detail = client.get(f"/containers/{row['id']}")
    return {**row, **detail}


@app.command("list")
def list_agents(
    tenant: str | None = typer.Option(None, "--tenant", "-t", help="Tenant ID"),
    status: str | None = typer.Option(
        None, "--status", "-s", help="Filter: active, idle, stopped, error"
    ),
    unit: str | None = typer.Option(None, "--unit", "-u", help="Business unit ID"),
):
    """List agents, optionally scoped to one tenant."""
    rows = _agent_rows(tenant=tenant, status=status, unit=unit)
    cols = [
        ("ID", "id"),
        ("Tenant", "tenant"),
        ("Unit", "unit"),
        ("Agent", "agent_name"),
        ("Role", "agent_role"),
        ("Provider", "provider"),
        ("Target", "_target"),
        ("Status", "status"),
        ("Agent Status", "_agent_status"),
        ("CPU%", "_cpu"),
        ("Mem%", "_mem"),
    ]
    title = f"Tenant Agents: {tenant}" if tenant else "Agents"
    display.table(rows, cols, title=title, row_styles=["none", "dim"])


@app.command()
def ssh(
    target: str = typer.Argument(..., help="Agent/container id or agent name"),
    tenant: str | None = typer.Option(None, "--tenant", "-t", help="Tenant ID"),
    unit: str | None = typer.Option(None, "--unit", "-u", help="Business unit ID"),
    user: str | None = typer.Option(None, "--user", help="SSH username override"),
    identity: str | None = typer.Option(None, "--identity", "-i", help="SSH private key"),
    port: int | None = typer.Option(None, "--port", "-p", help="SSH port"),
    workdir: str | None = typer.Option(
        DEFAULT_WORKDIR,
        "--workdir",
        help="Remote directory to enter before launching a shell or assistant",
    ),
    command: str | None = typer.Option(
        None, "--command", "-c", help="Remote command to run after connecting"
    ),
    assistant: str | None = typer.Option(
        None, "--assistant", help="Run a coding assistant after attach: codex or claude"
    ),
    via: str = typer.Option(
        "auto", "--via", help="Attach transport: auto, ssh, or gcloud"
    ),
    print_only: bool = typer.Option(
        False, "--print", help="Print the attach command instead of executing it"
    ),
    ssh_arg: list[str] | None = typer.Option(
        None, "--ssh-arg", help="Extra argument passed to native ssh"
    ),
):
    """SSH into a tenant agent VM/container and land in the runtime code directory."""
    row = _resolved_agent(target, tenant, unit)
    cmd = build_attach_command(
        row,
        via=via,
        user=user,
        identity=identity,
        port=port,
        workdir=workdir,
        command=command,
        assistant=assistant,
        ssh_args=ssh_arg,
    )

    payload = {
        "agent": {
            "id": row.get("id"),
            "tenant": row.get("tenant"),
            "unit": row.get("unit"),
            "agent_name": row.get("agent_name"),
            "provider": row.get("provider"),
            "ip": row.get("ip"),
            "host": row.get("host"),
            "zone": row.get("zone"),
        },
        "command": cmd,
        "shell": shlex.join(cmd),
    }

    if display.is_json_mode():
        display.print_json(payload)
        return
    if print_only:
        display.console.print(payload["shell"])
        return

    display.console.print(
        f"[dim]Connecting to {row.get('id')} ({row.get('agent_name')})...[/dim]"
    )
    try:
        result = subprocess.run(cmd, check=False)
    except FileNotFoundError as exc:
        binary = cmd[0] if cmd else "ssh"
        display.print_error(
            f"{binary} executable not found. Install {binary} or rerun with --print."
        )
        raise typer.Exit(127) from exc
    raise typer.Exit(result.returncode)
