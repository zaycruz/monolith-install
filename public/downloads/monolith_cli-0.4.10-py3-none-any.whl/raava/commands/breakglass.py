"""Explicit provider CLI break-glass guidance."""

from __future__ import annotations

import json
from datetime import UTC, datetime

import typer

from raava import config, display

app = typer.Typer(no_args_is_help=True)

_GUIDANCE = {
    "allowed_when": [
        "Monolith control-plane state is stale or missing",
        "provider outage blocks Monolith health checks",
        "serial console, OS Login, raw IAM, quota, or org-policy recovery is required",
        "the task is generic cloud administration and not about a Monolith object",
    ],
    "not_allowed_for": [
        "normal runtime health checks",
        "normal agent/service logs",
        "normal runtime restarts",
        "normal runtime config inspection or apply",
        "Monolith-managed host lookup",
    ],
    "rule": (
        "Use Monolith first. Use provider CLI only with a named missing capability "
        "or emergency recovery reason."
    ),
}


def _write_audit_record(payload: dict) -> str:
    config.CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        config.CONFIG_DIR.chmod(0o700)
    except OSError:
        pass
    audit_path = config.CONFIG_DIR / "breakglass-audit.jsonl"
    with audit_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, sort_keys=True) + "\n")
    try:
        audit_path.chmod(0o600)
    except OSError:
        pass
    return str(audit_path)


@app.command("policy")
def policy():
    """Show the provider CLI break-glass boundary."""
    display.detail(_GUIDANCE, title="Monolith Break-Glass Policy")


@app.command("reason")
def reason(
    reason: str = typer.Argument(..., help="Why provider CLI fallback is required"),
):
    """Record an auditable break-glass reason without running provider CLI commands."""
    payload = {
        "breakglass": True,
        "reason": reason,
        "recorded_at": datetime.now(UTC).isoformat(),
        **_GUIDANCE,
    }
    payload["audit_path"] = _write_audit_record(payload)
    display.detail(payload, title="Break-Glass Reason")
