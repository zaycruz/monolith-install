"""CLI configuration management."""

import typer

from raava import config, display

app = typer.Typer(no_args_is_help=True)
env_app = typer.Typer(no_args_is_help=True)


def _display_config() -> dict:
    data = config.all_config()
    if data.get("api_key"):
        data["api_key"] = "<redacted>"
    return data


@app.command()
def show():
    """Show current configuration."""
    display.detail(_display_config(), title="Monolith CLI Config")


@app.command("set")
def set_config(
    key: str = typer.Argument(..., help="Config key (api_url, timeout, output)"),
    value: str = typer.Argument(..., help="Value"),
):
    """Set a config value."""
    if key not in config.VALID_KEYS:
        display.print_warning(f"Unknown key '{key}'. Valid keys: {', '.join(sorted(config.VALID_KEYS))}")
    old = config.get(key)
    config.set_value(key, value)
    display.print_success(f"{key}: {old} -> {config.get(key)}")


@app.command("get")
def get_config(
    key: str = typer.Argument(..., help="Config key to read"),
):
    """Get a single config value."""
    value = config.get(key)
    if value is None:
        display.print_error(f"Key '{key}' not found")
        raise typer.Exit(1)
    display.console.print(f"[bold]{key}:[/] {value}")


@app.command()
def reset(
    key: str = typer.Argument(..., help="Config key to reset to default"),
):
    """Reset a config key to its default value."""
    if key not in config.VALID_KEYS:
        display.print_error(f"Unknown key '{key}'. Valid keys: {', '.join(sorted(config.VALID_KEYS))}")
        raise typer.Exit(1)
    config.delete_key(key)
    display.print_success(f"'{key}' reset to default: {config.get(key)}")


@app.command()
def path():
    """Show the config file path."""
    display.console.print(f"[bold]Config file:[/] {config.CONFIG_FILE}")
    if config.active_env():
        display.console.print(
            f"[bold]Active env:[/] {config.active_env()} ({config.profile_file(config.active_env())})"
        )
    exists = config.CONFIG_FILE.exists()
    display.console.print(f"[bold]Exists:[/] {'yes' if exists else 'no'}")


@env_app.command("list")
def list_envs():
    """List configured environment profiles."""
    rows = config.list_envs()
    display.table(
        rows,
        [
            ("Env", "env"),
            ("Active", "active"),
            ("Configured", "configured"),
            ("API URL", "api_url"),
        ],
        title="Monolith Environments",
    )


@env_app.command("use")
def use_env(
    env: str = typer.Argument(
        ...,
        help="Environment profile: local, staging, prod, or another normalized profile name",
    ),
):
    """Switch the active environment profile."""
    try:
        data = config.use_env(env)
    except ValueError as exc:
        display.print_error(str(exc))
        raise typer.Exit(1) from None

    display.print_success(f"Active environment: {data['active_env']}")
    if data.get("api_url"):
        display.console.print(f"| api_url: {data['api_url']}")
    else:
        display.console.print("| api_url: not configured")


@env_app.command("current")
def current_env():
    """Show the active environment profile."""
    env = config.active_env() or "legacy"
    display.console.print(f"[bold]Active environment:[/] {env}")
    display.detail(_display_config(), title="Effective Config")


app.add_typer(env_app, name="env", help="Switch between local, staging, and prod profiles")
