"""Git operations inside containers."""

import typer

from raava import client, display
from raava.commands._safety import warn_deprecated_direct_write

app = typer.Typer(no_args_is_help=True)


@app.command()
def status(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Show git status."""
    data = client.get(f"/containers/{container_id}/git/status", params={"path": path})
    if display.is_json_mode():
        display.print_json(data)
        return
    display.console.print(f"Branch: [bold]{data.get('branch')}[/bold]  Clean: {'[green]yes[/green]' if data.get('clean') else '[yellow]no[/yellow]'}")
    for f in data.get("files", []):
        display.console.print(f"  [dim]{f['status']}[/dim] {f['file']}")


@app.command()
def commit(
    container_id: str = typer.Argument(..., help="Container ID"),
    message: str = typer.Argument(..., help="Commit message"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Deprecated direct git commit (stages all changes)."""
    warn_deprecated_direct_write("git commit", "Fleet Manager proposal/approval")
    data = client.post(f"/containers/{container_id}/git/commit", json={"message": message, "path": path})
    if data.get("status") == "nothing_to_commit":
        display.console.print("[dim]Nothing to commit[/dim]")
    else:
        display.print_success(f"Committed [{data.get('hash')}] {message}")


@app.command()
def log(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
    limit: int = typer.Option(20, "--limit", "-n", help="Max commits to show"),
):
    """Show git log."""
    data = client.get(f"/containers/{container_id}/git/log", params={"path": path, "limit": limit})
    cols = [
        ("Hash", "short_hash"),
        ("Author", "author"),
        ("Date", "date"),
        ("Message", "message"),
    ]
    display.table(data.get("commits", []), cols, title=f"Git Log: {container_id}")


@app.command()
def push(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Deprecated direct git push."""
    warn_deprecated_direct_write("git push", "Fleet Manager proposal/approval")
    data = client.post(f"/containers/{container_id}/git/push", json={"path": path})
    display.print_success(data.get("output", "Pushed"))


@app.command()
def pull(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Deprecated direct git pull."""
    warn_deprecated_direct_write("git pull", "Fleet Manager proposal/approval")
    data = client.post(f"/containers/{container_id}/git/pull", json={"path": path})
    display.print_success(data.get("output", "Pulled"))


@app.command()
def branches(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """List git branches."""
    data = client.get(f"/containers/{container_id}/git/branches", params={"path": path})
    for b in data.get("branches", []):
        marker = " *" if b.get("current") else ""
        color = "green" if b.get("current") else "white"
        display.console.print(f"  [{color}]{b['name']}{marker}[/{color}]")


@app.command()
def branch(
    container_id: str = typer.Argument(..., help="Container ID"),
    name: str = typer.Argument(..., help="New branch name"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Deprecated direct branch creation."""
    warn_deprecated_direct_write("git branch", "Fleet Manager proposal/approval")
    client.post(f"/containers/{container_id}/git/branch", json={"name": name, "path": path})
    display.print_success(f"Created and switched to branch '{name}'")


@app.command()
def checkout(
    container_id: str = typer.Argument(..., help="Container ID"),
    name: str = typer.Argument(..., help="Branch name"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Deprecated direct checkout."""
    warn_deprecated_direct_write("git checkout", "Fleet Manager proposal/approval")
    client.post(f"/containers/{container_id}/git/checkout", json={"name": name, "path": path})
    display.print_success(f"Switched to branch '{name}'")


@app.command()
def merge(
    container_id: str = typer.Argument(..., help="Container ID"),
    branch_name: str = typer.Argument(..., help="Branch to merge"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Deprecated direct merge that may restart the agent."""
    warn_deprecated_direct_write("git merge", "Fleet Manager proposal/approval")
    data = client.post(f"/containers/{container_id}/git/merge", json={"branch": branch_name, "path": path})
    msg = f"Merged {data.get('source')} -> {data.get('target')} [{data.get('hash')}]"
    if data.get("restart_triggered"):
        msg += " (agent restarted)"
    display.print_success(msg)


@app.command()
def diff(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Option("/home/agent", "--path", "-p", help="Repository path inside container"),
):
    """Show uncommitted changes."""
    data = client.get(f"/containers/{container_id}/git/diff", params={"path": path})
    if display.is_json_mode():
        display.print_json(data)
        return
    diff_text = data.get("diff", "")
    if not diff_text.strip():
        display.console.print("[dim]No changes[/dim]")
    else:
        display.console.print(diff_text)
