"""Local-first harness summaries and proposal stubs."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

import typer

from raava import display

app = typer.Typer(
    no_args_is_help=False,
    help="AXI-style local harness summaries and proposal stubs.",
)

def _find_repo_root(start: Path | None = None) -> Path:
    """Find the Monolith product root when the CLI is run from tools/cli."""
    start_path = (start or Path(__file__)).resolve()
    for parent in (start_path, *start_path.parents):
        if (parent / "docs" / "agent-ops").is_dir():
            return parent
    return Path(__file__).resolve().parents[2]


_REPO_ROOT = _find_repo_root()
_DEFAULT_EVAL_REPORT = _REPO_ROOT / "docs/agent-ops/generated/mcp_gap_report.md"
_DEFAULT_READINESS_REPORT = (
    _REPO_ROOT / "docs/agent-ops/generated/harness_staging_eval_latest.md"
)
_ALLOWED_EVIDENCE = {
    "need_to_know",
    "redaction",
    "policy_diff",
    "rollback_plan",
    "verification_plan",
    "operator_approval",
    "staging_evidence",
    "owner_approval",
    "stop_conditions",
    "break_glass_reason",
    "post_action_review",
}


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value if value is not None else {},
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _load_text(path: Path, label: str) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        display.print_error(f"{label} not found: {path}")
        raise typer.Exit(1) from exc


def _display_path(path: Path) -> str:
    try:
        return str(path.relative_to(_REPO_ROOT))
    except ValueError:
        return str(path)


def _match(pattern: str, text: str, *, label: str) -> str:
    match = re.search(pattern, text, flags=re.MULTILINE)
    if not match:
        display.print_error(f"Could not parse {label} from the report")
        raise typer.Exit(1)
    return match.group(1)


def _match_float(pattern: str, text: str, *, label: str) -> float:
    return float(_match(pattern, text, label=label))


def _match_int(pattern: str, text: str, *, label: str) -> int:
    return int(_match(pattern, text, label=label))


def _section(text: str, heading: str) -> str:
    match = re.search(
        rf"^## {re.escape(heading)}\n(.*?)(?=^## |\Z)",
        text,
        flags=re.MULTILINE | re.DOTALL,
    )
    return match.group(1).strip() if match else ""


def _parse_bullets(section_text: str) -> list[str]:
    items: list[str] = []
    current: list[str] = []
    for raw_line in section_text.splitlines():
        line = raw_line.rstrip()
        if line.startswith("- "):
            if current:
                items.append(" ".join(part.strip() for part in current).strip())
            current = [line[2:].strip()]
            continue
        if current and line.strip():
            current.append(line.strip())
    if current:
        items.append(" ".join(part.strip() for part in current).strip())
    return items


def _parse_json_option(raw: str | None, label: str) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        display.print_error(f"Invalid JSON for {label}: {exc}")
        raise typer.Exit(1) from exc
    if not isinstance(value, dict):
        display.print_error(f"{label} must be a JSON object")
        raise typer.Exit(1)
    return value


def _normalize_evidence(evidence: list[str] | None) -> list[str]:
    normalized = sorted({item.strip() for item in evidence or [] if item.strip()})
    invalid = [item for item in normalized if item not in _ALLOWED_EVIDENCE]
    if invalid:
        display.print_error(
            f"Unknown evidence values: {', '.join(invalid)}. "
            f"Valid values: {', '.join(sorted(_ALLOWED_EVIDENCE))}"
        )
        raise typer.Exit(1)
    return normalized


def _missing_evidence(required: list[str], provided: list[str]) -> list[str]:
    provided_set = set(provided)
    return [item for item in required if item not in provided_set]


def _scalar(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, float):
        rendered = f"{value:.1f}"
        if rendered.endswith(".0"):
            return rendered[:-2]
        return rendered
    if isinstance(value, (int, str)):
        return str(value)
    return _canonical_json(value)


def _render_toon(data: dict[str, Any]) -> str:
    lines: list[str] = []
    for key, value in data.items():
        if isinstance(value, dict):
            if not value:
                lines.append(f"{key}: {{}}")
                continue
            lines.append(f"{key}:")
            for child_key, child_value in value.items():
                lines.append(f"  {child_key}: {_scalar(child_value)}")
            continue
        if isinstance(value, list):
            if not value:
                lines.append(f"{key}: []")
                continue
            lines.append(f"{key}:")
            for item in value:
                if isinstance(item, dict):
                    compact = ", ".join(
                        f"{item_key}={_scalar(item_value)}"
                        for item_key, item_value in item.items()
                    )
                    lines.append(f"  - {compact}")
                else:
                    lines.append(f"  - {_scalar(item)}")
            continue
        lines.append(f"{key}: {_scalar(value)}")
    return "\n".join(lines)


def _emit(summary: dict[str, Any]) -> None:
    if display.is_json_mode():
        display.print_json(summary)
        return
    display.console.print(_render_toon(summary))


def _readiness_summary(report: Path) -> dict[str, Any]:
    text = _load_text(report, "Readiness report")
    failures = _parse_bullets(_section(text, "Failures"))
    pass_rate = _match(r"- Pass rate:\s+([0-9.]+%)", text, label="pass rate")
    failed = _match_int(r"- Failed:\s+(\d+)", text, label="failed count")
    verdict = "blocked" if failed else "ready"
    if verdict == "ready" and failures:
        verdict = "caution"

    return {
        "kind": "harness.readiness",
        "verdict": verdict,
        "artifact": _display_path(report),
        "run_id": _match(r"Run ID:\s+`([^`]+)`", text, label="run id"),
        "generated_at": _match(r"Generated:\s+`([^`]+)`", text, label="generated time"),
        "cases": _match_int(r"- Cases:\s+(\d+)", text, label="case count"),
        "passed": _match_int(r"- Passed:\s+(\d+)", text, label="pass count"),
        "failed": failed,
        "expected_failures": _match_int(
            r"- Expected-failure probes:\s+(\d+)",
            text,
            label="expected-failure count",
        ),
        "pass_rate": pass_rate,
        "blocking_failures": failures,
        "summary": (
            "Local readiness report only. Treat live writes as blocked until "
            "the blocking failures are cleared."
            if failed
            else "Local readiness report shows no blocking failures."
        ),
    }


def _eval_summary(report: Path) -> dict[str, Any]:
    text = _load_text(report, "Eval report")
    gaps = _section(text, "Gaps")
    recommendations = _parse_bullets(_section(text, "Recommendations"))
    executable_policy_gates = _match(
        r"- Executable policy gates:\s+(.+)",
        gaps,
        label="executable policy gates",
    )
    untrusted_write_tools = _match(
        r"- Untrusted external write tools:\s+(.+)",
        gaps,
        label="untrusted external write tools",
    )
    trusted_wrappers = _match(
        r"- Trusted change-request/proposal wrappers:\s+(.+)",
        gaps,
        label="trusted wrappers",
    )
    score = _match_float(
        r"Static coverage score:\s+([0-9.]+)\/100",
        text,
        label="static coverage score",
    )
    verdict = "ready" if score >= 95.0 else "caution"
    if executable_policy_gates != "none":
        verdict = "caution"

    return {
        "kind": "harness.eval",
        "verdict": verdict,
        "artifact": _display_path(report),
        "generated_at": _match(
            r"Generated:\s+([0-9T:+.-]+)",
            text,
            label="generated time",
        ),
        "tool_count": _match_int(r"Tool count:\s+(\d+)", text, label="tool count"),
        "scenario_count": _match_int(
            r"Scenario count:\s+(\d+)",
            text,
            label="scenario count",
        ),
        "static_coverage_score": score,
        "benchmark_score": _match(
            r"Benchmark score:\s+(.+)",
            text,
            label="benchmark score",
        ),
        "average_toon_savings": _match(
            r"Average TOON savings vs pretty JSON:\s+([0-9.]+%)",
            text,
            label="average TOON savings",
        ),
        "executable_policy_gates": []
        if executable_policy_gates == "none"
        else [item.strip() for item in executable_policy_gates.split(",")],
        "untrusted_write_tools": []
        if untrusted_write_tools == "none"
        else [item.strip() for item in untrusted_write_tools.split(",")],
        "trusted_wrappers": []
        if trusted_wrappers == "none"
        else [item.strip() for item in trusted_wrappers.split(",")],
        "top_recommendations": recommendations[:5],
    }


@app.callback(invoke_without_command=True)
def harness_home(ctx: typer.Context):
    """Show content-first local harness readiness when no subcommand is given."""
    if ctx.invoked_subcommand is None:
        _emit(_eval_summary(_DEFAULT_EVAL_REPORT))


@app.command("readiness")
def readiness(
    report: Path = typer.Option(
        _DEFAULT_READINESS_REPORT,
        "--report",
        help="Path to a generated readiness markdown report.",
    ),
):
    """Summarize the latest local readiness artifact as AXI-style TOON."""
    _emit(_readiness_summary(report))


@app.command("eval")
def eval_summary(
    report: Path = typer.Option(
        _DEFAULT_EVAL_REPORT,
        "--report",
        help="Path to a generated eval markdown report.",
    ),
):
    """Summarize the latest local eval artifact as AXI-style TOON."""
    _emit(_eval_summary(report))


@app.command("preflight")
def preflight(
    tenant_id: str = typer.Option("staging-validator", "--tenant-id"),
    environment: str = typer.Option("staging", "--environment"),
    target_kind: str = typer.Option("container", "--target-kind"),
    target_id: str = typer.Option("raava-alpha", "--target-id"),
    action_type: str = typer.Option("runtime_config_patch", "--action-type"),
    risk_class: str = typer.Option("proposal_write", "--risk-class"),
    evidence: list[str] | None = typer.Option(
        None,
        "--evidence",
        help="Mark local evidence as present. Repeat for multiple values.",
    ),
):
    """Run a local-only proposal preflight summary using the MCP draft contract."""
    from raava import mcp_server

    provided_evidence = _normalize_evidence(evidence)
    draft = mcp_server.change_request_create(
        tenant_id=tenant_id,
        environment=environment,
        target_kind=target_kind,
        target_id=target_id,
        action_type=action_type,
        risk_class=risk_class,
        policy_decision={"write_path": "local_cli_preflight"},
    )
    required_evidence = draft["change_request"]["required_evidence"]
    missing = _missing_evidence(required_evidence, provided_evidence)

    _emit(
        {
            "kind": "harness.preflight",
            "verdict": "ready" if not missing else "blocked",
            "submission_target": draft["submission_target"],
            "status": draft["status"],
            "tenant_id": tenant_id,
            "environment": environment,
            "target_kind": target_kind,
            "target_id": target_id,
            "action_type": action_type,
            "risk_class": risk_class,
            "required_evidence": required_evidence,
            "provided_evidence": provided_evidence,
            "missing_evidence": missing,
            "trusted_wrapper": "change_request_create",
            "next_steps": draft["next_steps"],
        }
    )


@app.command("diff-proposal")
def diff_proposal(
    container_id: str = typer.Argument(..., help="Target container ID"),
    tenant_id: str = typer.Option("staging-validator", "--tenant-id"),
    environment: str = typer.Option("staging", "--environment"),
    env: str | None = typer.Option(
        None, "--env", help="JSON object for env overrides"
    ),
    config: str | None = typer.Option(
        None, "--config", help="JSON object for config overrides"
    ),
    current_state: str | None = typer.Option(
        None, "--current-state", help="JSON object used to compute current state hash"
    ),
    desired_state: str | None = typer.Option(
        None, "--desired-state", help="JSON object used to compute desired state hash"
    ),
    evidence: list[str] | None = typer.Option(
        None,
        "--evidence",
        help="Mark local evidence as present. Repeat for multiple values.",
    ),
):
    """Prepare a local-only runtime config diff proposal summary."""
    from raava import mcp_server

    env_payload = _parse_json_option(env, "--env")
    config_payload = _parse_json_option(config, "--config")
    current_payload = _parse_json_option(current_state, "--current-state")
    desired_payload = _parse_json_option(desired_state, "--desired-state")
    provided_evidence = _normalize_evidence(evidence)
    diff_payload = {}
    if env_payload:
        diff_payload["env"] = env_payload
    if config_payload:
        diff_payload["config"] = config_payload

    proposal = mcp_server.change_request_runtime_config_patch(
        tenant_id=tenant_id,
        environment=environment,
        container_id=container_id,
        env=env_payload or None,
        config=config_payload or None,
        current_state_hash=_stable_hash(current_payload) if current_payload else None,
        desired_state_hash=_stable_hash(desired_payload or diff_payload)
        if (desired_payload or diff_payload)
        else None,
        staging_evidence={"source": "local_cli"}
        if "staging_evidence" in provided_evidence
        else None,
        rollback_plan={"type": "previous_runtime_config", "tool": "runtime_config_show"}
        if "rollback_plan" in provided_evidence
        else None,
        verification_plan={"tool": "runtime_config_show", "target": container_id}
        if "verification_plan" in provided_evidence
        else None,
    )
    request = proposal["change_request"]
    missing = _missing_evidence(request["required_evidence"], provided_evidence)

    _emit(
        {
            "kind": "harness.diff_proposal",
            "verdict": "draft" if not missing else "needs_evidence",
            "proposal_status": proposal["status"],
            "submission_target": proposal["submission_target"],
            "tenant_id": tenant_id,
            "environment": environment,
            "target_id": container_id,
            "tool_name": request["tool_name"],
            "diff_keys": sorted(diff_payload),
            "diff_preview": {
                "env_keys": sorted(env_payload),
                "config_keys": sorted(config_payload),
            },
            "required_evidence": request["required_evidence"],
            "provided_evidence": provided_evidence,
            "missing_evidence": missing,
            "current_state_hash": request["current_state_hash"],
            "desired_state_hash": request["desired_state_hash"],
            "approval_binding": proposal["approval_binding"],
            "next_steps": proposal["next_steps"],
        }
    )
