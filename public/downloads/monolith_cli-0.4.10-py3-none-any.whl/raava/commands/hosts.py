"""Monolith-managed host commands."""

from __future__ import annotations

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_hosts():
    """List hosts that back Monolith-managed runtimes."""
    data = client.get("/hosts")
    rows = data.get("hosts", []) if isinstance(data, dict) else []
    display.table(
        rows,
        [
            ("Provider", "provider"),
            ("Host", "host"),
            ("Zone", "zone"),
            ("Runtimes", "managed_runtime_count"),
            ("Running", "running_runtime_count"),
            ("Scope", "scope"),
        ],
        title="Monolith Hosts",
    )


@app.command("show")
def show_host(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Show the host for one Monolith-managed runtime."""
    data = client.get(f"/containers/{runtime}/host")
    display.detail(data, title=f"Monolith Host: {runtime}")
