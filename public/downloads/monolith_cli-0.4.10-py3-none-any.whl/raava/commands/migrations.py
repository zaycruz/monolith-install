"""Hermes/OpenClaw migration operations."""

from __future__ import annotations

import time

import click
import typer

from raava import client, display
from raava.commands._safety import warn_deprecated_direct_write

app = typer.Typer(no_args_is_help=True)


def _render_operation(operation: dict[str, object], title: str = "Operation") -> None:
    summary: dict[str, object] = {
        "id": operation.get("id") or operation.get("operation_id"),
        "type": operation.get("type"),
        "status": operation.get("status"),
        "source_container_id": operation.get("source_container_id"),
        "target_container_id": operation.get("target_container_id"),
        "current_step": operation.get("current_step"),
        "started_at": operation.get("started_at"),
        "completed_at": operation.get("completed_at"),
        "stream_url": operation.get("stream_url"),
    }
    display.detail(summary, title=title)

    steps = operation.get("steps") or []
    if isinstance(steps, list) and steps:
        display.table(
            steps,
            [("Step", "name"), ("Status", "status"), ("Detail", "detail")],
            title="Migration Steps",
        )

    result = operation.get("result")
    if isinstance(result, dict) and result:
        display.detail(result, title="Result")
    elif result is not None:
        display.console.print(result)

    error = operation.get("error")
    if isinstance(error, dict) and error:
        display.detail(error, title="Error")
    elif error:
        display.print_error(str(error))


def _wait_for_operation(
    operation_id: str, interval: float = 1.5, timeout: float = 300.0
) -> dict[str, object]:
    """Poll an operation until it reaches a terminal state or the timeout expires."""
    started_at = time.monotonic()
    with display.console.status(f"Waiting for operation {operation_id}..."):
        while True:
            operation = client.get(f"/operations/{operation_id}")
            if operation.get("status") in {"succeeded", "failed", "cancelled"}:
                return operation
            if time.monotonic() - started_at >= timeout:
                raise TimeoutError(
                    f"Operation {operation_id} did not finish within {timeout:.0f}s"
                )
            time.sleep(interval)


def _raise_if_operation_unsuccessful(operation: dict[str, object]) -> None:
    if operation.get("status") != "succeeded":
        raise typer.Exit(1)


def _build_migration_payload(
    command: str,
    dry_run: bool,
    preset: str,
    install_hermes: bool,
    overwrite: bool,
    workspace_target: str | None,
    skill_conflict: str,
    yes: bool,
    migrate_secrets: bool,
    start_hermes_after: bool,
    require_stage: str,
    source_root: str,
    target_root: str,
    hermes_version: str | None,
) -> dict[str, object]:
    payload: dict[str, object] = {
        "command": command,
        "dry_run": dry_run,
        "preset": preset,
        "install_hermes": install_hermes,
        "overwrite": overwrite,
        "skill_conflict": skill_conflict,
        "yes": yes,
        "migrate_secrets": migrate_secrets,
        "start_hermes_after": start_hermes_after,
        "require_stage": require_stage,
        "source_root": source_root,
        "target_root": target_root,
    }
    if workspace_target is not None:
        payload["workspace_target"] = workspace_target
    if hermes_version is not None:
        payload["hermes_version"] = hermes_version
    return payload


@app.command("hermes")
def migrate_hermes(
    container_id: str = typer.Argument(..., help="Staged clone container ID"),
    command: str = typer.Option(
        "claw",
        "--command",
        click_type=click.Choice(["claw", "honcho", "both"]),
        help="Migration flow to run",
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run/--apply",
        help="Preview the migration or execute it for real",
    ),
    preset: str = typer.Option(
        "full",
        "--preset",
        click_type=click.Choice(["full", "user-data"]),
        help="Hermes migration preset",
    ),
    install_hermes: bool = typer.Option(
        True,
        "--install-hermes/--skip-install-hermes",
        help="Install Hermes first if it is missing",
    ),
    overwrite: bool = typer.Option(
        False, "--overwrite", help="Overwrite conflicting files when supported"
    ),
    workspace_target: str | None = typer.Option(
        None, "--workspace-target", help="Where AGENTS.md should be written"
    ),
    skill_conflict: str = typer.Option(
        "skip",
        "--skill-conflict",
        click_type=click.Choice(["skip", "overwrite", "rename"]),
        help="How imported skill name collisions should be handled",
    ),
    yes: bool = typer.Option(
        True, "--yes/--prompt", help="Skip Hermes confirmation prompts"
    ),
    migrate_secrets: bool = typer.Option(
        False,
        "--migrate-secrets/--no-migrate-secrets",
        help="Include API keys and platform secrets when supported",
    ),
    start_hermes_after: bool = typer.Option(
        False,
        "--start-hermes-after/--no-start-hermes-after",
        help="Start hermes-gateway after a non-dry-run migration",
    ),
    require_stage: str = typer.Option(
        "staging",
        "--require-stage",
        click_type=click.Choice(["production", "staging", "development", "recovery"]),
        help="Required source stage before migration is allowed",
    ),
    source_root: str = typer.Option(
        "/home/agent/.openclaw",
        "--source-root",
        help="OpenClaw source root inside the container",
    ),
    target_root: str = typer.Option(
        "/home/agent/.hermes",
        "--target-root",
        help="Hermes target root inside the container",
    ),
    hermes_version: str | None = typer.Option(
        None,
        "--hermes-version",
        help="Exact Hermes git ref or channel to install when installation is needed",
    ),
    wait: bool = typer.Option(
        False,
        "--wait",
        help="Poll until the operation finishes and then print the final result",
    ),
):
    """Run Hermes migration on a staged clone."""
    resolved = client.resolve_container_id(container_id)
    payload = _build_migration_payload(
        command=command,
        dry_run=dry_run,
        preset=preset,
        install_hermes=install_hermes,
        overwrite=overwrite,
        workspace_target=workspace_target,
        skill_conflict=skill_conflict,
        yes=yes,
        migrate_secrets=migrate_secrets,
        start_hermes_after=start_hermes_after,
        require_stage=require_stage,
        source_root=source_root,
        target_root=target_root,
        hermes_version=hermes_version,
    )
    warn_deprecated_direct_write("migrations hermes", "Fleet Manager migration approval")
    accepted = client.post(f"/containers/{resolved}/migrations/hermes", json=payload)
    _render_operation(accepted, title=f"Hermes Migration Queued: {resolved}")

    if wait:
        try:
            operation = _wait_for_operation(accepted["operation_id"])
        except TimeoutError as exc:
            display.print_error(str(exc))
            raise typer.Exit(1) from exc
        _render_operation(operation, title=f"Hermes Migration Result: {resolved}")
        _raise_if_operation_unsuccessful(operation)


@app.command("clone-hermes")
def clone_and_migrate_hermes(
    container_id: str = typer.Argument(..., help="Source OpenClaw container ID"),
    target_name: str = typer.Argument(..., help="Name for the staged clone target"),
    command: str = typer.Option(
        "claw",
        "--command",
        click_type=click.Choice(["claw", "honcho", "both"]),
        help="Migration flow to run after clone",
    ),
    dry_run: bool = typer.Option(
        True,
        "--dry-run/--apply",
        help="Preview the migration or execute it for real",
    ),
    preset: str = typer.Option(
        "full",
        "--preset",
        click_type=click.Choice(["full", "user-data"]),
        help="Hermes migration preset",
    ),
    install_hermes: bool = typer.Option(
        True,
        "--install-hermes/--skip-install-hermes",
        help="Install Hermes first if it is missing",
    ),
    overwrite: bool = typer.Option(
        False, "--overwrite", help="Overwrite conflicting files when supported"
    ),
    workspace_target: str | None = typer.Option(
        None, "--workspace-target", help="Where AGENTS.md should be written"
    ),
    skill_conflict: str = typer.Option(
        "skip",
        "--skill-conflict",
        click_type=click.Choice(["skip", "overwrite", "rename"]),
        help="How imported skill name collisions should be handled",
    ),
    yes: bool = typer.Option(
        True, "--yes/--prompt", help="Skip Hermes confirmation prompts"
    ),
    migrate_secrets: bool = typer.Option(
        False,
        "--migrate-secrets/--no-migrate-secrets",
        help="Include API keys and platform secrets when supported",
    ),
    start_hermes_after: bool = typer.Option(
        False,
        "--start-hermes-after/--no-start-hermes-after",
        help="Start hermes-gateway after a non-dry-run migration",
    ),
    require_stage: str = typer.Option(
        "staging",
        "--require-stage",
        click_type=click.Choice(["production", "staging", "development", "recovery"]),
        help="Stage the cloned container must be in before migration is allowed",
    ),
    stage: str = typer.Option(
        "staging",
        "--stage",
        click_type=click.Choice(["production", "staging", "development", "recovery"]),
        help="Stage to assign to the cloned container",
    ),
    source_root: str = typer.Option(
        "/home/agent/.openclaw",
        "--source-root",
        help="OpenClaw source root inside the cloned container",
    ),
    target_root: str = typer.Option(
        "/home/agent/.hermes",
        "--target-root",
        help="Hermes target root inside the cloned container",
    ),
    hermes_version: str | None = typer.Option(
        None,
        "--hermes-version",
        help="Exact Hermes git ref or channel to install when installation is needed",
    ),
    require_source_state: str = typer.Option(
        "STOPPED",
        "--require-source-state",
        click_type=click.Choice(["STOPPED", "ANY"]),
        help="Required source state before cloning",
    ),
    network_mode: str = typer.Option(
        "isolated",
        "--network-mode",
        click_type=click.Choice(["shared", "isolated"]),
        help="Network mode for the staged clone",
    ),
    disable_agent_autostart: bool = typer.Option(
        True,
        "--disable-agent-autostart/--enable-agent-autostart",
        help="Keep the cloned agent runtime from auto-starting",
    ),
    disable_integrations: bool = typer.Option(
        True,
        "--disable-integrations/--enable-integrations",
        help="Prevent the clone from using integrations by default",
    ),
    stage_notes: str | None = typer.Option(
        None, "--stage-notes", help="Operator notes for the staged clone"
    ),
    expires_at: str | None = typer.Option(
        None, "--expires-at", help="Optional expiry timestamp for the staged clone"
    ),
    verify_after: bool = typer.Option(
        True,
        "--verify-after/--skip-verify",
        help="Run simple post-migration verification checks",
    ),
    verify_check: list[str] | None = typer.Option(
        None,
        "--verify-check",
        help="Verification check to run (repeatable). Defaults to openclaw_present and hermes_installed.",
    ),
    wait: bool = typer.Option(
        False,
        "--wait",
        help="Poll until the operation finishes and then print the final result",
    ),
):
    """Clone a source container and run Hermes migration on the staged copy."""
    resolved = client.resolve_container_id(container_id)
    migration = _build_migration_payload(
        command=command,
        dry_run=dry_run,
        preset=preset,
        install_hermes=install_hermes,
        overwrite=overwrite,
        workspace_target=workspace_target,
        skill_conflict=skill_conflict,
        yes=yes,
        migrate_secrets=migrate_secrets,
        start_hermes_after=start_hermes_after,
        require_stage=require_stage,
        source_root=source_root,
        target_root=target_root,
        hermes_version=hermes_version,
    )
    clone: dict[str, object] = {
        "stage": stage,
        "require_source_state": require_source_state,
        "network_mode": network_mode,
        "disable_agent_autostart": disable_agent_autostart,
        "disable_integrations": disable_integrations,
    }
    if stage_notes is not None:
        clone["stage_notes"] = stage_notes
    if expires_at is not None:
        clone["expires_at"] = expires_at

    payload: dict[str, object] = {
        "target_name": target_name,
        "clone": clone,
        "migration": migration,
        "verify_after": verify_after,
    }
    if verify_check:
        payload["verify_checks"] = verify_check

    warn_deprecated_direct_write("migrations clone-hermes", "Fleet Manager migration approval")
    accepted = client.post(
        f"/containers/{resolved}/clone-and-migrate/hermes", json=payload
    )
    _render_operation(accepted, title=f"Clone & Hermes Migration Queued: {resolved}")

    if wait:
        try:
            operation = _wait_for_operation(accepted["operation_id"])
        except TimeoutError as exc:
            display.print_error(str(exc))
            raise typer.Exit(1) from exc
        _render_operation(
            operation, title=f"Clone & Hermes Migration Result: {target_name}"
        )
        _raise_if_operation_unsuccessful(operation)


@app.command("status")
def operation_status(
    operation_id: str = typer.Argument(..., help="Migration operation ID"),
):
    """Show current migration operation status and result."""
    operation = client.get(f"/operations/{operation_id}")
    _render_operation(operation, title=f"Operation: {operation_id}")


@app.command("stream")
def stream_operation(
    operation_id: str = typer.Argument(..., help="Migration operation ID"),
):
    """Stream migration operation events until interrupted."""
    display.console.print(
        f"[dim]Streaming migration events for {operation_id}... (Ctrl+C to stop)[/dim]"
    )
    try:
        for event in client.stream_sse(f"/operations/{operation_id}/stream"):
            event_type = event.get("type", "event")
            step = event.get("step") or "—"
            message = event.get("message") or ""
            display.console.print(f"[bold]{event_type}[/] step={step} {message}")
            data = event.get("data")
            if data is not None:
                if isinstance(data, dict):
                    display.detail(data, title="Event Data")
                else:
                    display.console.print(data)
    except KeyboardInterrupt:
        display.console.print("\n[dim]Stream closed[/dim]")
