"""Runtime configuration management."""

import json

import click
import typer

from raava import client, display
from raava.commands._safety import warn_deprecated_direct_write

app = typer.Typer(no_args_is_help=True)


@app.command("show")
def show_config(container_id: str = typer.Argument(..., help="Container ID")):
    """Show effective and pending runtime config."""
    data = client.get(f"/containers/{container_id}/runtime-config")
    display.detail(data, title=f"Runtime Config: {container_id}")


@app.command("validate")
def validate_config(container_id: str = typer.Argument(..., help="Container ID")):
    """Deprecated direct validation of a pending runtime config patch."""
    warn_deprecated_direct_write("runtime validate", "Fleet Manager validation evidence")
    data = client.post(f"/containers/{container_id}/runtime-config/validate", json={})
    display.detail(data, title=f"Validation Result: {container_id}")


@app.command("patch")
def patch_config(
    container_id: str = typer.Argument(..., help="Container ID"),
    env: str | None = typer.Option(
        None, "--env", help="JSON string for env overrides"
    ),
    config: str | None = typer.Option(
        None, "--config", help="JSON string for config overrides"
    ),
):
    """Deprecated direct runtime config patch staging."""
    warn_deprecated_direct_write("runtime patch", "Fleet Manager runtime_config_patch")
    payload = {}
    try:
        if env:
            payload["env"] = json.loads(env)
    except json.JSONDecodeError as e:
        display.print_error(f"Invalid JSON for --env: {e}")
        raise typer.Exit(1)

    try:
        if config:
            payload["config"] = json.loads(config)
    except json.JSONDecodeError as e:
        display.print_error(f"Invalid JSON for --config: {e}")
        raise typer.Exit(1)

    data = client.patch(f"/containers/{container_id}/runtime-config", json=payload)
    display.detail(data, title=f"Config Patched: {container_id}")


@app.command("apply")
def apply_config(
    container_id: str = typer.Argument(..., help="Container ID"),
    service: str = typer.Option(
        "gateway",
        "--service",
        click_type=click.Choice(["gateway", "agent"]),
        help="Target service to restart/reload",
    ),
    action: str = typer.Option(
        "restart",
        "--action",
        click_type=click.Choice(["restart", "reload"]),
        help="Service action (restart or reload)",
    ),
):
    """Deprecated direct runtime config apply for operator break-glass."""
    warn_deprecated_direct_write("runtime apply", "Fleet Manager runtime_config_apply")
    payload = {"service": service, "action": action}
    data = client.post(f"/containers/{container_id}/runtime-config/apply", json=payload)
    display.detail(data, title=f"Config Applied: {container_id}")
