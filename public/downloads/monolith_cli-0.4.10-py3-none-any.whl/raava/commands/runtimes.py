"""Curated Monolith runtime incident commands."""

from __future__ import annotations

import click
import typer

from raava import client, display
from raava.commands._runtime_common import (
    container_rows,
    print_lines,
    runtime_columns,
    success_or_json,
)
from raava.commands._safety import warn_deprecated_direct_write

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_runtimes():
    """List Monolith-managed runtimes."""
    display.table(container_rows(), runtime_columns(), title="Monolith Runtimes")


@app.command("show")
def show_runtime(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Show runtime detail."""
    data = client.get(f"/containers/{runtime}")
    display.detail(data, title=f"Monolith Runtime: {data.get('id') or runtime}")


@app.command("status")
def runtime_status(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Show runtime status and metadata."""
    data = client.get(f"/containers/{runtime}")
    display.detail(data, title=f"Runtime Status: {runtime}")


@app.command("health")
def runtime_health(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Show latest runtime health."""
    data = client.get(f"/containers/{runtime}/health")
    display.detail(data, title=f"Runtime Health: {runtime}")


@app.command("doctor")
def runtime_doctor(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Run Monolith runtime diagnostics."""
    data = client.get(f"/containers/{runtime}/doctor")
    display.detail(data, title=f"Runtime Doctor: {runtime}")


@app.command("logs")
def runtime_logs(
    runtime: str = typer.Argument(..., help="Runtime ID or agent name"),
    service: str | None = typer.Option(
        None, "--service", help="Optional logical service, e.g. gateway or agent"
    ),
    lines: int = typer.Option(100, "--lines", "-n", help="Number of log lines"),
    since: str | None = typer.Option(None, "--since", "-s", help="Time filter"),
):
    """Fetch agent or service logs for a Monolith runtime."""
    params: dict[str, object] = {"lines": lines, "tail": lines}
    if since:
        params["since"] = since
    path = (
        f"/containers/{runtime}/services/{service}/logs"
        if service
        else f"/containers/{runtime}/agent/logs"
    )
    data = client.get(path, params=params)
    print_lines(data)


@app.command("config")
def runtime_config(
    runtime: str = typer.Argument(..., help="Runtime ID or agent name"),
    validate: bool = typer.Option(
        False, "--validate", help="Validate pending runtime config"
    ),
):
    """Inspect or validate bounded runtime config."""
    if validate:
        data = client.post(f"/containers/{runtime}/runtime-config/validate", json={})
        display.detail(data, title=f"Runtime Config Validation: {runtime}")
        return
    data = client.get(f"/containers/{runtime}/runtime-config")
    display.detail(data, title=f"Runtime Config: {runtime}")


@app.command("apply-config")
def apply_runtime_config(
    runtime: str = typer.Argument(..., help="Runtime ID or agent name"),
    service: str = typer.Option(
        "gateway",
        "--service",
        click_type=click.Choice(["gateway", "agent"]),
        help="Target service",
    ),
    action: str = typer.Option(
        "restart",
        "--action",
        click_type=click.Choice(["restart", "reload"]),
        help="Service action",
    ),
):
    """Apply pending runtime config through Monolith."""
    warn_deprecated_direct_write(
        "runtimes apply-config", "Fleet Manager runtime_config_apply"
    )
    data = client.post(
        f"/containers/{runtime}/runtime-config/apply",
        json={"service": service, "action": action},
    )
    display.detail(data, title=f"Runtime Config Applied: {runtime}")


@app.command("restart")
def restart_runtime(
    runtime: str = typer.Argument(..., help="Runtime ID or agent name"),
    target: str = typer.Option(
        "agent",
        "--target",
        click_type=click.Choice(["agent", "gateway", "runtime"]),
        help="Restart target",
    ),
):
    """Restart an agent, gateway service, or full Monolith runtime."""
    warn_deprecated_direct_write(
        "runtimes restart", "Fleet Manager approval or a named break-glass reason"
    )
    if target == "runtime":
        data = client.post(f"/containers/{runtime}/restart")
        success_or_json(data or {}, f"Runtime restarted for {runtime}")
        return
    if target == "agent":
        data = client.post(f"/containers/{runtime}/agent/restart")
        success_or_json(data or {}, f"Agent restarted for {runtime}")
        return
    data = client.post(f"/containers/{runtime}/services/gateway/restart")
    success_or_json(data or {}, f"Gateway restarted for {runtime}")


@app.command("snapshots")
def runtime_snapshots(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """List runtime snapshots."""
    data = client.get(f"/containers/{runtime}/snapshots")
    rows = data if isinstance(data, list) else data.get("snapshots", [])
    display.table(
        rows,
        [("Name", "name"), ("Created", "created_at"), ("Stateful", "stateful")],
        title=f"Runtime Snapshots: {runtime}",
    )


@app.command("backup")
def runtime_backup(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Show runtime backup posture."""
    data = client.get(f"/containers/{runtime}/backup")
    display.detail(data, title=f"Runtime Backup: {runtime}")


@app.command("host")
def runtime_host(runtime: str = typer.Argument(..., help="Runtime ID or agent name")):
    """Show the Monolith-managed host for a runtime."""
    data = client.get(f"/containers/{runtime}/host")
    display.detail(data, title=f"Runtime Host: {runtime}")
