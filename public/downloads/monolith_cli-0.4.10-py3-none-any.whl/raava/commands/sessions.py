"""WebSocket terminal session management."""

import typer

from raava import client, display
from raava.commands._safety import warn_deprecated_direct_write

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_sessions():
    """List active terminal sessions."""
    data = client.get("/sessions")
    if not data:
        display.print_success("No active sessions")
        return
    cols = [
        ("ID", "id"),
        ("Container", "container_id"),
        ("Type", "type"),
        ("Started", "started_at"),
    ]
    display.table(data, cols, title="Active Sessions")


@app.command()
def kill(session_id: str = typer.Argument(..., help="Session ID")):
    """Deprecated direct session kill for operator break-glass."""
    warn_deprecated_direct_write("sessions kill", "the supported terminal session workflow")
    client.delete(f"/sessions/{session_id}")
    display.print_success(f"Session {session_id} killed")
