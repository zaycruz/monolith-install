"""Configuration management for the Monolith CLI."""

import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "monolith"
CONFIG_FILE = CONFIG_DIR / "config.toml"

VALID_KEYS = {"api_url", "timeout", "output", "api_key"}
DEFAULT_API_URL = "http://127.0.0.1:8400"
KNOWN_ENVS = {"local", "staging", "prod"}

_defaults = {
    "api_url": DEFAULT_API_URL,
    "timeout": 30,
    "output": "table",
    "api_key": "",
    "active_env": "",
}


def load_toml(path: Path, default_data: dict | None = None) -> dict:
    if not path.exists():
        return dict(default_data) if default_data else {}
    try:
        import tomllib
        with open(path, "rb") as f:
            data = tomllib.load(f)
        if default_data:
            merged = dict(default_data)
            merged.update(data)
            return merged
        return dict(data) if isinstance(data, dict) else {}
    except Exception:
        return dict(default_data) if default_data else {}


def save_toml(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.parent.chmod(0o700)
    except OSError:
        pass
    lines = []
    for k, v in data.items():
        if isinstance(v, bool):
            lines.append(f"{k} = {'true' if v else 'false'}")
        elif isinstance(v, int):
            lines.append(f"{k} = {v}")
        elif isinstance(v, float):
            lines.append(f"{k} = {v}")
        elif isinstance(v, str):
            escaped = v.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k} = "{escaped}"')
        else:
            lines.append(f'{k} = "{v}"')
    path.write_text("\n".join(lines) + "\n")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def normalize_env(env: str) -> str:
    value = (env or "").strip().lower()
    if not value:
        raise ValueError("Environment name cannot be empty")
    if not all(ch.isalnum() or ch in {"-", "_"} for ch in value):
        raise ValueError("Environment names may only contain letters, numbers, '-' and '_'")
    return value


def profile_file(env: str) -> Path:
    safe = normalize_env(env)
    return CONFIG_DIR / f"config.{safe}.toml"


def _load_config() -> dict:
    root = load_toml(CONFIG_FILE, _defaults)
    raw_active_env = _active_env(root)
    try:
        active_env = normalize_env(raw_active_env) if raw_active_env else ""
    except ValueError:
        active_env = ""
        root["active_env"] = ""
    if not active_env:
        return root

    profile = load_toml(profile_file(active_env), {})
    merged = dict(_defaults)
    merged.update(profile)
    merged["active_env"] = active_env
    return merged


def _save_config(data: dict):
    active_env = str(data.get("active_env") or "").strip()
    if not active_env:
        save_toml(CONFIG_FILE, data)
        return

    active_env = normalize_env(active_env)
    save_toml(CONFIG_FILE, {"active_env": active_env})

    profile_data = {k: v for k, v in data.items() if k != "active_env"}
    save_toml(profile_file(active_env), profile_data)


def _active_env(root: dict) -> str:
    return (
        os.environ.get("MONOLITH_ENV")
        or os.environ.get("RAAVA_ENV")
        or str(root.get("active_env") or "")
    ).strip()


_config = _load_config()


def active_env() -> str:
    return str(_config.get("active_env") or "")


def use_env(env: str) -> dict:
    """Switch the active profile, creating it from current values if absent."""
    selected = normalize_env(env)
    profile = load_toml(profile_file(selected), {})
    if not profile:
        profile = {k: v for k, v in _config.items() if k != "active_env"}
        if selected == "local":
            profile["api_url"] = DEFAULT_API_URL
        elif selected == "staging":
            profile["api_url"] = "https://raava-fleet-api-staging-lmbn6fkciq-ue.a.run.app"
        elif selected == "prod":
            profile["api_url"] = ""
            profile["api_key"] = ""

    new_config = dict(_defaults)
    new_config.update(profile)
    new_config["active_env"] = selected
    _config.clear()
    _config.update(new_config)
    _save_config(_config)
    return dict(_config)


def list_envs() -> list[dict]:
    envs = set(KNOWN_ENVS)
    if CONFIG_DIR.exists():
        for path in CONFIG_DIR.glob("config.*.toml"):
            envs.add(path.stem.removeprefix("config."))
    current = active_env()
    rows = []
    for env in sorted(envs):
        data = load_toml(profile_file(env), {})
        rows.append(
            {
                "env": env,
                "active": "yes" if env == current else "",
                "api_url": data.get("api_url", ""),
                "configured": "yes" if data.get("api_url") or data.get("api_key") else "",
            }
        )
    return rows


def get(key: str, default=None):
    suffix = key.upper()
    for env_key in (f"MONOLITH_{suffix}", f"RAAVA_{suffix}"):
        env_val = os.environ.get(env_key)
        if env_val is not None:
            return env_val
    return _config.get(key, default)


def set_value(key: str, value: str):
    # Type coercion
    if value.lower() in ("true", "false"):
        value = value.lower() == "true"
    else:
        try:
            value = int(value)
        except ValueError:
            try:
                value = float(value)
            except ValueError:
                pass
    _config[key] = value
    _save_config(_config)


def delete_key(key: str) -> bool:
    if key in _config and key not in _defaults:
        del _config[key]
        _save_config(_config)
        return True
    elif key in _config:
        _config[key] = _defaults[key]
        _save_config(_config)
        return True
    return False


def all_config() -> dict:
    return dict(_config)
