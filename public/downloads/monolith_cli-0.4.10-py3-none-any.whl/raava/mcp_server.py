"""Monolith Fleet API — MCP Server.

Exposes fleet management tools to Claude Code and other MCP clients.
Run via: python -m raava.mcp_server
Or register in .mcp.json / settings.json
"""

from __future__ import annotations

import hashlib
import csv
import json
import os
import secrets
import time
from collections.abc import Iterable
from io import StringIO
from typing import Any, Callable, Literal

import httpx
from mcp.server.auth.provider import AccessToken
from mcp.server.auth.settings import AuthSettings
from mcp.server.fastmcp import FastMCP
from starlette.requests import Request
from starlette.responses import JSONResponse

from raava import agent_contract as agent_contract_model
from raava import agent_diagnostics
from raava import config
from raava.config import DEFAULT_API_URL


McpTransport = Literal["stdio", "sse", "streamable-http"]
ChangeRequestRiskClass = Literal[
    "read",
    "sensitive_read",
    "proposal_write",
    "operational_write",
    "high_risk_write",
    "break_glass",
]
LOCAL_DEBUG_ENVIRONMENTS = {"local", "dev", "development", "test"}


class StaticBearerVerifier:
    """Verify the bearer token used by hosted MCP transports."""

    async def verify_token(self, token: str) -> AccessToken | None:
        expected = os.environ.get("MONOLITH_MCP_AUTH_TOKEN", "")
        if not expected or not secrets.compare_digest(token, expected):
            return None
        return AccessToken(
            token=token,
            client_id=os.environ.get("MONOLITH_MCP_CLIENT_ID", "monolith-mcp-client"),
            scopes=["mcp"],
        )


def _server_port() -> int:
    value = os.environ.get("PORT") or os.environ.get("MONOLITH_MCP_PORT") or "8000"
    return int(value)


def _auth_settings() -> tuple[AuthSettings | None, StaticBearerVerifier | None]:
    if not os.environ.get("MONOLITH_MCP_AUTH_TOKEN"):
        return None, None

    issuer_url = os.environ.get("MONOLITH_MCP_ISSUER_URL", "https://thisismonolith.com")
    resource_url = os.environ.get(
        "MONOLITH_MCP_RESOURCE_URL",
        "https://mcp.thisismonolith.com",
    )
    return (
        AuthSettings(
            issuer_url=issuer_url,
            resource_server_url=resource_url,
            required_scopes=["mcp"],
            service_documentation_url="https://thisismonolith.com",
        ),
        StaticBearerVerifier(),
    )


def _normalize_transport(value: str | None) -> McpTransport:
    normalized = (value or "stdio").strip().lower().replace("_", "-")
    if normalized in {"http", "streamable-http"}:
        return "streamable-http"
    if normalized in {"sse", "stdio"}:
        return normalized
    raise ValueError(
        "MONOLITH_MCP_TRANSPORT must be one of: stdio, sse, streamable-http"
    )


def _require_hosted_auth(transport: McpTransport) -> None:
    if transport == "stdio":
        return
    if os.environ.get("MONOLITH_MCP_AUTH_TOKEN"):
        return
    if os.environ.get("MONOLITH_MCP_ALLOW_UNAUTH_HTTP") == "1":
        runtime_env = _configured_mcp_environment()
        if runtime_env in LOCAL_DEBUG_ENVIRONMENTS:
            return
    raise RuntimeError(
        "Hosted MCP transports require MONOLITH_MCP_AUTH_TOKEN. "
        "Set MONOLITH_MCP_ALLOW_UNAUTH_HTTP=1 only when MONOLITH_MCP_ENVIRONMENT, "
        "MONOLITH_ENVIRONMENT, or MONOLITH_MCP_DEFAULT_ENVIRONMENT is local/dev/development/test."
    )


auth_settings, token_verifier = _auth_settings()

server = FastMCP(
    name="monolith-fleet",
    instructions=(
        "Monolith Fleet API — agent-first MCP surface for operating AI fleets. "
        "Start with agent_contract() or agent_workflow_guide(), prefer compact "
        "read tools for context, and route writes through Fleet Manager proposal, "
        "approval, and execution tools."
    ),
    host=os.environ.get("MONOLITH_MCP_HOST", "0.0.0.0"),
    port=_server_port(),
    streamable_http_path=os.environ.get("MONOLITH_MCP_PATH", "/mcp"),
    stateless_http=os.environ.get("MONOLITH_MCP_STATELESS_HTTP", "1") != "0",
    auth=auth_settings,
    token_verifier=token_verifier,
)

def _api_url() -> str:
    return (
        os.environ.get("MONOLITH_API_URL")
        or os.environ.get("RAAVA_API_URL")
        or config.get("api_url", "")
        or DEFAULT_API_URL
    )


API_URL = _api_url()
TIMEOUT = 30.0
TOON_VERSION = "TOON:v1"
DIRECT_WRITE_OVERRIDE_ENV = "MONOLITH_MCP_ALLOW_DIRECT_WRITES"
FLEET_MANAGER_ACTION_ROUTE = "POST /api/fleet-manager/actions"
DEFAULT_LIMIT = 25
MAX_LIMIT = 200
MAX_CELL_CHARS = 240
MAX_LOG_LINE_CHARS = 500


@server.custom_route("/health", methods=["GET"], include_in_schema=False)
async def health(_: Request) -> JSONResponse:
    return JSONResponse(
        {
            "status": "ok",
            "service": "monolith-mcp",
            "api_url": API_URL,
            "mcp_path": server.settings.streamable_http_path,
            "auth": bool(os.environ.get("MONOLITH_MCP_AUTH_TOKEN")),
        }
    )


def _clamp_limit(limit: int, default: int = DEFAULT_LIMIT, maximum: int = MAX_LIMIT) -> int:
    if limit <= 0:
        return default
    return min(limit, maximum)


def _select_fields(row: dict[str, Any], fields: Iterable[str]) -> dict[str, Any]:
    return {field: row.get(field) for field in fields}


def _truncate_rows(rows: list[dict[str, Any]], limit: int) -> tuple[list[dict[str, Any]], dict[str, int | bool]]:
    clamped = _clamp_limit(limit)
    visible = rows[:clamped]
    return visible, {
        "returned": len(visible),
        "total": len(rows),
        "truncated": len(rows) > len(visible),
    }


def _truncate_text(value: Any, max_chars: int = MAX_CELL_CHARS) -> str:
    text = "" if value is None else str(value).replace("\r", " ").replace("\n", " ")
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 1] + "…"


def _empty(message: str, next_steps: list[str] | None = None, *, fmt: str = "toon") -> dict[str, Any]:
    return {
        "ok": True,
        "summary": message,
        "format": fmt,
        "data": "",
        "returned": 0,
        "total": 0,
        "truncated": False,
        "help": next_steps or [],
    }


def _toon_table(rows: list[dict[str, Any]], fields: list[str]) -> str:
    if not rows:
        return ""
    output = StringIO()
    writer = csv.writer(output, lineterminator="\n")
    writer.writerow(fields)
    for row in rows:
        values = []
        for field in fields:
            value = row.get(field)
            values.append(f"{value:.1f}" if isinstance(value, float) else _truncate_text(value))
        writer.writerow(values)
    return output.getvalue().rstrip("\n")


def _agent_status(container: dict[str, Any]) -> str:
    health = container.get("health") or {}
    return health.get("agent_status") or container.get("status") or "unknown"


def _health_row(container: dict[str, Any]) -> dict[str, Any]:
    health = container.get("health") or {}
    return {
        "id": container.get("id"),
        "tenant": container.get("tenant") or container.get("tenant_id"),
        "agent": container.get("agent_name"),
        "status": container.get("status"),
        "agent_status": health.get("agent_status"),
        "cpu": health.get("cpu"),
        "mem": health.get("mem"),
        "ip": container.get("ip"),
    }


def _compact_response(
    summary: str,
    rows: list[dict[str, Any]],
    fields: list[str],
    *,
    limit: int = DEFAULT_LIMIT,
    help_text: list[str] | None = None,
) -> dict[str, Any]:
    visible_rows, meta = _truncate_rows(rows, limit)
    compact_rows = [_select_fields(row, fields) for row in visible_rows]
    return {
        "ok": True,
        "summary": summary,
        "format": "toon",
        "data": _toon_table(compact_rows, fields),
        **meta,
        "help": help_text or [],
    }


def _workflow_response(
    *,
    summary: str,
    rows: list[dict[str, Any]],
    fields: list[str],
    evidence: dict[str, Any] | None = None,
    proposals: dict[str, Any] | None = None,
    limit: int = DEFAULT_LIMIT,
    help_text: list[str] | None = None,
) -> dict[str, Any]:
    response = _compact_response(
        summary,
        rows,
        fields,
        limit=limit,
        help_text=help_text,
    )
    response["evidence"] = evidence or {}
    if proposals:
        response["proposals"] = proposals
    return response


def _safe_workflow_call(label: str, fn: Callable[[], Any]) -> dict[str, Any]:
    try:
        return {"ok": True, "value": fn()}
    except httpx.HTTPStatusError as exc:
        detail: Any
        try:
            detail = exc.response.json()
        except ValueError:
            detail = exc.response.text
        return {
            "ok": False,
            "label": label,
            "status_code": exc.response.status_code,
            "error": detail,
        }
    except Exception as exc:
        return {"ok": False, "label": label, "error": str(exc)}


def _call_value(result: dict[str, Any], default: Any) -> Any:
    return result["value"] if result.get("ok") else default


def _containers_from_payload(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        containers = payload.get("containers") or payload.get("items") or []
    else:
        containers = payload
    if isinstance(containers, list):
        return [item for item in containers if isinstance(item, dict)]
    return []


def _container_and_health(detail: dict[str, Any], container_id: str) -> tuple[dict[str, Any], dict[str, Any]]:
    container = detail.get("container") if isinstance(detail.get("container"), dict) else detail
    health = detail.get("health") if isinstance(detail.get("health"), dict) else {}
    return {"id": container.get("id") or container_id, **container}, health


def _tenant_from_container(container: dict[str, Any]) -> str | None:
    return container.get("tenant_id") or container.get("tenant")


def _extract_log_text(log_payload: Any) -> str:
    if isinstance(log_payload, dict):
        value = log_payload.get("data") or log_payload.get("logs") or log_payload.get("lines")
    else:
        value = log_payload
    if isinstance(value, list):
        return "\n".join(str(item) for item in value)
    return "" if value is None else str(value)


def _likely_triage_cause(
    *,
    container: dict[str, Any],
    health: dict[str, Any],
    agent: dict[str, Any],
    logs: str,
) -> str:
    lowered_logs = logs.lower()
    agent_status_value = str(
        agent.get("status")
        or agent.get("agent_status")
        or health.get("agent_status")
        or container.get("status")
        or "unknown"
    ).lower()
    container_status = str(container.get("status") or "unknown").lower()
    if container_status not in {"running", "active"}:
        return "container_not_running"
    if "unauthorized" in lowered_logs or "forbidden" in lowered_logs:
        return "auth_or_allowlist"
    if "traceback" in lowered_logs or "exception" in lowered_logs or "error" in lowered_logs:
        return "recent_log_errors"
    if agent_status_value not in {"active", "running", "healthy"}:
        return "agent_service_unhealthy"
    return "no_obvious_fault"


def _auth_headers() -> dict[str, str]:
    api_key = (
        os.environ.get("MONOLITH_API_KEY")
        or os.environ.get("RAAVA_API_KEY")
        or config.get("api_key", "")
        or ""
    )
    if api_key:
        return {"Authorization": f"Bearer {api_key}"}
    return {}


def _client() -> httpx.Client:
    return httpx.Client(base_url=API_URL, timeout=TIMEOUT, headers=_auth_headers())


def _get(path: str, params: dict | None = None) -> dict | list:
    with _client() as c:
        resp = c.get(f"/api{path}", params=params)
        resp.raise_for_status()
        return resp.json()


def _post(path: str, body: dict | None = None, params: dict | None = None) -> dict:
    with _client() as c:
        resp = c.post(f"/api{path}", json=body or {}, params=params)
        resp.raise_for_status()
        return resp.json()


def _patch(path: str, body: dict | None = None) -> dict:
    with _client() as c:
        resp = c.patch(f"/api{path}", json=body or {})
        resp.raise_for_status()
        return resp.json()


def _delete(path: str) -> dict:
    with _client() as c:
        resp = c.delete(f"/api{path}")
        resp.raise_for_status()
        return resp.json()


def _require_api_path(path: str) -> str:
    p = (path or "").strip()
    if not p.startswith("/"):
        raise ValueError("path must start with '/' and be an API-relative path")
    return p


def _raw_get(path: str, params: dict | None = None) -> dict | list:
    p = _require_api_path(path)
    return _get(p, params=params)


def _raw_post(path: str, body: dict | None = None) -> dict | list:
    p = _require_api_path(path)
    with _client() as c:
        kwargs = {"json": body} if body is not None else {}
        resp = c.post(f"/api{p}", **kwargs)
        resp.raise_for_status()
        return resp.json()


def _raw_patch(path: str, body: dict | None = None) -> dict | list:
    p = _require_api_path(path)
    with _client() as c:
        resp = c.patch(f"/api{p}", json=body or {})
        resp.raise_for_status()
        return resp.json()


def _raw_put(path: str, body: dict | None = None) -> dict | list:
    p = _require_api_path(path)
    with _client() as c:
        resp = c.put(f"/api{p}", json=body or {})
        resp.raise_for_status()
        return resp.json()


def _raw_delete(path: str) -> dict | list:
    p = _require_api_path(path)
    with _client() as c:
        resp = c.delete(f"/api{p}")
        resp.raise_for_status()
        return resp.json()


def _raw_write_disabled_response(
    *,
    tool_name: str,
    method: str,
    path: str,
    environment: str,
    reason: str,
) -> dict[str, Any]:
    return _policy_blocked_write_response(
        tool_name=tool_name,
        action_type=f"raw_api_{method.lower()}",
        risk_class="break_glass",
        target_kind="raw_api_path",
        target_id=path,
        environment=environment,
        reason=reason,
        policy_mode="raw_write_disabled",
    )


def _raw_write_tool(
    *,
    tool_name: str,
    method: str,
    path: str,
    executor: Callable[[str], dict | list],
) -> dict | list:
    p = _require_api_path(path)
    environment = _default_write_environment()
    if _direct_writes_requested() and not _direct_writes_allowed(environment):
        return _raw_write_disabled_response(
            tool_name=tool_name,
            method=method,
            path=p,
            environment=environment,
            reason=(
                f"{DIRECT_WRITE_OVERRIDE_ENV}=1 is limited to local/dev/development/test environments; "
                f"route {environment} writes through {FLEET_MANAGER_ACTION_ROUTE}."
            ),
        )
    if not _direct_writes_allowed(environment):
        return _raw_write_disabled_response(
            tool_name=tool_name,
            method=method,
            path=p,
            environment=environment,
            reason=(
                f"Raw Fleet API {method.upper()} is disabled in monolith-mcp. "
                "Use dedicated read tools, change-request helpers, or Fleet Manager actions."
            ),
        )
    return executor(p)


def _stream_preview(path: str, params: dict | None = None, max_events: int = 5, max_seconds: int = 12) -> dict:
    p = _require_api_path(path)
    started = time.monotonic()
    events: list[dict | str] = []
    with _client() as c:
        with c.stream("GET", f"/api{p}", params=params) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if time.monotonic() - started > max_seconds:
                    break
                if not line:
                    continue
                if line.startswith("data: "):
                    payload = line[6:]
                    try:
                        events.append(json.loads(payload))
                    except Exception:
                        events.append(payload)
                if len(events) >= max_events:
                    break
    return {
        "path": p,
        "events": events,
        "truncated": len(events) >= max_events,
    }


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value if value is not None else {},
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def _stable_hash(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _compact_toon(kind: str, **fields: Any) -> str:
    parts = [TOON_VERSION, kind]
    for key, value in fields.items():
        if value in (None, "", {}, []):
            continue
        if isinstance(value, dict):
            rendered = _stable_hash(value)[:12]
        elif isinstance(value, (list, tuple, set)):
            rendered = str(len(value))
        else:
            rendered = str(value).replace(" ", "_")
        parts.append(f"{key}={rendered}")
    return " ".join(parts)


def _build_target_tuple(
    *,
    tenant_id: str,
    environment: str,
    target_kind: str,
    target_id: str,
    provider: str | None = None,
    region: str | None = None,
    zone: str | None = None,
    release_lane: str | None = None,
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    target: dict[str, Any] = {
        "tenant_id": tenant_id,
        "environment": environment,
        "target_kind": target_kind,
        "target_id": target_id,
    }
    optional = {
        "provider": provider,
        "region": region,
        "zone": zone,
        "release_lane": release_lane,
    }
    target.update({key: value for key, value in optional.items() if value})
    if extra:
        target.update({key: value for key, value in extra.items() if value is not None})
    return target


def _required_evidence_for(
    risk_class: ChangeRequestRiskClass,
    environment: str,
) -> list[str]:
    if risk_class == "read":
        return []
    if risk_class == "sensitive_read":
        return ["need_to_know", "redaction"]

    evidence = ["policy_diff", "rollback_plan", "verification_plan", "operator_approval"]
    if environment == "production":
        evidence.append("staging_evidence")
    if risk_class == "high_risk_write":
        evidence.extend(["owner_approval", "stop_conditions"])
    if risk_class == "break_glass":
        evidence.extend(["break_glass_reason", "post_action_review"])
    return evidence


def _policy_diff_helper(
    *,
    current: dict[str, Any] | None = None,
    desired: dict[str, Any] | None = None,
    action_type: str | None = None,
) -> dict[str, Any]:
    current_state = current or {}
    desired_state = desired or {}
    current_keys = set(current_state)
    desired_keys = set(desired_state)
    added = sorted(desired_keys - current_keys)
    removed = sorted(current_keys - desired_keys)
    changed = sorted(
        key for key in (current_keys & desired_keys)
        if current_state[key] != desired_state[key]
    )
    summary = {
        "added": added,
        "removed": removed,
        "changed": changed,
        "change_count": len(added) + len(removed) + len(changed),
    }
    return {
        "action_type": action_type or "unspecified",
        "current_state_hash": _stable_hash(current_state),
        "desired_state_hash": _stable_hash(desired_state),
        "diff_hash": _stable_hash(summary),
        "summary": summary,
        "toon": _compact_toon(
            "policy_diff",
            action=action_type or "unspecified",
            changes=summary["change_count"],
            added=len(added),
            changed=len(changed),
            removed=len(removed),
        ),
    }


def _default_rollback_plan(
    *,
    action_type: str,
    target_kind: str,
    target_id: str,
    fallback_tool: str,
) -> dict[str, Any]:
    if action_type == "snapshot_create":
        return {
            "type": "snapshot_delete",
            "tool": "snapshot_delete",
            "steps": [
                "Confirm the snapshot name created by the change request execution.",
                f"Delete the snapshot from {target_kind} {target_id} if rollback is required.",
                "Verify the snapshot inventory returns to the expected baseline.",
            ],
        }
    if action_type == "provision_start":
        return {
            "type": "provision_rollback",
            "tool": "provision_rollback",
            "steps": [
                "Track the provision job id created by the approved execution.",
                "Run provision_rollback if the new unit fails validation or must be abandoned.",
                "Verify container and cloud artifacts were cleaned up.",
            ],
        }
    if action_type == "tenant_create":
        return {
            "type": "manual_tenant_cleanup",
            "tool": "manual_cleanup_required",
            "steps": [
                "Record the tenant id and any units or containers created during execution.",
                "Coordinate tenant cleanup through the Fleet API/admin surface because monolith-mcp has no tenant delete tool yet.",
                "Verify the tenant record and any provisioned resources are removed.",
            ],
        }
    if action_type == "runtime_config_apply":
        return {
            "type": "reapply_previous_runtime_config",
            "tool": "runtime_config_patch",
            "follow_up_tool": "runtime_config_apply",
            "steps": [
                "Capture the known-good runtime config before approval.",
                "Re-stage the previous env/config values with runtime_config_patch.",
                "Run runtime_config_apply again and verify the target service recovers.",
            ],
        }
    if action_type == "agent_restart":
        return {
            "type": "service_recovery",
            "tool": "agent_restart",
            "steps": [
                "Capture agent status and recent logs before execution.",
                "If the restart leaves the service unhealthy, use the same operator path for controlled recovery.",
                "Verify agent health and logs return to the expected baseline.",
            ],
        }
    return {
        "type": "direct_tool_fallback",
        "tool": fallback_tool,
        "steps": [
            f"Capture current {target_kind} state before executing {action_type}.",
            f"Use {fallback_tool} under the current approval policy if rollback is required.",
            "Run post-rollback verification before closing the request.",
        ],
    }


def _rollback_plan_helper(
    *,
    action_type: str,
    target_kind: str,
    target_id: str,
    fallback_tool: str,
    plan: dict[str, Any] | None = None,
) -> dict[str, Any]:
    resolved = _default_rollback_plan(
        action_type=action_type,
        target_kind=target_kind,
        target_id=target_id,
        fallback_tool=fallback_tool,
    )
    if plan:
        resolved.update({key: value for key, value in plan.items() if value is not None})
    resolved.setdefault("steps", [])
    resolved["target_kind"] = target_kind
    resolved["target_id"] = target_id
    return {
        "ok": True,
        "rollback_plan": resolved,
        "toon": _compact_toon(
            "rollback_plan",
            action=action_type,
            target=f"{target_kind}:{target_id}",
            tool=resolved.get("tool"),
            steps=len(resolved["steps"]),
        ),
    }


def _staging_gate_helper(
    *,
    environment: str,
    action_type: str,
    target_id: str,
    staging_evidence: dict[str, Any] | None = None,
) -> dict[str, Any]:
    evidence = staging_evidence or {}
    evidence_keys = sorted(evidence.keys())
    required = environment == "production"
    satisfied = not required or bool(evidence_keys)
    status = "not_required"
    if required:
        status = "satisfied" if satisfied else "missing"
    return {
        "ok": True,
        "environment": environment,
        "action_type": action_type,
        "required": required,
        "satisfied": satisfied,
        "status": status,
        "evidence_keys": evidence_keys,
        "next_step": (
            "Collect staging evidence before approval."
            if required and not satisfied
            else "Staging gate is satisfied for this draft."
        ),
        "toon": _compact_toon(
            "staging_gate",
            action=action_type,
            env=environment,
            status=status,
            evidence=len(evidence_keys),
            target=target_id,
        ),
    }


def _default_verification_plan(
    *,
    action_type: str,
    target_id: str,
) -> dict[str, Any]:
    if action_type == "agent_restart":
        return {"tool": "agent_status", "target": target_id}
    if action_type == "container_update":
        return {"tool": "container_detail", "target": target_id}
    if action_type == "snapshot_create":
        return {"tool": "snapshots_list", "target": target_id}
    if action_type == "provision_start":
        return {"tool": "provision_status", "target": target_id}
    if action_type == "tenant_create":
        return {"tool": "tenant_detail", "target": target_id}
    if action_type == "runtime_config_apply":
        return {"tool": "runtime_config_show", "target": target_id}
    return {"tool": "manual_verification", "target": target_id}


def _change_request_stub(
    *,
    tenant_id: str,
    environment: str,
    target_kind: str,
    target_id: str,
    action_type: str,
    risk_class: ChangeRequestRiskClass,
    tool_name: str | None = None,
    target_tuple: dict[str, Any] | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    diff: dict[str, Any] | None = None,
    payload: dict[str, Any] | None = None,
    policy_decision: dict[str, Any] | None = None,
    required_evidence: list[str] | None = None,
    staging_evidence: dict[str, Any] | None = None,
    rollback_plan: dict[str, Any] | None = None,
    verification_plan: dict[str, Any] | None = None,
    quota_estimate: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
    helper_outputs: dict[str, Any] | None = None,
    toon: str | None = None,
) -> dict[str, Any]:
    resolved_target_tuple = target_tuple or _build_target_tuple(
        tenant_id=tenant_id,
        environment=environment,
        target_kind=target_kind,
        target_id=target_id,
    )
    request = {
        "tenant_id": tenant_id,
        "environment": environment,
        "target_kind": target_kind,
        "target_id": target_id,
        "target_tuple": resolved_target_tuple,
        "action_type": action_type,
        "tool_name": tool_name,
        "risk_class": risk_class,
        "current_state_hash": current_state_hash,
        "desired_state_hash": desired_state_hash,
        "diff": diff or {},
        "payload": payload or {},
        "policy_decision": policy_decision or {},
        "required_evidence": required_evidence or _required_evidence_for(risk_class, environment),
        "staging_evidence": staging_evidence,
        "rollback_plan": rollback_plan,
        "verification_plan": verification_plan,
        "quota_estimate": quota_estimate,
        "idempotency_key": idempotency_key,
    }
    binding = {
        "target_tuple_hash": _stable_hash(resolved_target_tuple),
        "current_state_hash": current_state_hash,
        "desired_state_hash": desired_state_hash,
        "diff_hash": _stable_hash(request["diff"]),
    }
    return {
        "ok": True,
        "stub": True,
        "status": "draft_local_only",
        "toon": toon
        or _compact_toon(
            "proposal",
            tenant=tenant_id,
            env=environment,
            action=action_type,
            target=f"{target_kind}:{target_id}",
            risk=risk_class,
        ),
        "submission_target": "POST /api/fleet-manager/actions",
        "api_dependency": "Fleet API Fleet Manager action routes",
        "change_request": request,
        "approval_binding": binding,
        "proposal_helpers": helper_outputs or {},
        "next_steps": [
            "Collect read-only evidence for the target.",
            "Attach staging, rollback, and verification evidence before approval.",
            "Submit this payload to /api/fleet-manager/actions.",
            "Approve and execute only through /api/fleet-manager/actions/{id}/execute.",
        ],
    }


def _proposal_change_request(
    *,
    tenant_id: str,
    environment: str,
    target_kind: str,
    target_id: str,
    action_type: str,
    tool_name: str,
    risk_class: ChangeRequestRiskClass,
    diff: dict[str, Any] | None = None,
    payload: dict[str, Any] | None = None,
    target_tuple: dict[str, Any] | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    policy_decision: dict[str, Any] | None = None,
    required_evidence: list[str] | None = None,
    staging_evidence: dict[str, Any] | None = None,
    rollback_plan: dict[str, Any] | None = None,
    verification_plan: dict[str, Any] | None = None,
    quota_estimate: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
) -> dict[str, Any]:
    desired_view = diff if diff is not None else (payload or {})
    policy_summary = _policy_diff_helper(
        current=None,
        desired=desired_view,
        action_type=action_type,
    )
    resolved_rollback = _rollback_plan_helper(
        action_type=action_type,
        target_kind=target_kind,
        target_id=target_id,
        fallback_tool=tool_name,
        plan=rollback_plan,
    )
    resolved_staging_gate = _staging_gate_helper(
        environment=environment,
        action_type=action_type,
        target_id=target_id,
        staging_evidence=staging_evidence,
    )
    merged_policy_decision = {
        "write_path": "proposal_first_draft",
        "fallback_tool": tool_name,
        "staging_gate": resolved_staging_gate["status"],
    }
    if policy_decision:
        merged_policy_decision.update(policy_decision)
    resolved_verification_plan = verification_plan or _default_verification_plan(
        action_type=action_type,
        target_id=target_id,
    )
    return _change_request_stub(
        tenant_id=tenant_id,
        environment=environment,
        target_kind=target_kind,
        target_id=target_id,
        action_type=action_type,
        risk_class=risk_class,
        tool_name=tool_name,
        target_tuple=target_tuple,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash or policy_summary["desired_state_hash"],
        diff=diff,
        payload=payload,
        policy_decision=merged_policy_decision,
        required_evidence=required_evidence,
        staging_evidence=staging_evidence,
        rollback_plan=resolved_rollback["rollback_plan"],
        verification_plan=resolved_verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        helper_outputs={
            "policy_diff": policy_summary,
            "rollback_plan": resolved_rollback,
            "staging_gate": resolved_staging_gate,
        },
    )


def _direct_writes_requested() -> bool:
    return os.environ.get(DIRECT_WRITE_OVERRIDE_ENV) == "1"


def _direct_writes_allowed(environment: str | None) -> bool:
    return (
        _direct_writes_requested()
        and (environment or "").strip().lower() in LOCAL_DEBUG_ENVIRONMENTS
    )


def _configured_mcp_environment(default: str = "") -> str:
    return (
        os.environ.get("MONOLITH_MCP_ENVIRONMENT")
        or os.environ.get("MONOLITH_ENVIRONMENT")
        or os.environ.get("MONOLITH_MCP_DEFAULT_ENVIRONMENT")
        or default
    ).strip().lower()


def _default_write_environment() -> str:
    return _configured_mcp_environment("production")


def _policy_blocked_write_response(
    *,
    tool_name: str,
    action_type: str,
    risk_class: ChangeRequestRiskClass,
    reason: str,
    target_kind: str | None = None,
    target_id: str | None = None,
    tenant_id: str | None = None,
    environment: str | None = None,
    missing_fields: list[str] | None = None,
    policy_mode: str = "blocked",
    proposal: dict[str, Any] | None = None,
    action_submission: dict[str, Any] | None = None,
) -> dict[str, Any]:
    response: dict[str, Any] = {
        "ok": bool(proposal or action_submission),
        "status": "blocked_by_policy",
        "tool_name": tool_name,
        "action_type": action_type,
        "risk_class": risk_class,
        "message": reason,
        "policy_mode": policy_mode,
        "required_route": FLEET_MANAGER_ACTION_ROUTE,
        "direct_write_override_env": DIRECT_WRITE_OVERRIDE_ENV,
        "next_steps": [
            f"Use {FLEET_MANAGER_ACTION_ROUTE} for proposal, approval, and execution.",
            f"Set {DIRECT_WRITE_OVERRIDE_ENV}=1 only for local/dev/development/test emergency break-glass use.",
        ],
    }
    optional = {
        "tenant_id": tenant_id,
        "environment": environment,
        "target_kind": target_kind,
        "target_id": target_id,
        "missing_fields": missing_fields,
        "proposal": proposal,
        "action_submission": action_submission,
    }
    response.update({key: value for key, value in optional.items() if value is not None})
    return response


def _route_direct_write(
    *,
    tool_name: str,
    action_type: str,
    risk_class: ChangeRequestRiskClass,
    target_kind: str,
    target_id: str,
    payload: dict[str, Any] | None = None,
    diff: dict[str, Any] | None = None,
    tenant_id: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict[str, Any] | None = None,
    rollback_plan: dict[str, Any] | None = None,
    verification_plan: dict[str, Any] | None = None,
    quota_estimate: dict[str, Any] | None = None,
    idempotency_key: str | None = None,
    target_tuple: dict[str, Any] | None = None,
    policy_decision: dict[str, Any] | None = None,
    direct_executor: Callable[[], dict[str, Any]] | None = None,
    supported: bool = True,
    break_glass_reason: str | None = None,
) -> dict[str, Any]:
    resolved_environment = environment or _default_write_environment()
    if _direct_writes_requested() and not _direct_writes_allowed(resolved_environment):
        return _policy_blocked_write_response(
            tool_name=tool_name,
            action_type=action_type,
            risk_class=risk_class,
            target_kind=target_kind,
            target_id=target_id,
            tenant_id=tenant_id,
            environment=resolved_environment,
            reason=(
                f"{DIRECT_WRITE_OVERRIDE_ENV}=1 is limited to local/dev/development/test environments; "
                f"route {resolved_environment} writes through {FLEET_MANAGER_ACTION_ROUTE}."
            ),
        )

    if _direct_writes_allowed(resolved_environment):
        if not supported and risk_class == "break_glass":
            return _policy_blocked_write_response(
                tool_name=tool_name,
                action_type=action_type,
                risk_class=risk_class,
                target_kind=target_kind,
                target_id=target_id,
                tenant_id=tenant_id,
                environment=resolved_environment,
                reason=break_glass_reason
                or f"{tool_name} is not supported for direct execution; use the governed route.",
                policy_mode="break_glass_only" if risk_class == "break_glass" else "blocked",
            )
        if direct_executor is None:
            return _policy_blocked_write_response(
                tool_name=tool_name,
                action_type=action_type,
                risk_class=risk_class,
                target_kind=target_kind,
                target_id=target_id,
                tenant_id=tenant_id,
                environment=environment,
                reason=(
                    f"{DIRECT_WRITE_OVERRIDE_ENV}=1 is set, but "
                    f"{tool_name} has no direct executor."
                ),
            )
        return direct_executor()

    if not supported:
        return _policy_blocked_write_response(
            tool_name=tool_name,
            action_type=action_type,
            risk_class=risk_class,
            target_kind=target_kind,
            target_id=target_id,
            tenant_id=tenant_id,
            environment=resolved_environment,
            reason=break_glass_reason
            or (
                f"Direct execution for {tool_name} is disabled in monolith-mcp. "
                "Use a Fleet Manager action or local break-glass override."
            ),
            policy_mode="break_glass_only",
        )

    missing_fields: list[str] = []
    if not tenant_id:
        missing_fields.append("tenant_id")
    if missing_fields:
        return _policy_blocked_write_response(
            tool_name=tool_name,
            action_type=action_type,
            risk_class=risk_class,
            target_kind=target_kind,
            target_id=target_id,
            tenant_id=tenant_id,
            environment=resolved_environment,
            missing_fields=missing_fields,
            reason=(
                f"Direct execution for {tool_name} is disabled. "
                "Provide the Fleet Manager target context and submit via the action route."
            ),
            policy_mode="missing_fleet_manager_context",
        )

    merged_policy_decision = {
        "write_path": "fleet_manager_action_first" if submit_action else "proposal_first_draft",
        "fallback_tool": tool_name,
        "mcp_direct_write": "blocked_by_policy",
    }
    if policy_decision:
        merged_policy_decision.update(policy_decision)

    if submit_action:
        action_submission = fleet_manager_action_create(
            tenant_id=tenant_id,
            action_type=action_type,
            tool_name=tool_name,
            risk_class=risk_class,
            target_environment=resolved_environment,
            payload=payload,
            idempotency_key=idempotency_key,
            target_kind=target_kind,
            target_id=target_id,
            current_state_hash=current_state_hash,
            desired_state_hash=desired_state_hash,
            diff=diff,
            rollback_plan=rollback_plan,
            verification_plan=verification_plan,
            staging_evidence=staging_evidence,
            quota_estimate=quota_estimate,
        )
        return _policy_blocked_write_response(
            tool_name=tool_name,
            action_type=action_type,
            risk_class=risk_class,
            target_kind=target_kind,
            target_id=target_id,
            tenant_id=tenant_id,
            environment=resolved_environment,
            reason=(
                f"Direct execution for {tool_name} is disabled. "
                "Submitted a Fleet Manager action instead."
            ),
            policy_mode="fleet_manager_action_submitted",
            action_submission=action_submission,
        )

    proposal = _proposal_change_request(
        tenant_id=tenant_id,
        environment=resolved_environment,
        target_kind=target_kind,
        target_id=target_id,
        action_type=action_type,
        tool_name=tool_name,
        risk_class=risk_class,
        diff=diff,
        payload=payload,
        target_tuple=target_tuple,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        policy_decision=merged_policy_decision,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )
    return _policy_blocked_write_response(
        tool_name=tool_name,
        action_type=action_type,
        risk_class=risk_class,
        target_kind=target_kind,
        target_id=target_id,
        tenant_id=tenant_id,
        environment=resolved_environment,
        reason=(
            f"Direct execution for {tool_name} is disabled. "
            "Prepared a Fleet Manager proposal draft instead."
        ),
        policy_mode="proposal_first_draft",
        proposal=proposal,
    )


def _safe_container_mutation(action: str, container_id: str, fn) -> dict:
    try:
        return fn()
    except httpx.HTTPStatusError as exc:
        response = exc.response
        message = f"Failed to {action} container {container_id}"
        try:
            payload = response.json()
        except ValueError:
            payload = None
        if isinstance(payload, dict):
            detail = payload.get("detail", payload)
            if isinstance(detail, dict):
                message = detail.get("error") or detail.get("message") or str(detail)
            elif isinstance(detail, str) and detail.strip():
                message = detail.strip()
        elif response.text.strip():
            message = response.text.strip()
        return {
            "ok": False,
            "action": action,
            "container_id": container_id,
            "status_code": response.status_code,
            "error": message,
        }
    except httpx.HTTPError as exc:
        return {
            "ok": False,
            "action": action,
            "container_id": container_id,
            "error": str(exc),
        }


# ═══════════════════════════════════════════
# Fleet
# ═══════════════════════════════════════════

@server.tool(description="Get fleet-wide health overview — all containers with CPU, memory, disk, and agent status")
def fleet_health() -> dict:
    return _get("/fleet/health")


@server.tool(description="Get fleet aggregate stats — total containers, running count, active agents, alert count")
def fleet_stats() -> dict:
    return _get("/fleet/stats")


@server.tool(description="Get current threshold alerts across the fleet")
def fleet_alerts() -> list:
    return _get("/fleet/alerts")


@server.tool(description="Get cross-tenant audit feed of recent actions")
def fleet_audit(hours: int = 1, limit: int = 50) -> list:
    return _get("/fleet/audit", params={"hours": hours, "limit": limit})


@server.tool(description="Filter agents across the fleet by status, tenant, or unit")
def fleet_agents(status: str | None = None, tenant: str | None = None, unit: str | None = None) -> dict:
    params = {}
    if status:
        params["status"] = status
    if tenant:
        params["tenant"] = tenant
    if unit:
        params["unit"] = unit
    return _get("/fleet/agents", params=params)


@server.tool(description="AXI compact fleet summary with counts, health, and next actions")
def fleet_summary() -> dict:
    stats = _get("/fleet/stats")
    alerts = _get("/fleet/alerts")
    critical = stats.get("critical_alerts", 0)
    running = stats.get("running_containers", 0)
    total = stats.get("total_containers", 0)
    status = "critical" if critical else "degraded" if alerts else "healthy"
    rows = [
        {
            "status": status,
            "containers": total,
            "running": running,
            "agents": stats.get("total_agents", total),
            "active": stats.get("active_agents", 0),
            "alerts": stats.get("total_alerts", len(alerts)),
            "critical": critical,
        }
    ]
    return _compact_response(
        f"Fleet {status}: {running}/{total} containers running, {len(alerts)} active alerts.",
        rows,
        ["status", "containers", "running", "agents", "active", "alerts", "critical"],
        limit=1,
        help_text=[
            "fleet_agents_compact(status='error')",
            "fleet_alerts()",
            "fleet_health() for raw full health payload",
        ],
    )


@server.tool(description="Return the agent-first CLI/MCP contract, including safe write policy and preferred tools.")
def agent_contract() -> dict:
    return agent_contract_model.agent_contract()


@server.tool(description="Return agent workflow guidance for orient, triage, staged_write, or provision.")
def agent_workflow_guide(intent: str | None = None) -> dict:
    return agent_contract_model.workflow_guide(intent)


@server.tool(description="Return API enhancement ticket drafts for gaps that cannot be fixed in the CLI/MCP adapter.")
def agent_api_tickets() -> dict:
    return {
        "ok": True,
        "schema_version": agent_contract_model.CONTRACT_VERSION,
        "tickets": agent_contract_model.api_tickets(),
    }


def _diagnostic_get(path: str, params: dict | None = None) -> Any:
    return _get(path, params=params)


@server.tool(description="Resolve a tenant/runtime target exactly without fuzzy guessing.")
def target_resolve(
    query: str,
    tenant: str | None = None,
    include_deleted: bool = False,
) -> dict:
    return agent_diagnostics.target_resolve(
        _diagnostic_get,
        query,
        tenant=tenant,
        include_deleted=include_deleted,
    )


@server.tool(description="Read Discord messaging config for one runtime as redacted structured data.")
def messaging_discord_config(container_id: str) -> dict:
    return agent_diagnostics.messaging_discord_config(_diagnostic_get, container_id)


@server.tool(description="Aggregate runtime config, env, messaging config, connectivity, and provenance notes.")
def config_inventory(container_id: str) -> dict:
    return agent_diagnostics.config_inventory(_diagnostic_get, container_id)


@server.tool(description="Aggregate Hermes-specific runtime config, path presence, messaging, and env facts.")
def hermes_config_inventory(container_id: str) -> dict:
    return agent_diagnostics.hermes_config_inventory(_diagnostic_get, container_id)


@server.tool(description="Inspect Hermes skill directories and load-state evidence available through read endpoints.")
def hermes_skill_enablement(container_id: str) -> dict:
    return agent_diagnostics.hermes_skill_enablement(_diagnostic_get, container_id)


@server.tool(description="Inspect Hermes plugin/connector directories and capability evidence available through read endpoints.")
def hermes_plugin_inventory(container_id: str) -> dict:
    return agent_diagnostics.hermes_plugin_inventory(_diagnostic_get, container_id)


@server.tool(description="Inspect cron, timer, and app schedule locations without executing commands.")
def cron_job_inventory(container_id: str) -> dict:
    return agent_diagnostics.cron_job_inventory(_diagnostic_get, container_id)


@server.tool(description="Build one compact investigation bundle with target, health, logs, config, Hermes, cron, and audit evidence.")
def incident_bundle(
    container_id: str,
    tenant: str | None = None,
    log_lines: int = 40,
) -> dict:
    return agent_diagnostics.incident_bundle(
        _diagnostic_get,
        container_id,
        tenant=tenant,
        log_lines=log_lines,
    )


@server.tool(description="AXI compact agent list. Default is token-light; use fleet_agents for raw JSON.")
def fleet_agents_compact(
    status: str | None = None,
    tenant: str | None = None,
    unit: str | None = None,
    limit: int = DEFAULT_LIMIT,
) -> dict:
    payload = fleet_agents(status=status, tenant=tenant, unit=unit)
    containers = payload.get("containers", []) if isinstance(payload, dict) else []
    if not containers:
        return _empty(
            "No agents matched the current filters.",
            ["fleet_agents_compact()", "fleet_health_compact()"],
        )
    rows = [_health_row(container) for container in containers]
    return _compact_response(
        f"{len(containers)} agents matched.",
        rows,
        ["id", "tenant", "agent", "status", "agent_status", "cpu", "mem", "ip"],
        limit=limit,
        help_text=[
            "container_view(container_id='<id>')",
            "agent_logs_compact(container_id='<id>')",
            "fleet_agents(...) for raw JSON",
        ],
    )


@server.tool(description="AXI compact fleet health table. Use fleet_health for raw JSON.")
def fleet_health_compact(limit: int = DEFAULT_LIMIT) -> dict:
    payload = fleet_health()
    containers = payload.get("containers", []) if isinstance(payload, dict) else []
    if not containers:
        return _empty(
            "No containers are registered in the fleet.",
            ["provision_start(...) to create an agent", "fleet_health() for raw JSON"],
        )
    rows = [_health_row(container) for container in list(containers)]
    return _compact_response(
        f"{len(containers)} containers in fleet health.",
        rows,
        ["id", "tenant", "agent", "status", "agent_status", "cpu", "mem", "ip"],
        limit=limit,
        help_text=[
            "fleet_summary()",
            "container_view(container_id='<id>')",
            "fleet_health() for raw JSON",
        ],
    )


# ═══════════════════════════════════════════
# Agent-optimized workflows
# ═══════════════════════════════════════════

@server.tool(description="Workflow: triage one agent with status, health, processes, logs, likely cause, and next actions.")
def triage_agent(container_id: str, log_lines: int = 40) -> dict:
    detail_result = _safe_workflow_call("container_detail", lambda: container_detail(container_id))
    detail = _call_value(detail_result, {})
    container, health = _container_and_health(detail if isinstance(detail, dict) else {}, container_id)

    agent_result = _safe_workflow_call("agent_status", lambda: agent_status(container_id))
    health_result = _safe_workflow_call("container_health", lambda: container_health(container_id))
    processes_result = _safe_workflow_call("system_processes", lambda: system_processes(container_id, limit=10))
    info_result = _safe_workflow_call("system_info", lambda: system_info(container_id, hours=24))
    logs_result = _safe_workflow_call(
        "agent_logs_compact",
        lambda: agent_logs_compact(container_id, lines=log_lines),
    )

    agent = _call_value(agent_result, {})
    health_payload = _call_value(health_result, health)
    resolved_health = health if health else (health_payload if isinstance(health_payload, dict) else {})
    logs_payload = _call_value(logs_result, {})
    log_text = _extract_log_text(logs_payload)
    cause = _likely_triage_cause(
        container=container,
        health=resolved_health,
        agent=agent if isinstance(agent, dict) else {},
        logs=log_text,
    )
    rows = [
        {"signal": "container_status", "value": container.get("status") or "unknown"},
        {
            "signal": "agent_status",
            "value": (
                agent.get("status")
                if isinstance(agent, dict)
                else None
            )
            or (
                agent.get("agent_status")
                if isinstance(agent, dict)
                else None
            )
            or resolved_health.get("agent_status")
            or "unknown",
        },
        {"signal": "tenant", "value": _tenant_from_container(container) or "unknown"},
        {"signal": "likely_cause", "value": cause},
        {"signal": "log_lines", "value": logs_payload.get("returned") if isinstance(logs_payload, dict) else 0},
    ]
    return _workflow_response(
        summary=f"Triage {container_id}: {cause}.",
        rows=rows,
        fields=["signal", "value"],
        evidence={
            "container_detail": detail_result,
            "agent_status": agent_result,
            "container_health": health_result,
            "system_processes": processes_result,
            "system_info": info_result,
            "agent_logs_compact": logs_result,
        },
        help_text=[
            f"container_view(container_id='{container_id}')",
            f"agent_logs_compact(container_id='{container_id}')",
            f"proposal_agent_restart(tenant_id='<tenant>', environment='staging', container_id='{container_id}') if restart is warranted",
        ],
    )


@server.tool(description="Workflow: scan fleet inventory for model, stack, limit, or health drift from a desired policy.")
def drift_scan(
    desired_policy: dict | None = None,
    tenant_id: str | None = None,
    limit: int = DEFAULT_LIMIT,
) -> dict:
    inventory_result = _safe_workflow_call("containers_list", containers_list)
    policy = desired_policy or {}
    if not inventory_result["ok"]:
        return {
            **_empty(
                "Drift scan could not load container inventory.",
                ["containers_list()"],
            ),
            "ok": False,
            "evidence": {
                "containers_list": inventory_result,
                "desired_policy": policy,
            },
        }
    containers = _containers_from_payload(_call_value(inventory_result, []))
    drift_rows: list[dict[str, Any]] = []
    fields_to_check = [
        "model",
        "stack",
        "agent_role",
        "memory_limit",
        "cpu_limit",
        "disk_limit",
    ]
    for container in containers:
        tenant = _tenant_from_container(container)
        if tenant_id and tenant != tenant_id:
            continue
        health = container.get("health") if isinstance(container.get("health"), dict) else {}
        mismatches: list[str] = []
        for field in fields_to_check:
            if field in policy and container.get(field) != policy[field]:
                mismatches.append(field)
        status = container.get("status")
        agent_state = health.get("agent_status")
        if not policy and (status != "running" or agent_state not in {None, "active", "running", "healthy"}):
            mismatches.append("health")
        if mismatches:
            drift_rows.append(
                {
                    "tenant": tenant,
                    "id": container.get("id"),
                    "agent": container.get("agent_name"),
                    "status": status,
                    "drift": "|".join(mismatches),
                }
            )
    summary = (
        f"{len(drift_rows)} drift candidates across {len(containers)} containers."
        if drift_rows
        else f"No drift found across {len(containers)} containers."
    )
    return _workflow_response(
        summary=summary,
        rows=drift_rows,
        fields=["tenant", "id", "agent", "status", "drift"],
        evidence={"containers_list": inventory_result, "desired_policy": policy},
        limit=limit,
        help_text=[
            "container_view(container_id='<id>')",
            "policy_diff(current={...}, desired={...})",
            "rollout_plan(tenant_id='<tenant>', container_id='<id>', requested_model='<model>')",
        ],
    )


@server.tool(description="Workflow: prepare a model rollout plan and proposal-first Fleet Manager action evidence.")
def rollout_plan(
    tenant_id: str,
    container_id: str,
    requested_model: str,
    environment: str = "staging",
    submit_action: bool = False,
    staging_evidence: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    detail_result = _safe_workflow_call("container_detail", lambda: container_detail(container_id))
    if not detail_result["ok"]:
        return {
            **_empty(
                f"Rollout plan for {container_id} requires current container state.",
                [f"container_detail(container_id='{container_id}')"],
            ),
            "ok": False,
            "evidence": {"container_detail": detail_result},
        }
    detail = _call_value(detail_result, {})
    container, _ = _container_and_health(detail if isinstance(detail, dict) else {}, container_id)
    current_model = container.get("model")
    diff = {"model": requested_model}
    current_hash = _stable_hash(container)
    desired_hash = _stable_hash(diff)
    if submit_action:
        proposal = fleet_manager_action_create(
            tenant_id=tenant_id,
            action_type="container_update",
            tool_name="container_update",
            risk_class="operational_write",
            target_environment=environment,
            payload={"container_id": container_id, "model": requested_model},
            idempotency_key=idempotency_key,
            target_kind="container",
            target_id=container_id,
            current_state_hash=current_hash,
            desired_state_hash=desired_hash,
            diff=diff,
            staging_evidence=staging_evidence,
            rollback_plan={
                "type": "restore_previous_model",
                "tool": "container_update",
                "previous_model": current_model,
            },
            verification_plan={"tool": "agent_status", "target": container_id},
        )
    else:
        proposal = proposal_container_update(
            tenant_id=tenant_id,
            environment=environment,
            container_id=container_id,
            model=requested_model,
            current_state_hash=current_hash,
            desired_state_hash=desired_hash,
            staging_evidence=staging_evidence,
            rollback_plan={
                "type": "restore_previous_model",
                "tool": "container_update",
                "previous_model": current_model,
            },
            verification_plan={"tool": "agent_status", "target": container_id},
            idempotency_key=idempotency_key,
        )
    rows = [
        {"field": "tenant", "value": tenant_id},
        {"field": "container", "value": container_id},
        {"field": "environment", "value": environment},
        {"field": "current_model", "value": current_model or "unknown"},
        {"field": "requested_model", "value": requested_model},
        {"field": "proposal_mode", "value": "submitted" if submit_action else "draft"},
    ]
    return _workflow_response(
        summary=f"Rollout plan for {container_id}: {current_model or 'unknown'} -> {requested_model}.",
        rows=rows,
        fields=["field", "value"],
        evidence={"container_detail": detail_result},
        proposals={"container_update": proposal},
        help_text=[
            "fleet_manager_action_approve(action_id='<id>', evidence={...}) after review",
            "fleet_manager_action_execute(action_id='<id>') only after approval",
            f"agent_status(container_id='{container_id}')",
        ],
    )


@server.tool(description="Workflow: prove rollback readiness with snapshots, audit context, and optional snapshot proposal.")
def rollback_readiness(
    container_id: str,
    tenant_id: str | None = None,
    environment: str = "production",
    snapshot_name: str | None = None,
) -> dict:
    detail_result = _safe_workflow_call("container_detail", lambda: container_detail(container_id))
    snapshots_result = _safe_workflow_call("snapshots_list", lambda: snapshots_list(container_id))
    audit_result = _safe_workflow_call("fleet_audit", lambda: fleet_audit(hours=24, limit=10))
    snapshots = _call_value(snapshots_result, [])
    snapshot_count = len(snapshots) if isinstance(snapshots, list) else 0
    status = "ready" if snapshot_count else "missing_snapshot"
    proposals: dict[str, Any] = {}
    if snapshot_name and tenant_id:
        proposals["snapshot_create"] = proposal_snapshot_create(
            tenant_id=tenant_id,
            environment=environment,
            container_id=container_id,
            name=snapshot_name,
        )
    rows = [
        {"check": "container_detail", "status": "pass" if detail_result["ok"] else "fail"},
        {"check": "snapshot_inventory", "status": "pass" if snapshot_count else "missing"},
        {"check": "audit_context", "status": "pass" if audit_result["ok"] else "fail"},
        {"check": "rollback_status", "status": status},
    ]
    return _workflow_response(
        summary=f"Rollback readiness for {container_id}: {status}.",
        rows=rows,
        fields=["check", "status"],
        evidence={
            "container_detail": detail_result,
            "snapshots_list": snapshots_result,
            "fleet_audit": audit_result,
            "snapshot_count": snapshot_count,
        },
        proposals=proposals,
        help_text=[
            f"snapshots_list(container_id='{container_id}')",
            f"proposal_snapshot_create(tenant_id='<tenant>', environment='{environment}', container_id='{container_id}')",
            "rollback_plan(action_type='<action>', target_kind='container', target_id='<id>', fallback_tool='<tool>')",
        ],
    )


# ═══════════════════════════════════════════
# Containers
# ═══════════════════════════════════════════

@server.tool(description="List all managed containers with their health snapshots")
def containers_list() -> dict:
    return _get("/containers")


@server.tool(description="Get detailed info for a specific container including health, snapshots, and audit log")
def container_detail(container_id: str) -> dict:
    return _get(f"/containers/{container_id}")


@server.tool(description="AXI compact container view with status, resource snapshot, and next actions")
def container_view(container_id: str) -> dict:
    detail = container_detail(container_id)
    health = detail.get("health") or {}
    container = detail.get("container") if isinstance(detail.get("container"), dict) else detail
    row = {
        "id": container.get("id") or container_id,
        "tenant": container.get("tenant") or container.get("tenant_id"),
        "agent": container.get("agent_name"),
        "status": container.get("status"),
        "agent_status": health.get("agent_status"),
        "cpu": health.get("cpu"),
        "mem": health.get("mem"),
        "disk": health.get("disk"),
        "ip": container.get("ip"),
    }
    return _compact_response(
        f"Container {container_id}: {_agent_status({'status': row['status'], 'health': health})}.",
        [row],
        ["id", "tenant", "agent", "status", "agent_status", "cpu", "mem", "disk", "ip"],
        limit=1,
        help_text=[
            f"agent_logs_compact(container_id='{container_id}')",
            f"container_health(container_id='{container_id}')",
            f"container_detail(container_id='{container_id}') for raw JSON",
        ],
    )


@server.tool(description="Start a stopped container")
def container_start(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="container_start",
        action_type="container_start",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id},
        direct_executor=lambda: _safe_container_mutation(
            "start", container_id, lambda: _post(f"/containers/{container_id}/start")
        ),
        supported=False,
    )


@server.tool(description="Stop a running container. Use force=True to force-kill.")
def container_stop(container_id: str, force: bool = False) -> dict:
    return _route_direct_write(
        tool_name="container_stop",
        action_type="container_stop",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id, "force": force},
        direct_executor=lambda: _safe_container_mutation(
            "stop",
            container_id,
            lambda: _post(f"/containers/{container_id}/stop", body={"force": force}),
        ),
        supported=False,
    )


@server.tool(description="Pause/freeze a running container while preserving runtime state")
def container_pause(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="container_pause",
        action_type="container_pause",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id, "operation": "pause"},
        direct_executor=lambda: _safe_container_mutation(
            "pause",
            container_id,
            lambda: _post(f"/containers/{container_id}/pause", body={}),
        ),
        supported=False,
    )


@server.tool(description="Resume a paused/frozen container")
def container_resume(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="container_resume",
        action_type="container_resume",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id, "operation": "resume"},
        direct_executor=lambda: _safe_container_mutation(
            "resume",
            container_id,
            lambda: _post(f"/containers/{container_id}/resume", body={}),
        ),
        supported=False,
    )


@server.tool(description="Restart a container")
def container_restart(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="container_restart",
        action_type="container_restart",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id, "operation": "restart"},
        direct_executor=lambda: _safe_container_mutation(
            "restart", container_id, lambda: _post(f"/containers/{container_id}/restart")
        ),
        supported=False,
    )


@server.tool(description="Delete a container permanently")
def container_delete(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="container_delete",
        action_type="container_delete",
        risk_class="high_risk_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id},
        direct_executor=lambda: _safe_container_mutation(
            "delete", container_id, lambda: _delete(f"/containers/{container_id}")
        ),
        supported=False,
    )


@server.tool(description="Update container metadata — agent_name, agent_role, model, memory_limit, cpu_limit")
def container_update(
    container_id: str,
    agent_name: str | None = None,
    agent_role: str | None = None,
    model: str | None = None,
    memory_limit: str | None = None,
    cpu_limit: str | None = None,
    tenant_id: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    body = {}
    if agent_name:
        body["agent_name"] = agent_name
    if agent_role:
        body["agent_role"] = agent_role
    if model:
        body["model"] = model
    if memory_limit:
        body["memory_limit"] = memory_limit
    if cpu_limit:
        body["cpu_limit"] = cpu_limit
    return _route_direct_write(
        tool_name="container_update",
        action_type="container_update",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        diff=body,
        payload={"container_id": container_id, **body},
        direct_executor=lambda: _patch(f"/containers/{container_id}", body=body),
    )


# ═══════════════════════════════════════════
# Agent (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="Get the agent process status inside a container (PID, uptime, stack type)")
def agent_status(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/agent")


@server.tool(description="Get agent logs from inside a container")
def agent_logs(container_id: str, lines: int = 100, since: str | None = None) -> dict:
    params = {"lines": lines}
    if since:
        params["since"] = since
    return _get(f"/containers/{container_id}/agent/logs", params=params)


@server.tool(description="AXI compact agent log tail. Truncates by default; use agent_logs for raw logs.")
def agent_logs_compact(
    container_id: str,
    lines: int = 40,
    since: str | None = None,
) -> dict:
    clamped = _clamp_limit(lines, default=40, maximum=200)
    payload = agent_logs(container_id, lines=clamped, since=since)
    raw_lines = payload.get("lines") or payload.get("logs") or payload.get("data") or []
    if isinstance(raw_lines, str):
        log_lines = raw_lines.splitlines()
    elif isinstance(raw_lines, list):
        log_lines = [str(line) for line in raw_lines]
    else:
        log_lines = []
    if not log_lines:
        return _empty(
            f"No agent logs returned for {container_id}.",
            [
                f"agent_status(container_id='{container_id}')",
                f"agent_logs(container_id='{container_id}') for raw JSON",
            ],
            fmt="text",
        )
    source_lines = log_lines[-clamped:]
    visible = [_truncate_text(line, MAX_LOG_LINE_CHARS) for line in source_lines]
    dropped_lines = len(log_lines) > len(visible)
    shortened_lines = any(len(line) > MAX_LOG_LINE_CHARS for line in source_lines)
    return {
        "ok": True,
        "summary": f"{len(visible)} log lines from {container_id}.",
        "format": "text",
        "data": "\n".join(visible),
        "returned": len(visible),
        "total": len(log_lines),
        "truncated": dropped_lines or shortened_lines,
        "help": [
            f"agent_status(container_id='{container_id}')",
            f"container_view(container_id='{container_id}')",
            f"agent_logs(container_id='{container_id}', lines={clamped}) for raw JSON",
        ],
    }


@server.tool(description="Start the agent service inside a container")
def agent_start(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="agent_start",
        action_type="agent_start",
        risk_class="operational_write",
        target_kind="agent_service",
        target_id=container_id,
        payload={"container_id": container_id},
        direct_executor=lambda: _post(f"/containers/{container_id}/agent/start"),
        supported=False,
    )


@server.tool(description="Stop the agent service inside a container")
def agent_stop(container_id: str) -> dict:
    return _route_direct_write(
        tool_name="agent_stop",
        action_type="agent_stop",
        risk_class="operational_write",
        target_kind="agent_service",
        target_id=container_id,
        payload={"container_id": container_id},
        direct_executor=lambda: _post(f"/containers/{container_id}/agent/stop"),
        supported=False,
    )


@server.tool(description="Restart the agent service inside a container")
def agent_restart(
    container_id: str,
    tenant_id: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    return _route_direct_write(
        tool_name="agent_restart",
        action_type="agent_restart",
        risk_class="operational_write",
        target_kind="agent_service",
        target_id=container_id,
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        diff={"operation": "restart"},
        payload={"container_id": container_id},
        direct_executor=lambda: _post(f"/containers/{container_id}/agent/restart"),
    )


# ═══════════════════════════════════════════
# Health
# ═══════════════════════════════════════════

@server.tool(description="Get the latest health snapshot for a container (CPU, mem, disk, network)")
def container_health(container_id: str) -> dict:
    with _client() as c:
        resp = c.get(f"/api/containers/{container_id}/health")
        if resp.status_code == 404:
            return {"message": "No health data available yet", "container_id": container_id}
        resp.raise_for_status()
        return resp.json()


@server.tool(description="Get health history with avg/peak stats for charting")
def container_health_history(container_id: str, hours: int = 24) -> dict:
    return _get(f"/containers/{container_id}/health/history", params={"hours": hours})


# ═══════════════════════════════════════════
# Snapshots
# ═══════════════════════════════════════════

@server.tool(description="List LXD snapshots for a container")
def snapshots_list(container_id: str) -> list:
    return _get(f"/containers/{container_id}/snapshots")


@server.tool(description="Create an LXD snapshot of a container")
def snapshot_create(
    container_id: str,
    name: str | None = None,
    tenant_id: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    body = {}
    if name:
        body["name"] = name
    return _route_direct_write(
        tool_name="snapshot_create",
        action_type="snapshot_create",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        diff={"snapshot_name": name or "auto"},
        payload={"container_id": container_id, **body},
        direct_executor=lambda: _post(f"/containers/{container_id}/snapshots", body=body),
    )


@server.tool(description="Restore a container from a snapshot")
def snapshot_restore(container_id: str, snapshot_name: str) -> dict:
    return _route_direct_write(
        tool_name="snapshot_restore",
        action_type="snapshot_restore",
        risk_class="high_risk_write",
        target_kind="container_snapshot",
        target_id=f"{container_id}:{snapshot_name}",
        payload={"container_id": container_id, "snapshot_name": snapshot_name},
        direct_executor=lambda: _post(
            f"/containers/{container_id}/snapshots/{snapshot_name}/restore"
        ),
        supported=False,
    )


@server.tool(description="Delete a snapshot")
def snapshot_delete(container_id: str, snapshot_name: str) -> dict:
    return _route_direct_write(
        tool_name="snapshot_delete",
        action_type="snapshot_delete",
        risk_class="break_glass",
        target_kind="container_snapshot",
        target_id=f"{container_id}:{snapshot_name}",
        payload={"container_id": container_id, "snapshot_name": snapshot_name},
        direct_executor=lambda: _delete(
            f"/containers/{container_id}/snapshots/{snapshot_name}"
        ),
        supported=False,
    )


# ═══════════════════════════════════════════
# Files (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="List directory contents inside a container")
def files_list(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/files", params={"path": path})


@server.tool(description="Read a file from inside a container")
def file_read(container_id: str, path: str) -> dict:
    return _get(f"/containers/{container_id}/files/{path.lstrip('/')}")


@server.tool(description="Write content to a file inside a container")
def file_write(container_id: str, path: str, content: str) -> dict:
    from raava.client import put
    return _route_direct_write(
        tool_name="file_write",
        action_type="file_write",
        risk_class="break_glass",
        target_kind="container_file",
        target_id=f"{container_id}:{path}",
        payload={"container_id": container_id, "path": path},
        direct_executor=lambda: put(
            f"/containers/{container_id}/files/{path.lstrip('/')}",
            json={"content": content},
        ),
        supported=False,
        break_glass_reason=(
            "Direct file_write is disabled in monolith-mcp. "
            "Use a Fleet Manager-approved maintenance action or local break-glass override."
        ),
    )


@server.tool(description="Delete a file or directory inside a container")
def file_delete(container_id: str, path: str) -> dict:
    return _route_direct_write(
        tool_name="file_delete",
        action_type="file_delete",
        risk_class="break_glass",
        target_kind="container_file",
        target_id=f"{container_id}:{path}",
        payload={"container_id": container_id, "path": path},
        direct_executor=lambda: _delete(
            f"/containers/{container_id}/files/{path.lstrip('/')}"
        ),
        supported=False,
    )


# ═══════════════════════════════════════════
# Git (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="Get git status inside a container (branch, modified/staged/untracked files)")
def git_status(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/git/status", params={"path": path})


@server.tool(description="AXI compact git status inside a container. Use git_status for raw JSON.")
def git_status_compact(container_id: str, path: str = "/home/agent", limit: int = DEFAULT_LIMIT) -> dict:
    payload = git_status(container_id=container_id, path=path)
    rows = []
    for key in ("modified", "staged", "untracked"):
        values = payload.get(key) or []
        if isinstance(values, str):
            values = [values]
        for value in values:
            rows.append({"state": key, "path": value})
    if not rows:
        branch = payload.get("branch") or "unknown"
        return {
            "ok": True,
            "summary": f"Git tree clean on {branch}.",
            "format": "toon",
            "data": _toon_table([{"branch": branch, "status": "clean"}], ["branch", "status"]),
            "returned": 1,
            "total": 1,
            "truncated": False,
            "help": [
                f"git_log(container_id='{container_id}', path='{path}', limit=5)",
                f"git_status(container_id='{container_id}', path='{path}') for raw JSON",
            ],
        }
    visible, meta = _truncate_rows(rows, limit)
    return {
        "ok": True,
        "summary": f"{len(rows)} git changes in {path}.",
        "format": "toon",
        "data": _toon_table(visible, ["state", "path"]),
        **meta,
        "help": [
            f"git_diff(container_id='{container_id}', path='{path}')",
            f"git_status(container_id='{container_id}', path='{path}') for raw JSON",
        ],
    }


@server.tool(description="Git commit all changes inside a container")
def git_commit(container_id: str, message: str, path: str = "/home/agent") -> dict:
    return _route_direct_write(
        tool_name="git_commit",
        action_type="git_commit",
        risk_class="break_glass",
        target_kind="container_git_repo",
        target_id=f"{container_id}:{path}",
        payload={"container_id": container_id, "message": message, "path": path},
        direct_executor=lambda: _post(
            f"/containers/{container_id}/git/commit",
            body={"message": message, "path": path},
        ),
        supported=False,
    )


@server.tool(description="Get git log from inside a container")
def git_log(container_id: str, path: str = "/home/agent", limit: int = 20) -> dict:
    return _get(f"/containers/{container_id}/git/log", params={"path": path, "limit": limit})


@server.tool(description="Git push from inside a container")
def git_push(container_id: str, path: str = "/home/agent") -> dict:
    return _route_direct_write(
        tool_name="git_push",
        action_type="git_push",
        risk_class="break_glass",
        target_kind="container_git_repo",
        target_id=f"{container_id}:{path}",
        payload={"container_id": container_id, "path": path},
        direct_executor=lambda: _post(
            f"/containers/{container_id}/git/push",
            body={"path": path},
        ),
        supported=False,
    )


@server.tool(description="Git pull inside a container")
def git_pull(container_id: str, path: str = "/home/agent") -> dict:
    return _route_direct_write(
        tool_name="git_pull",
        action_type="git_pull",
        risk_class="break_glass",
        target_kind="container_git_repo",
        target_id=f"{container_id}:{path}",
        payload={"container_id": container_id, "path": path},
        direct_executor=lambda: _post(
            f"/containers/{container_id}/git/pull",
            body={"path": path},
        ),
        supported=False,
    )


@server.tool(description="List git branches inside a container")
def git_branches(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/git/branches", params={"path": path})


@server.tool(description="Show uncommitted git diff inside a container")
def git_diff(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/git/diff", params={"path": path})


# ═══════════════════════════════════════════
# Provisioning
# ═══════════════════════════════════════════

@server.tool(description="List available provisioning templates (hermes, openclaw, etc)")
def templates_list() -> list:
    return _get("/templates")


@server.tool(description="Start provisioning a new agent container from a template")
def provision_start(
    template: str,
    tenant_id: str,
    agent_name: str,
    agent_role: str,
    unit_id: str | None = None,
    model: str | None = None,
    memory: str | None = None,
    cpu: str | None = None,
    disk: str | None = None,
    test: bool = False,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    body = {
        "template": template,
        "tenant_id": tenant_id,
        "agent_name": agent_name,
        "agent_role": agent_role,
    }
    if unit_id:
        body["unit_id"] = unit_id
    if model:
        body["model"] = model
    if memory:
        body["memory"] = memory
    if cpu:
        body["cpu"] = cpu
    if disk:
        body["disk"] = disk
    if test:
        body["test"] = True
    return _route_direct_write(
        tool_name="provision_start",
        action_type="provision_start",
        risk_class="high_risk_write",
        target_kind="provision_request",
        target_id=f"{tenant_id}:{agent_name}",
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        target_tuple=_build_target_tuple(
            tenant_id=tenant_id,
            environment=environment or _default_write_environment(),
            target_kind="provision_request",
            target_id=f"{tenant_id}:{agent_name}",
            extra={
                "template": template,
                "agent_role": agent_role,
                "unit_id": unit_id,
            },
        ),
        diff=body,
        payload=body,
        direct_executor=lambda: _post("/provision", body=body),
    )


@server.tool(description="Get the status of a provisioning job (steps, progress, errors)")
def provision_status(job_id: str) -> dict:
    return _get(f"/provision/{job_id}")


@server.tool(description="List recent provisioning jobs")
def provision_jobs(limit: int = 50) -> list:
    return _get("/provision", params={"limit": limit})


@server.tool(description="Cancel a running provisioning job")
def provision_cancel(job_id: str) -> dict:
    return _route_direct_write(
        tool_name="provision_cancel",
        action_type="provision_cancel",
        risk_class="operational_write",
        target_kind="provision_job",
        target_id=job_id,
        payload={"job_id": job_id},
        direct_executor=lambda: _post(f"/provision/{job_id}/cancel"),
        supported=False,
    )


@server.tool(description="Rollback artifacts from a failed/cancelled provision job; completed jobs require force=True")
def provision_rollback(
    job_id: str,
    force: bool = False,
    reason: str | None = None,
    delete_instance: bool = True,
    mark_container_deleted: bool = True,
) -> dict:
    body = {}
    if force:
        body["force"] = force
    if reason:
        body["reason"] = reason
    if not delete_instance:
        body["delete_instance"] = delete_instance
    if not mark_container_deleted:
        body["mark_container_deleted"] = mark_container_deleted
    return _route_direct_write(
        tool_name="provision_rollback",
        action_type="provision_rollback",
        risk_class="high_risk_write",
        target_kind="provision_job",
        target_id=job_id,
        payload={"job_id": job_id, **body},
        direct_executor=lambda: _post(f"/provision/{job_id}/rollback", body=body),
        supported=False,
    )


@server.tool(description="Retry a failed provisioning job")
def provision_retry(job_id: str) -> dict:
    return _route_direct_write(
        tool_name="provision_retry",
        action_type="provision_retry",
        risk_class="operational_write",
        target_kind="provision_job",
        target_id=job_id,
        payload={"job_id": job_id},
        direct_executor=lambda: _post(f"/provision/{job_id}/retry"),
        supported=False,
    )


@server.tool(description="Run one durable provision worker iteration; break-glass only from MCP")
def provision_worker_run_once(
    tenant_id: str,
    job_id: str | None = None,
    worker_id: str | None = None,
    stale_after_seconds: int | None = None,
) -> dict:
    body: dict[str, Any] = {}
    if job_id:
        body["job_id"] = job_id
    if worker_id:
        body["worker_id"] = worker_id
    if stale_after_seconds is not None:
        body["stale_after_seconds"] = stale_after_seconds
    return _route_direct_write(
        tool_name="provision_worker_run_once",
        action_type="provision_worker_run_once",
        risk_class="break_glass",
        target_kind="provision_worker",
        target_id=job_id or "next",
        tenant_id=tenant_id,
        payload=body,
        direct_executor=lambda: _post("/provision/worker/run-once", body=body),
        supported=False,
        break_glass_reason=(
            "Provision worker execution can create or resume live infrastructure; "
            "run it through the API worker/Cloud Run Job path or explicit break-glass."
        ),
    )


# ═══════════════════════════════════════════
# Runtime Changes / Migration
# ═══════════════════════════════════════════

@server.tool(description="Create a same-provider staged clone with safe default isolation settings")
def container_clone(
    container_id: str,
    clone_name: str | None = None,
    require_source_state: str = "STOPPED",
    stage: str = "staging",
    network_mode: str = "isolated",
    disable_agent_autostart: bool = True,
    disable_integrations: bool = True,
    stage_notes: str | None = None,
) -> dict:
    body = {
        "require_source_state": require_source_state,
        "stage": stage,
        "network_mode": network_mode,
        "disable_agent_autostart": disable_agent_autostart,
        "disable_integrations": disable_integrations,
    }
    if clone_name:
        body["clone_name"] = clone_name
    if stage_notes:
        body["stage_notes"] = stage_notes
    return _route_direct_write(
        tool_name="container_clone",
        action_type="container_clone",
        risk_class="high_risk_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id, **body},
        direct_executor=lambda: _post(f"/containers/{container_id}/clone", body=body),
        supported=False,
    )


@server.tool(description="Get runtime change status for a staged clone/promote/rollback flow")
def runtime_change_get(change_id: str) -> dict:
    return _get(f"/runtime-changes/{change_id}")


@server.tool(description="Record validation evidence for a runtime change")
def runtime_change_validate(
    change_id: str,
    status: str,
    evidence: dict | None = None,
) -> dict:
    body = {"status": status, "evidence": evidence or {}}
    return _route_direct_write(
        tool_name="runtime_change_validate",
        action_type="runtime_change_validate",
        risk_class="operational_write",
        target_kind="runtime_change",
        target_id=change_id,
        payload={"change_id": change_id, **body},
        direct_executor=lambda: _post(
            f"/runtime-changes/{change_id}/validation",
            body=body,
        ),
        supported=False,
    )


@server.tool(description="Promote a validated staged runtime change")
def runtime_change_promote(change_id: str) -> dict:
    return _route_direct_write(
        tool_name="runtime_change_promote",
        action_type="runtime_change_promote",
        risk_class="high_risk_write",
        target_kind="runtime_change",
        target_id=change_id,
        payload={"change_id": change_id},
        direct_executor=lambda: _post(f"/runtime-changes/{change_id}/promote", body={}),
        supported=False,
    )


@server.tool(description="Rollback a promoted runtime change to its rollback instance")
def runtime_change_rollback(change_id: str) -> dict:
    return _route_direct_write(
        tool_name="runtime_change_rollback",
        action_type="runtime_change_rollback",
        risk_class="high_risk_write",
        target_kind="runtime_change",
        target_id=change_id,
        payload={"change_id": change_id},
        direct_executor=lambda: _post(
            f"/runtime-changes/{change_id}/rollback",
            body={},
        ),
        supported=False,
    )


@server.tool(description="Clone a container and run Hermes migration on the staged clone")
def clone_and_migrate_hermes(
    container_id: str,
    target_name: str,
    migration: dict | None = None,
    verify_after: bool = True,
) -> dict:
    body = {
        "target_name": target_name,
        "verify_after": verify_after,
    }
    if migration:
        body["migration"] = migration
    return _route_direct_write(
        tool_name="clone_and_migrate_hermes",
        action_type="clone_and_migrate_hermes",
        risk_class="high_risk_write",
        target_kind="container",
        target_id=container_id,
        payload={"container_id": container_id, **body},
        direct_executor=lambda: _post(
            f"/containers/{container_id}/clone-and-migrate/hermes",
            body=body,
        ),
        supported=False,
    )


# ═══════════════════════════════════════════
# Change Requests (Proposal-first draft stubs)
# ═══════════════════════════════════════════

@server.tool(description="Summarize the policy-relevant diff between current and desired state and emit a compact TOON string.")
def policy_diff(
    current: dict | None = None,
    desired: dict | None = None,
    action_type: str = "unspecified",
) -> dict:
    return {
        "ok": True,
        **_policy_diff_helper(current=current, desired=desired, action_type=action_type),
    }


@server.tool(description="Prepare a rollback-plan scaffold for a proposed write and emit a compact TOON string.")
def rollback_plan(
    action_type: str,
    target_kind: str,
    target_id: str,
    fallback_tool: str,
    plan: dict | None = None,
) -> dict:
    return _rollback_plan_helper(
        action_type=action_type,
        target_kind=target_kind,
        target_id=target_id,
        fallback_tool=fallback_tool,
        plan=plan,
    )


@server.tool(description="Evaluate whether a proposal passes the staging gate for its environment and emit a compact TOON string.")
def staging_gate(
    environment: str,
    action_type: str,
    target_id: str,
    staging_evidence: dict | None = None,
) -> dict:
    return _staging_gate_helper(
        environment=environment,
        action_type=action_type,
        target_id=target_id,
        staging_evidence=staging_evidence,
    )


@server.tool(description="Describe the proposal-first contract used by monolith-mcp and the Fleet Manager API.")
def change_request_contract() -> dict:
    return {
        "ok": True,
        "stub": True,
        "status": "draft_contract_only",
        "object": "change_request_contract",
        "version": "phase1",
        "submission_target": "POST /api/fleet-manager/actions",
        "api_dependency": "Fleet API Fleet Manager action routes",
        "risk_classes": [
            "read",
            "sensitive_read",
            "proposal_write",
            "operational_write",
            "high_risk_write",
            "break_glass",
        ],
        "required_fields": [
            "tenant_id",
            "environment",
            "target_kind",
            "target_id",
            "action_type",
            "risk_class",
        ],
        "create_fields": [
            "tenant_id",
            "environment",
            "target_kind",
            "target_id",
            "target_tuple",
            "action_type",
            "tool_name",
            "risk_class",
            "current_state_hash",
            "desired_state_hash",
            "diff",
            "payload",
            "policy_decision",
            "required_evidence",
            "staging_evidence",
            "rollback_plan",
            "verification_plan",
            "quota_estimate",
            "idempotency_key",
            "expires_at",
        ],
        "lifecycle_endpoints": {
            "create": "/api/change-requests",
            "validate": "/api/change-requests/{id}/validate",
            "request_approval": "/api/change-requests/{id}/request-approval",
            "approve": "/api/change-requests/{id}/approve",
            "deny": "/api/change-requests/{id}/deny",
            "list": "/api/change-requests",
            "get": "/api/change-requests/{id}",
            "events": "/api/change-requests/{id}/events",
            "queue": "/api/change-requests/{id}/queue",
            "cancel": "/api/change-requests/{id}/cancel",
        },
        "optional_fields": [
            "tool_name",
            "target_tuple",
            "current_state_hash",
            "desired_state_hash",
            "diff",
            "payload",
            "policy_decision",
            "required_evidence",
            "staging_evidence",
            "rollback_plan",
            "verification_plan",
            "quota_estimate",
            "idempotency_key",
        ],
        "notes": [
            "No direct runtime mutation is performed by MCP change-request tools.",
            "queue is a future deferred state transition and does not execute changes.",
        ],
    }


@server.tool(description="Prepare a local-only Fleet Manager action draft. Does not write to the control plane.")
def change_request_create(
    tenant_id: str,
    environment: str,
    target_kind: str,
    target_id: str,
    action_type: str,
    risk_class: ChangeRequestRiskClass = "proposal_write",
    tool_name: str | None = None,
    target_tuple: dict | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    diff: dict | None = None,
    payload: dict | None = None,
    policy_decision: dict | None = None,
    required_evidence: list[str] | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
    expires_at: str | None = None,
) -> dict:
    if expires_at is not None:
        body: dict[str, Any] = {
            "tenant_id": tenant_id,
            "environment": environment,
            "target_kind": target_kind,
            "target_id": target_id,
            "action_type": action_type,
            "risk_class": risk_class,
        }
        if target_tuple is not None:
            body["target_tuple"] = target_tuple
        if tool_name is not None:
            body["tool_name"] = tool_name
        if payload is not None:
            body["payload"] = payload
        if diff is not None:
            body["diff"] = diff
        if policy_decision is not None:
            body["policy_decision"] = policy_decision
        if required_evidence is not None:
            body["required_evidence"] = required_evidence
        if staging_evidence is not None:
            body["staging_evidence"] = staging_evidence
        if rollback_plan is not None:
            body["rollback_plan"] = rollback_plan
        if verification_plan is not None:
            body["verification_plan"] = verification_plan
        if quota_estimate is not None:
            body["quota_estimate"] = quota_estimate
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key
        body["expires_at"] = expires_at
        if current_state_hash is not None:
            body["current_state_hash"] = current_state_hash
        if desired_state_hash is not None:
            body["desired_state_hash"] = desired_state_hash
        return _raw_post("/change-requests", body=body)

    return _change_request_stub(
        tenant_id=tenant_id,
        environment=environment,
        target_kind=target_kind,
        target_id=target_id,
        action_type=action_type,
        risk_class=risk_class,
        tool_name=tool_name,
        target_tuple=target_tuple,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        diff=diff,
        payload=payload,
        policy_decision=policy_decision,
        required_evidence=required_evidence,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Validate a draft change request via persisted evidence")
def change_request_validate(request_id: str) -> dict | list:
    return _raw_post(f"/change-requests/{request_id}/validate")


@server.tool(description="Request operator approval for a validated proposal")
def change_request_request_approval(request_id: str) -> dict | list:
    return _raw_post(f"/change-requests/{request_id}/request-approval")


@server.tool(description="Approve a validated change request")
def change_request_approve(
    request_id: str,
    approval_scope: str,
    target_tuple: dict,
    current_state_hash: str,
    desired_state_hash: str,
    diff: dict,
    comment: str | None = None,
) -> dict | list:
    body: dict[str, Any] = {
        "approval_scope": approval_scope,
        "target_tuple": target_tuple,
        "current_state_hash": current_state_hash,
        "desired_state_hash": desired_state_hash,
        "diff": diff,
    }
    if comment is not None:
        body["comment"] = comment
    return _raw_post(f"/change-requests/{request_id}/approve", body=body)


@server.tool(description="Deny a change request")
def change_request_deny(request_id: str, comment: str | None = None) -> dict | list:
    body = {"comment": comment} if comment else {}
    return _raw_post(f"/change-requests/{request_id}/deny", body=body if body else None)


@server.tool(description="List change requests")
def change_request_list(
    tenant_id: str | None = None,
    status: str | None = None,
    limit: int = 50,
) -> dict | list:
    params = {"limit": limit}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if status:
        params["status"] = status
    return _raw_get("/change-requests", params=params)


@server.tool(description="Get details for a change request")
def change_request_get(request_id: str) -> dict | list:
    return _raw_get(f"/change-requests/{request_id}")


@server.tool(description="Get change request events")
def change_request_events(request_id: str, after_id: int = 0) -> dict | list:
    return _raw_get(f"/change-requests/{request_id}/events", params={"after_id": after_id})


@server.tool(description="Queue an approved proposal for future deferred processing (non-executing)")
def change_request_queue(request_id: str) -> dict | list:
    return _raw_post(f"/change-requests/{request_id}/queue")


@server.tool(description="Cancel a proposal-only change request")
def change_request_cancel(request_id: str, reason: str | None = None) -> dict | list:
    body = {"comment": reason} if reason else None
    return _raw_post(f"/change-requests/{request_id}/cancel", body=body)


@server.tool(description="List Fleet Manager actions to inspect pending, in-flight, blocked, or conflicting proposals.")
def fleet_manager_action_list(
    tenant_id: str | None = None,
    status: str | None = None,
    limit: int = 50,
) -> dict:
    response = _get(
        "/fleet-manager/actions",
        params={
            key: value
            for key, value in {
                "tenant_id": tenant_id,
                "status": status,
                "limit": limit,
            }.items()
            if value is not None
        },
    )
    actions = response.get("actions", []) if isinstance(response, dict) else []
    return {
        "ok": True,
        "toon": _compact_toon(
            "fleet_manager_actions",
            count=len(actions),
            tenant=tenant_id or "all",
            status=status or "all",
        ),
        "actions": actions,
    }


@server.tool(description="Get one Fleet Manager action by id, including status, target binding, payload, and execution evidence.")
def fleet_manager_action_get(action_id: str) -> dict:
    response = _get(f"/fleet-manager/actions/{action_id}")
    return {
        "ok": True,
        "toon": _compact_toon(
            "fleet_manager_action",
            id=response.get("id"),
            status=response.get("status"),
            tool=response.get("tool_name"),
            tenant=response.get("tenant_id"),
        ),
        "action": response,
    }


@server.tool(description="Submit a policy-gated Fleet Manager action proposal to the Fleet API. Does not execute the write.")
def fleet_manager_action_create(
    tenant_id: str,
    action_type: str,
    tool_name: str,
    risk_class: ChangeRequestRiskClass,
    target_environment: str = "production",
    payload: dict | None = None,
    run_id: str | None = None,
    idempotency_key: str | None = None,
    target_kind: str | None = None,
    target_id: str | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    diff: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    staging_evidence: dict | None = None,
    quota_estimate: dict | None = None,
) -> dict:
    body: dict[str, Any] = {
        "tenant_id": tenant_id,
        "action_type": action_type,
        "tool_name": tool_name,
        "risk_class": risk_class,
        "target_environment": target_environment,
        "payload": payload or {},
    }
    optional = {
        "run_id": run_id,
        "idempotency_key": idempotency_key,
        "target_kind": target_kind,
        "target_id": target_id,
        "current_state_hash": current_state_hash,
        "desired_state_hash": desired_state_hash,
        "diff": diff,
        "rollback_plan": rollback_plan,
        "verification_plan": verification_plan,
        "staging_evidence": staging_evidence,
        "quota_estimate": quota_estimate,
    }
    body.update({key: value for key, value in optional.items() if value is not None})
    response = _post("/fleet-manager/actions", body=body)
    return {
        "ok": True,
        "submission_target": "POST /api/fleet-manager/actions",
        "toon": _compact_toon(
            "fleet_manager_action",
            id=response.get("id"),
            status=response.get("status"),
            tool=tool_name,
            tenant=tenant_id,
        ),
        "action": response,
    }


@server.tool(description="Approve a pending Fleet Manager action with bound evidence. Does not execute the write.")
def fleet_manager_action_approve(
    action_id: str,
    approval_scope: str | None = None,
    comment: str | None = None,
    evidence: dict | None = None,
) -> dict:
    body = {
        "approval_scope": approval_scope,
        "comment": comment,
        "evidence": evidence or {},
    }
    response = _post(f"/fleet-manager/actions/{action_id}/approve", body=body)
    return {
        "ok": True,
        "toon": _compact_toon(
            "fleet_manager_approval",
            id=action_id,
            status=response.get("status"),
            scope=approval_scope,
        ),
        "action": response,
    }


@server.tool(description="Execute an approved Fleet Manager action through the API-owned autonomous write executor.")
def fleet_manager_action_execute(action_id: str) -> dict:
    response = _post(f"/fleet-manager/actions/{action_id}/execute", body={})
    return {
        "ok": True,
        "toon": _compact_toon(
            "fleet_manager_execute",
            id=action_id,
            status=response.get("status"),
            tool=response.get("tool_name"),
        ),
        "action": response,
    }


@server.tool(description="Get Fleet Manager autonomous-write metrics from the API.")
def fleet_manager_metrics() -> dict:
    response = _get("/fleet-manager/metrics")
    return {
        "ok": True,
        "toon": _compact_toon(
            "fleet_manager_metrics",
            actions=response.get("action_count"),
            succeeded=response.get("succeeded"),
            blocked=response.get("execution_blocked"),
            success_rate=response.get("success_rate"),
        ),
        "metrics": response,
    }


@server.tool(description="Prepare a local-only proposal for runtime_config_patch using the Fleet Manager action contract.")
def change_request_runtime_config_patch(
    tenant_id: str,
    environment: str,
    container_id: str,
    env: dict | None = None,
    config: dict | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    diff = {}
    if env:
        diff["env"] = env
    if config:
        diff["config"] = config

    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="container",
        target_id=container_id,
        action_type="runtime_config_patch",
        risk_class="proposal_write",
        tool_name="runtime_config_patch",
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        diff=diff,
        payload={
            "container_id": container_id,
            "env": env or {},
            "config": config or {},
        },
        policy_decision={
            "write_path": "proposal_first_draft",
            "fallback_tool": "runtime_config_patch",
        },
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan
        or {"type": "previous_runtime_config", "tool": "runtime_config_show"},
        verification_plan=verification_plan
        or {
            "tool": "runtime_config_show",
            "target": container_id,
        },
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Prepare a local-only proposal for agent_restart and attach policy, rollback, and staging helper outputs.")
def proposal_agent_restart(
    tenant_id: str,
    environment: str,
    container_id: str,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="agent_service",
        target_id=container_id,
        action_type="agent_restart",
        tool_name="agent_restart",
        risk_class="operational_write",
        diff={"operation": "restart"},
        payload={"container_id": container_id},
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Prepare a local-only proposal for container_update and attach policy, rollback, and staging helper outputs.")
def proposal_container_update(
    tenant_id: str,
    environment: str,
    container_id: str,
    agent_name: str | None = None,
    agent_role: str | None = None,
    model: str | None = None,
    memory_limit: str | None = None,
    cpu_limit: str | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    diff = {}
    if agent_name:
        diff["agent_name"] = agent_name
    if agent_role:
        diff["agent_role"] = agent_role
    if model:
        diff["model"] = model
    if memory_limit:
        diff["memory_limit"] = memory_limit
    if cpu_limit:
        diff["cpu_limit"] = cpu_limit

    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="container",
        target_id=container_id,
        action_type="container_update",
        tool_name="container_update",
        risk_class="operational_write",
        diff=diff,
        payload={"container_id": container_id, **diff},
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Prepare a local-only proposal for snapshot_create and attach policy, rollback, and staging helper outputs.")
def proposal_snapshot_create(
    tenant_id: str,
    environment: str,
    container_id: str,
    name: str | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    payload = {"container_id": container_id}
    if name:
        payload["name"] = name

    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="container",
        target_id=container_id,
        action_type="snapshot_create",
        tool_name="snapshot_create",
        risk_class="operational_write",
        diff={"snapshot_name": name or "auto"},
        payload=payload,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Prepare a local-only proposal for provision_start and attach policy, rollback, and staging helper outputs.")
def proposal_provision_start(
    environment: str,
    template: str,
    tenant_id: str,
    agent_name: str,
    agent_role: str,
    unit_id: str | None = None,
    model: str | None = None,
    memory: str | None = None,
    cpu: str | None = None,
    disk: str | None = None,
    test: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    payload = {
        "template": template,
        "tenant_id": tenant_id,
        "agent_name": agent_name,
        "agent_role": agent_role,
    }
    if unit_id:
        payload["unit_id"] = unit_id
    if model:
        payload["model"] = model
    if memory:
        payload["memory"] = memory
    if cpu:
        payload["cpu"] = cpu
    if disk:
        payload["disk"] = disk
    if test:
        payload["test"] = True

    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="provision_request",
        target_id=f"{tenant_id}:{agent_name}",
        action_type="provision_start",
        tool_name="provision_start",
        risk_class="high_risk_write",
        target_tuple=_build_target_tuple(
            tenant_id=tenant_id,
            environment=environment,
            target_kind="provision_request",
            target_id=f"{tenant_id}:{agent_name}",
            extra={
                "template": template,
                "agent_role": agent_role,
                "unit_id": unit_id,
            },
        ),
        diff=payload,
        payload=payload,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Prepare a local-only proposal for tenant_create and attach policy, rollback, and staging helper outputs.")
def proposal_tenant_create(
    environment: str,
    tenant_id: str,
    name: str,
    contact: str | None = None,
    notes: str | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    diff = {"name": name}
    payload = {"id": tenant_id, "name": name}
    if contact:
        diff["contact"] = contact
        payload["contact"] = contact
    if notes:
        diff["notes"] = notes
        payload["notes"] = notes

    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="tenant",
        target_id=tenant_id,
        action_type="tenant_create",
        tool_name="tenant_create",
        risk_class="high_risk_write",
        diff=diff,
        payload=payload,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


@server.tool(description="Prepare a local-only proposal for runtime_config_apply and attach policy, rollback, and staging helper outputs.")
def proposal_runtime_config_apply(
    tenant_id: str,
    environment: str,
    container_id: str,
    service: str = "gateway",
    action: str = "restart",
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    diff = {"service": service, "action": action}

    return _proposal_change_request(
        tenant_id=tenant_id,
        environment=environment,
        target_kind="container",
        target_id=container_id,
        action_type="runtime_config_apply",
        tool_name="runtime_config_apply",
        risk_class="operational_write",
        diff=diff,
        payload={"container_id": container_id, **diff},
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
    )


# ═══════════════════════════════════════════
# Tenants
# ═══════════════════════════════════════════

@server.tool(description="List all tenants")
def tenants_list() -> list:
    return _get("/tenants")


@server.tool(description="Get tenant detail with containers and units")
def tenant_detail(tenant_id: str) -> dict:
    return _get(f"/tenants/{tenant_id}")


@server.tool(description="Create a new tenant")
def tenant_create(
    tenant_id: str,
    name: str,
    contact: str | None = None,
    notes: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    body = {"id": tenant_id, "name": name}
    if contact:
        body["contact"] = contact
    if notes:
        body["notes"] = notes
    diff = {"name": name}
    if contact:
        diff["contact"] = contact
    if notes:
        diff["notes"] = notes
    return _route_direct_write(
        tool_name="tenant_create",
        action_type="tenant_create",
        risk_class="high_risk_write",
        target_kind="tenant",
        target_id=tenant_id,
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        diff=diff,
        payload=body,
        direct_executor=lambda: _post("/tenants", body=body),
    )


@server.tool(description="List business units for a tenant")
def tenant_units(tenant_id: str) -> list:
    return _get(f"/tenants/{tenant_id}/units")


# ═══════════════════════════════════════════
# Metrics
# ═══════════════════════════════════════════

@server.tool(description="Get token usage summary — total tokens, cost, message count")
def metrics_tokens(container_id: str | None = None, hours: int = 24) -> dict:
    params = {"hours": hours}
    if container_id:
        params["container_id"] = container_id
    return _get("/metrics/tokens", params=params)


@server.tool(description="Get token usage broken down by container")
def metrics_tokens_by_container(hours: int = 24) -> list:
    return _get("/metrics/tokens/by-container", params={"hours": hours})


@server.tool(description="Get average fleet CPU and memory utilization")
def metrics_fleet_utilization() -> dict:
    return _get("/metrics/fleet-utilization")


@server.tool(description="Get agent/container restart count from audit log")
def metrics_restarts(container_id: str | None = None, hours: int = 24) -> dict:
    params = {"hours": hours}
    if container_id:
        params["container_id"] = container_id
    return _get("/metrics/restarts", params=params)


@server.tool(description="Read-only cloud/provider snapshot for fleet RCA; no raw gcloud fallback.")
def metrics_cloud_snapshot(
    container_id: str | None = None,
    probe_provider: bool = False,
) -> dict:
    params: dict[str, object] = {"probe_provider": probe_provider}
    if container_id:
        params["container_id"] = container_id
    return _get("/metrics/cloud-snapshot", params=params)


@server.tool(description="Read-only VM/provider snapshot for one runtime; provider probes go through Fleet API.")
def metrics_vm_snapshot(
    container_id: str,
    probe_provider: bool = False,
) -> dict:
    return _get(
        "/metrics/vm-snapshot",
        params={"container_id": container_id, "probe_provider": probe_provider},
    )


@server.tool(description="Read-only agent runtime metrics snapshot with health, token, restart, and audit signals.")
def metrics_runtime_snapshot(container_id: str, hours: int = 24) -> dict:
    return _get(
        "/metrics/runtime-snapshot",
        params={"container_id": container_id, "hours": hours},
    )


@server.tool(description="Read-only layered RCA bundle combining cloud, VM, and runtime metrics.")
def metrics_agent_rca_bundle(
    container_id: str,
    hours: int = 24,
    probe_provider: bool = False,
) -> dict:
    return _get(
        "/metrics/agent-rca-bundle",
        params={
            "container_id": container_id,
            "hours": hours,
            "probe_provider": probe_provider,
        },
    )


@server.tool(description="Read-only host-level CPU, memory, disk, load, and VM count metrics.")
def system_host_health() -> dict:
    return _get("/system/host")


@server.tool(description="Read-only host-level metrics history for RCA trend checks.")
def system_host_history(hours: int = 24) -> dict:
    return _get("/system/host/history", params={"hours": hours})


# ═══════════════════════════════════════════
# Runtime Configuration
# ═══════════════════════════════════════════

@server.tool(description="Read effective and pending runtime config for one container. Use before model, env, or gateway changes.")
def runtime_config_show(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/runtime-config")


@server.tool(description="Get runtime config for a container")
def runtime_config_get(container_id: str) -> dict | list:
    return _raw_get(f"/containers/{container_id}/runtime-config")


@server.tool(description="Validate a pending runtime config patch for one container without applying it.")
def runtime_config_validate(container_id: str, patch: dict | None = None) -> dict | list:
    body = {"patch": patch} if patch else {}
    return _raw_post(f"/containers/{container_id}/runtime-config/validate", body=body)


@server.tool(description="Stage allowlisted runtime config/env changes for one container. Requires approval and staging-first policy.")
def runtime_config_patch(
    container_id: str,
    env: dict | None = None,
    config: dict | None = None,
    tenant_id: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    rollout_notes: str | None = None,
    target_tuple: dict | None = None,
    tool_name: str | None = None,
    current_state: dict | None = None,
    desired_state: dict | None = None,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    if not env and not config:
        raise ValueError("env or config must be provided")

    body = {}
    if env:
        body["env"] = env
    if config:
        body["config"] = config

    proposal_context_requested = bool(tenant_id and environment and not submit_action)
    if proposal_context_requested and not _direct_writes_requested():
        computed_current_hash = _stable_hash(current_state) if current_state is not None else None
        computed_desired_hash = _stable_hash(desired_state) if desired_state is not None else None
        current_hash = current_state_hash or computed_current_hash
        desired_hash = desired_state_hash or computed_desired_hash
        if not current_hash or not desired_hash:
            raise ValueError(
                "current_state_hash and desired_state_hash are required unless current_state and desired_state are provided"
            )
        return _raw_post(
            "/change-requests",
            body={
                "tenant_id": tenant_id,
                "environment": environment,
                "target_kind": "container",
                "target_id": container_id,
                "action_type": "runtime_config_patch",
                "risk_class": "proposal_write",
                "target_tuple": target_tuple,
                "tool_name": tool_name or "runtime_config_patch",
                "payload": {"container_id": container_id, "patch": body},
                "diff": body,
                "policy_decision": {
                    "approval_scope": "operator",
                    "policy_diff": {"type": "runtime_config_patch", "changes": body},
                    "required_checks": ["runtime_config_validate"],
                },
                "required_evidence": [
                    "policy_diff",
                    "rollback_plan",
                    "verification_plan",
                    "staging_evidence",
                ],
                "staging_evidence": {
                    "rationale": rollout_notes
                    or "Runtime config must validate in staging before production apply."
                },
                "rollback_plan": {
                    "tool": "runtime_config_get",
                    "target_id": container_id,
                },
                "verification_plan": {
                    "tool": "runtime_config_validate",
                    "target_id": container_id,
                    "required_checks": ["health", "agent_status"],
                },
                "current_state_hash": current_hash,
                "desired_state_hash": desired_hash,
            },
        )

    return _route_direct_write(
        tool_name=tool_name or "runtime_config_patch",
        action_type="runtime_config_patch",
        risk_class="proposal_write",
        target_kind="container",
        target_id=container_id,
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan
        or {"type": "previous_runtime_config", "tool": "runtime_config_show"},
        verification_plan=verification_plan
        or {"tool": "runtime_config_show", "target": container_id},
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        target_tuple=target_tuple,
        diff=body,
        payload={"container_id": container_id, "env": env or {}, "config": config or {}},
        direct_executor=lambda: _patch(f"/containers/{container_id}/runtime-config", body=body),
    )


@server.tool(description="Apply pending runtime config and restart/reload gateway or agent. Requires approval and post-change verification.")
def runtime_config_apply(
    container_id: str,
    service: str = "gateway",
    action: str = "restart",
    tenant_id: str | None = None,
    environment: str | None = None,
    submit_action: bool = False,
    current_state_hash: str | None = None,
    desired_state_hash: str | None = None,
    staging_evidence: dict | None = None,
    rollback_plan: dict | None = None,
    verification_plan: dict | None = None,
    quota_estimate: dict | None = None,
    idempotency_key: str | None = None,
) -> dict:
    body = {"service": service, "action": action}
    return _route_direct_write(
        tool_name="runtime_config_apply",
        action_type="runtime_config_apply",
        risk_class="operational_write",
        target_kind="container",
        target_id=container_id,
        tenant_id=tenant_id,
        environment=environment,
        submit_action=submit_action,
        current_state_hash=current_state_hash,
        desired_state_hash=desired_state_hash,
        staging_evidence=staging_evidence,
        rollback_plan=rollback_plan,
        verification_plan=verification_plan,
        quota_estimate=quota_estimate,
        idempotency_key=idempotency_key,
        diff=body,
        payload={"container_id": container_id, **body},
        direct_executor=lambda: _post(
            f"/containers/{container_id}/runtime-config/apply",
            body=body,
        ),
    )


# ═══════════════════════════════════════════
# System (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="List processes running inside a container (CPU, memory per process)")
def system_processes(container_id: str, limit: int = 25) -> dict:
    return _get(f"/containers/{container_id}/system/processes", params={"limit": limit})


@server.tool(description="Get environment variables from a container (sensitive values redacted)")
def system_env(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/system/env")


@server.tool(description="Check service connectivity from inside a container (inference API, 1Password, MCP, etc)")
def system_connections(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/system/connections")


@server.tool(description="Get OS and system info from a container (uptime, kernel, restart count)")
def system_info(container_id: str, hours: int = 24) -> dict:
    return _get(f"/containers/{container_id}/system/info", params={"hours": hours})


# ═══════════════════════════════════════════
# Sessions
# ═══════════════════════════════════════════

def sessions_list() -> list:
    return _get("/sessions")


def session_kill(session_id: str) -> dict:
    return _route_direct_write(
        tool_name="session_kill",
        action_type="session_kill",
        risk_class="break_glass",
        target_kind="terminal_session",
        target_id=session_id,
        payload={"session_id": session_id},
        direct_executor=lambda: _delete(f"/sessions/{session_id}"),
        supported=False,
    )


# ═══════════════════════════════════════════
# Terminal / Chat Agent
# ═══════════════════════════════════════════

@server.tool(description="Send a message to the fleet management agent and get a response. The agent can execute fleet operations autonomously.")
def chat(message: str, session_id: str | None = None, context: str | None = None) -> dict:
    body = {"content": message}
    if session_id:
        body["session_id"] = session_id
    if context:
        body["context"] = context
    return _post("/terminal/message", body=body)


# ═══════════════════════════════════════════
# Extended API Coverage
# ═══════════════════════════════════════════

@server.tool(description="Raw Fleet API GET for paths not yet mapped to dedicated tools")
def api_get(path: str, params: dict | None = None) -> dict | list:
    return _raw_get(path, params=params)


def api_post(path: str, body: dict | None = None) -> dict | list:
    return _raw_write_tool(
        tool_name="api_post",
        method="post",
        path=path,
        executor=lambda p: _raw_post(p, body=body),
    )


def api_patch(path: str, body: dict | None = None) -> dict | list:
    return _raw_write_tool(
        tool_name="api_patch",
        method="patch",
        path=path,
        executor=lambda p: _raw_patch(p, body=body),
    )


def api_put(path: str, body: dict | None = None) -> dict | list:
    return _raw_write_tool(
        tool_name="api_put",
        method="put",
        path=path,
        executor=lambda p: _raw_put(p, body=body),
    )


def api_delete(path: str) -> dict | list:
    return _raw_write_tool(
        tool_name="api_delete",
        method="delete",
        path=path,
        executor=_raw_delete,
    )


@server.tool(description="Preview first SSE events from any stream endpoint")
def api_stream_preview(path: str, params: dict | None = None, max_events: int = 5, max_seconds: int = 12) -> dict:
    return _stream_preview(path, params=params, max_events=max_events, max_seconds=max_seconds)


@server.tool(description="Get Fleet API liveness health endpoint")
def api_health() -> dict | list:
    return _raw_get("/health")


@server.tool(description="Get Fleet API readiness endpoint")
def api_ready() -> dict | list:
    return _raw_get("/ready")


@server.tool(description="Get fleet overview dashboard payload")
def fleet_overview() -> dict | list:
    return _raw_get("/fleet/overview")


@server.tool(description="Get global alerts list")
def alerts_list() -> dict | list:
    return _raw_get("/alerts")


def terminal_session_create(session_type: str = "standard", context: str | None = None, user_role: str | None = None) -> dict | list:
    body: dict[str, Any] = {"type": session_type}
    if context is not None:
        body["context"] = context
    if user_role is not None:
        body["user_role"] = user_role
    return _raw_post("/terminal/sessions", body=body)


def terminal_sessions_list() -> dict | list:
    return _raw_get("/terminal/sessions")


def terminal_session_messages(session_id: str, limit: int = 100) -> dict | list:
    return _raw_get(f"/terminal/sessions/{session_id}/messages", params={"limit": limit})


def terminal_session_close(session_id: str) -> dict | list:
    return _raw_delete(f"/terminal/sessions/{session_id}")


@server.tool(description="Preview streaming terminal response events")
def terminal_message_stream_preview(content: str, session_id: str | None = None, max_events: int = 5, max_seconds: int = 12) -> dict:
    body: dict[str, Any] = {"content": content}
    if session_id:
        body["session_id"] = session_id
    events: list[dict | str] = []
    started = time.monotonic()
    with _client() as c:
        with c.stream("POST", "/api/terminal/message/stream", json=body) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines():
                if time.monotonic() - started > max_seconds:
                    break
                if not line:
                    continue
                if line.startswith("data: "):
                    payload = line[6:]
                    try:
                        events.append(json.loads(payload))
                    except Exception:
                        events.append(payload)
                if len(events) >= max_events:
                    break
    return {"events": events, "truncated": len(events) >= max_events}


@server.tool(description="Preview fleet stream SSE events")
def stream_fleet_preview(hours: int = 24, events: str | None = None, max_events: int = 5, max_seconds: int = 12) -> dict:
    params = {"hours": hours}
    if events:
        params["events"] = events
    return _stream_preview("/stream/fleet", params=params, max_events=max_events, max_seconds=max_seconds)


@server.tool(description="Preview single-container stream SSE events")
def stream_container_preview(container_id: str, hours: int = 24, events: str | None = None, max_events: int = 5, max_seconds: int = 12) -> dict:
    params = {"hours": hours}
    if events:
        params["events"] = events
    return _stream_preview(f"/stream/container/{container_id}", params=params, max_events=max_events, max_seconds=max_seconds)


@server.tool(description="Preview tenant stream SSE events")
def stream_tenant_preview(tenant_id: str, hours: int = 24, events: str | None = None, max_events: int = 5, max_seconds: int = 12) -> dict:
    params = {"hours": hours}
    if events:
        params["events"] = events
    return _stream_preview(f"/stream/tenant/{tenant_id}", params=params, max_events=max_events, max_seconds=max_seconds)


def main():
    transport = _normalize_transport(os.environ.get("MONOLITH_MCP_TRANSPORT"))
    _require_hosted_auth(transport)
    if transport == "sse":
        server.run("sse", mount_path=os.environ.get("MONOLITH_MCP_MOUNT_PATH"))
        return
    server.run(transport)


def http_main():
    os.environ.setdefault("MONOLITH_MCP_TRANSPORT", "streamable-http")
    main()


if __name__ == "__main__":
    main()
