"""CLI configuration management."""

import typer

from raava import config, display

app = typer.Typer(no_args_is_help=True)


def _display_config() -> dict:
    data = config.all_config()
    if data.get("api_key"):
        data["api_key"] = "<redacted>"
    return data


@app.command()
def show():
    """Show current configuration."""
    display.detail(_display_config(), title="Monolith CLI Config")


@app.command("set")
def set_config(
    key: str = typer.Argument(..., help="Config key (api_url, timeout, output)"),
    value: str = typer.Argument(..., help="Value"),
):
    """Set a config value."""
    if key not in config.VALID_KEYS:
        display.print_warning(f"Unknown key '{key}'. Valid keys: {', '.join(sorted(config.VALID_KEYS))}")
    old = config.get(key)
    config.set_value(key, value)
    display.print_success(f"{key}: {old} -> {config.get(key)}")


@app.command("get")
def get_config(
    key: str = typer.Argument(..., help="Config key to read"),
):
    """Get a single config value."""
    value = config.get(key)
    if value is None:
        display.print_error(f"Key '{key}' not found")
        raise typer.Exit(1)
    display.console.print(f"[bold]{key}:[/] {value}")


@app.command()
def reset(
    key: str = typer.Argument(..., help="Config key to reset to default"),
):
    """Reset a config key to its default value."""
    if key not in config.VALID_KEYS:
        display.print_error(f"Unknown key '{key}'. Valid keys: {', '.join(sorted(config.VALID_KEYS))}")
        raise typer.Exit(1)
    config.delete_key(key)
    display.print_success(f"'{key}' reset to default: {config.get(key)}")


@app.command()
def path():
    """Show the config file path."""
    display.console.print(f"[bold]Config file:[/] {config.CONFIG_FILE}")
    exists = config.CONFIG_FILE.exists()
    display.console.print(f"[bold]Exists:[/] {'yes' if exists else 'no'}")
