"""Container lifecycle commands."""

import time
from collections.abc import Callable
from typing import TypeVar

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)
_T = TypeVar("_T")


_PROVIDER_LABELS: dict[str, str] = {
    "lxd": "Bare Metal",
    "aws": "AWS",
    "gcp": "GCP",
}


def _container_rows() -> list[dict[str, object]]:
    data = client.get("/containers")
    rows = data.get("containers", [])
    for row in rows:
        health = row.get("health") or {}
        row["_cpu"] = display.percent_bar(health.get("cpu", 0), color="cyan")
        row["_mem"] = display.percent_bar(health.get("mem", 0), color="green")
        raw_provider = row.get("provider") or ""
        row["_provider"] = _PROVIDER_LABELS.get(raw_provider, raw_provider)
    return rows


def _render_containers(
    rows: list[dict[str, object]], title: str = "Containers"
) -> None:
    cols = [
        ("ID", "id"),
        ("Tenant", "tenant"),
        ("Agent", "agent_name"),
        ("Role", "agent_role"),
        ("Model", "model"),
        ("Status", "status"),
        ("Provider", "_provider"),
        ("IP", "ip"),
        ("CPU", "_cpu"),
        ("Mem", "_mem"),
    ]
    display.table(rows, cols, title=title, row_styles=["none", "dim"])


def _with_progress(message: str, action: Callable[[], _T]) -> _T:
    if display.is_json_mode():
        return action()
    with display.console.status(message):
        return action()


@app.command("list")
def list_containers(
    watch: bool = typer.Option(False, "--watch", "-w", help="Auto-refresh output"),
    interval: int = typer.Option(
        5, "--interval", "-i", min=1, help="Refresh interval in seconds"
    ),
):
    """List all managed containers."""
    if display.is_json_mode() or not watch:
        _render_containers(_container_rows())
        return

    try:
        while True:
            rows = _container_rows()
            display.console.clear()
            _render_containers(rows, title=f"Containers (refresh {interval}s)")
            time.sleep(interval)
    except KeyboardInterrupt:
        display.console.print("\n[dim]Watch stopped[/dim]")


@app.command()
def show(container_id: str = typer.Argument(..., help="Container ID")):
    """Show container detail."""
    data = client.get(f"/containers/{container_id}")
    resolved_id = data.get("id", container_id)

    display.detail(
        {
            "id": data.get("id"),
            "tenant": data.get("tenant"),
            "unit": data.get("unit"),
            "agent_name": data.get("agent_name"),
            "agent_role": data.get("agent_role"),
            "model": data.get("model"),
            "status": data.get("status"),
            "ip": data.get("ip"),
            "uptime": data.get("uptime"),
            "memory_limit": data.get("memory_limit"),
            "cpu_limit": data.get("cpu_limit"),
            "disk_limit": data.get("disk_limit"),
            "image": data.get("image"),
            "arch": data.get("arch"),
            "created_at": data.get("created_at"),
        },
        title=f"Container: {resolved_id}",
    )

    health = data.get("health")
    if health:
        cpu_pct = health.get("cpu", 0)
        mem_pct = health.get("mem", 0)
        disk_pct = health.get("disk", 0)
        mem_bytes = display.format_bytes(health.get("mem_bytes", 0))
        mem_total = display.format_bytes(health.get("mem_total", 0))

        display.detail(
            {
                "cpu": f"{cpu_pct:.1f}%",
                "mem": f"{mem_pct:.1f}% ({mem_bytes} / {mem_total})",
                "disk": f"{disk_pct:.1f}%",
                "agent_status": health.get("agent_status"),
                "agent_pid": health.get("agent_pid"),
                "recorded_at": health.get("recorded_at"),
            },
            title="Health",
        )

    snapshots = data.get("snapshots", [])
    if snapshots:
        display.table(
            snapshots, [("Name", "name"), ("Created", "created_at")], title="Snapshots"
        )


@app.command()
def start(container_id: str = typer.Argument(..., help="Container ID")):
    """Start a container."""
    data = _with_progress(
        f"Starting container {container_id}...",
        lambda: client.post(f"/containers/{container_id}/start"),
    )
    display.print_success(f"Container {container_id} {data.get('status', 'started')}")


@app.command()
def stop(
    container_id: str = typer.Argument(..., help="Container ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force stop"),
):
    """Stop a container."""
    verb = "Force stopping" if force else "Stopping"
    data = _with_progress(
        f"{verb} container {container_id}...",
        lambda: client.post(f"/containers/{container_id}/stop", json={"force": force}),
    )
    display.print_success(f"Container {container_id} {data.get('status', 'stopped')}")


@app.command()
def restart(container_id: str = typer.Argument(..., help="Container ID")):
    """Restart a container."""
    data = _with_progress(
        f"Restarting container {container_id}...",
        lambda: client.post(f"/containers/{container_id}/restart"),
    )
    display.print_success(f"Container {container_id} {data.get('status', 'restarted')}")


@app.command()
def delete(
    container_id: str = typer.Argument(..., help="Container ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a container."""
    if not yes:
        typer.confirm(
            f"Delete container {container_id}? This cannot be undone", abort=True
        )
    data = _with_progress(
        f"Deleting container {container_id}...",
        lambda: client.delete(f"/containers/{container_id}"),
    )
    display.print_success(f"Container {container_id} {data.get('status', 'deleted')}")


@app.command()
def update(
    container_id: str = typer.Argument(..., help="Container ID"),
    name: str | None = typer.Option(None, "--name", help="Agent name"),
    role: str | None = typer.Option(None, "--role", help="Agent role"),
    model: str | None = typer.Option(None, "--model", help="LLM model"),
    memory: str | None = typer.Option(
        None, "--memory", help="Memory limit, e.g. 4GB"
    ),
    cpu: str | None = typer.Option(None, "--cpu", help="CPU limit, e.g. 2"),
    disk: str | None = typer.Option(None, "--disk", help="Disk limit, e.g. 30GB"),
    tenant: str | None = typer.Option(None, "--tenant", help="Reassign to tenant"),
    unit: str | None = typer.Option(
        None, "--unit", help="Reassign to business unit"
    ),
    mcp_servers: str | None = typer.Option(
        None, "--mcp-servers", help="Comma-separated MCP server names"
    ),
    integrations: str | None = typer.Option(
        None, "--integrations", help="Comma-separated integration names"
    ),
):
    """Update container metadata."""
    body = {}
    if name is not None:
        body["agent_name"] = name
    if role is not None:
        body["agent_role"] = role
    if model is not None:
        body["model"] = model
    if memory is not None:
        body["memory_limit"] = memory
    if cpu is not None:
        body["cpu_limit"] = cpu
    if disk is not None:
        body["disk_limit"] = disk
    if tenant is not None:
        body["tenant"] = tenant
    if unit is not None:
        body["unit"] = unit
    if mcp_servers is not None:
        body["mcp_servers"] = [item.strip() for item in mcp_servers.split(",")]
    if integrations is not None:
        body["integrations"] = [item.strip() for item in integrations.split(",")]
    if not body:
        display.print_error("No fields specified")
        raise typer.Exit(1)
    _with_progress(
        f"Updating container {container_id}...",
        lambda: client.patch(f"/containers/{container_id}", json=body),
    )
    display.print_success(f"Container {container_id} updated")
