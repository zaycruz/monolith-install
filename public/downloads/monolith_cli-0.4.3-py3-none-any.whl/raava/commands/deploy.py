"""Fleet deploy command — provision N agents sequentially (or in limited parallel)."""

from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import typer

from raava import client

app = typer.Typer(no_args_is_help=True)


def _validate_one(name: str, body_base: dict) -> dict:
    """Call POST /provision/validate for a single replica name.

    Returns dict with name, valid (bool), and error (str or None).
    """
    payload = dict(body_base)
    payload["agent_name"] = name
    try:
        client.post("/provision/validate", json=payload)
        return {"name": name, "valid": True, "error": None}
    except Exception as exc:
        return {"name": name, "valid": False, "error": str(exc)}


def _provision_one(name: str, body_base: dict) -> dict:
    """Provision a single agent. Returns dict with name, success, ip, error."""
    body = dict(body_base)
    body["agent_name"] = name
    try:
        data = client.post("/provision", json=body)
        ip = data.get("ip") or data.get("container_ip") or ""
        return {"name": name, "success": True, "ip": ip, "data": data}
    except Exception as exc:
        return {"name": name, "success": False, "ip": "", "error": str(exc)}


@app.command()
def deploy(
    fleet: str = typer.Option(..., "--fleet", help="Fleet name"),
    replicas: int = typer.Option(..., "--replicas", min=1, help="Number of agents to provision"),
    template: str = typer.Option("hermes", "--template", "-t", help="Provisioning template"),
    tenant: str = typer.Option("default", "--tenant", help="Tenant ID"),
    role: str = typer.Option("Agent", "--role", help="Agent role"),
    parallel: bool = typer.Option(False, "--parallel", help="Allow limited parallelism (max 2 workers)"),
):
    """Deploy a fleet by provisioning N agents."""
    names = [f"agent-{fleet}-{i}" for i in range(1, replicas + 1)]

    body_base = {
        "template": template,
        "tenant_id": tenant,
        "agent_role": role,
        # agent_name is set per-replica
    }

    # --- Pre-validation ---
    validation_failures: list[dict] = []
    for name in names:
        result = _validate_one(name, body_base)
        if not result["valid"]:
            validation_failures.append(result)

    if validation_failures:
        for vf in validation_failures:
            typer.echo(f"  validation failed: {vf['name']}  {vf['error']}")
        typer.echo(f"pre-validation failed for {len(validation_failures)} name(s) — aborting")
        raise typer.Exit(1)

    # --- Provision ---
    typer.echo(f'provisioning {replicas} agent{"s" if replicas != 1 else ""} in fleet "{fleet}"')

    max_workers = 2 if parallel else 1
    wall_start = time.monotonic()
    results: list[dict] = []

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        # Submit one future at a time so we can stop on first failure
        pending_futures = {}
        aborted = False

        for name in names:
            if aborted:
                break
            future = pool.submit(_provision_one, name, body_base)
            pending_futures[future] = name

            # In sequential mode (max_workers=1) the future is already done
            # when we reach here; in parallel mode we need to drain completed
            # futures before the next submit only when we detect a failure.
            # We check completed futures after each submit to catch failures early.
            done_now = []
            for f in list(pending_futures):
                if f.done():
                    done_now.append(f)

            for f in done_now:
                del pending_futures[f]
                try:
                    r = f.result()
                except Exception as exc:
                    agent_name = names[len(results)]
                    r = {"name": agent_name, "success": False, "ip": "", "error": str(exc)}
                results.append(r)
                if not r["success"]:
                    aborted = True

        # Drain any still-running futures (parallel mode only)
        for future in as_completed(pending_futures):
            try:
                r = future.result()
            except Exception as exc:
                r = {"name": pending_futures[future], "success": False, "ip": "", "error": str(exc)}
            results.append(r)
            # Don't start more — aborted flag already set; pool won't accept new work

    elapsed = time.monotonic() - wall_start
    elapsed_str = f"{elapsed:.1f}s"

    succeeded = 0
    failed = 0
    for r in results:
        name = r.get("name", "unknown")
        if r.get("success"):
            ip = r.get("ip", "")
            if ip:
                typer.echo(f"  {name} ready  {ip}")
            else:
                typer.echo(f"  {name} ready")
            succeeded += 1
        else:
            err = r.get("error", "unknown error")
            typer.echo(f"  {name} failed  {err}")
            failed += 1

    not_attempted = replicas - len(results)
    if not_attempted > 0:
        typer.echo(f"  ({not_attempted} replica(s) not attempted after failure)")

    if failed == 0:
        typer.echo(f'\u2713 fleet "{fleet}" deployed ({succeeded} agent{"s" if succeeded != 1 else ""}, {elapsed_str})')
    else:
        typer.echo(
            f'\u2717 fleet "{fleet}" partially deployed ({succeeded}/{replicas} agents, {elapsed_str})'
        )
        raise typer.Exit(1)
