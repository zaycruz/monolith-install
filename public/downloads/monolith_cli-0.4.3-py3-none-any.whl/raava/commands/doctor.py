"""Doctor and diagnostic commands."""

import urllib.parse

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("run")
def run_doctor(container_id: str = typer.Argument(..., help="Container ID")):
    """Run stack-aware health and recovery checks for a container."""
    encoded_container_id = urllib.parse.quote(container_id, safe="")
    data = client.get(f"/containers/{encoded_container_id}/doctor")
    display.detail(data, title=f"Doctor Report: {container_id}")
