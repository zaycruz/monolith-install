"""File operations inside containers."""

import sys

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("ls")
def list_files(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Argument("/home/agent", help="Directory path"),
):
    """List directory contents."""
    data = client.get(f"/containers/{container_id}/files", params={"path": path})
    entries = data.get("entries", [])
    cols = [
        ("Type", "type"),
        ("Name", "name"),
        ("Size", "_size"),
        ("Modified", "modified"),
    ]
    for e in entries:
        size = e.get("size", 0)
        if e["type"] == "dir":
            e["_size"] = "—"
        elif size < 1024:
            e["_size"] = f"{size}B"
        elif size < 1048576:
            e["_size"] = f"{size // 1024}KB"
        else:
            e["_size"] = f"{size // 1048576}MB"
    display.table(entries, cols, title=f"{container_id}:{path}")


@app.command()
def read(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Argument(..., help="File path"),
):
    """Read file content."""
    data = client.get(f"/containers/{container_id}/files/{path.lstrip('/')}")
    if display.is_json_mode():
        display.print_json(data)
        return
    display.console.print(f"[dim]{data.get('path')} ({data.get('size', 0)} bytes)[/dim]")
    display.console.print(data.get("content", ""))


@app.command()
def write(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Argument(..., help="File path"),
    file: str | None = typer.Option(None, "--file", "-f", help="Local file to upload"),
):
    """Write file content. Reads from --file or stdin."""
    if file:
        with open(file) as f:
            content = f.read()
    elif not sys.stdin.isatty():
        content = sys.stdin.read()
    else:
        display.print_error("Provide content via --file or stdin pipe")
        raise typer.Exit(1)
    client.put(f"/containers/{container_id}/files/{path.lstrip('/')}", json={"content": content})
    display.print_success(f"Written to {container_id}:{path}")


@app.command()
def delete(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Argument(..., help="File path"),
):
    """Delete a file or directory."""
    client.delete(f"/containers/{container_id}/files/{path.lstrip('/')}")
    display.print_success(f"Deleted {container_id}:{path}")


@app.command()
def rename(
    container_id: str = typer.Argument(..., help="Container ID"),
    path: str = typer.Argument(..., help="Current path"),
    new_path: str = typer.Argument(..., help="New path"),
):
    """Rename or move a file."""
    client.post(f"/containers/{container_id}/files/{path.lstrip('/')}/rename", json={"new_path": new_path})
    display.print_success(f"Renamed {path} -> {new_path}")
