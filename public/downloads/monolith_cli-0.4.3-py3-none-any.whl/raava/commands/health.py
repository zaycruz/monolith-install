"""Container health commands."""

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command()
def show(container_id: str = typer.Argument(..., help="Container ID")):
    """Latest health snapshot."""
    try:
        data = client.get(f"/containers/{container_id}/health")
    except client.APIError as e:
        if e.status == 404:
            typer.echo("No health data available yet")
            return
        raise
    net_rx_rate = data.get("net_rx_rate", 0) or 0
    net_tx_rate = data.get("net_tx_rate", 0) or 0
    display.detail(
        {
            "cpu": f"{data.get('cpu', 0):.1f}%",
            "mem_rss": f"{display.format_bytes(data.get('mem_rss_bytes', 0))}",
            "mem_cache": f"{display.format_bytes(data.get('mem_cache_bytes', 0))}",
            "mem_total": display.format_bytes(data.get("mem_total", 0)),
            "disk": f"{data.get('disk', 0):.1f}%",
            "disk_usage": f"{display.format_bytes(data.get('disk_bytes', 0))} / {display.format_bytes(data.get('disk_total', 0))}",
            "disk_path": data.get("disk_path"),
            "disk_source": data.get("disk_source"),
            "net_rx": f"{display.format_bytes(data.get('net_rx_bytes', 0))} ({net_rx_rate:.0f} B/s)",
            "net_tx": f"{display.format_bytes(data.get('net_tx_bytes', 0))} ({net_tx_rate:.0f} B/s)",
            "disk_read": display.format_bytes(data.get("disk_read_bytes", 0)),
            "disk_write": display.format_bytes(data.get("disk_write_bytes", 0)),
            "agent_status": data.get("agent_status"),
            "agent_pid": data.get("agent_pid"),
            "backup_available": (data.get("backup") or {}).get("available"),
            "backup_run": (data.get("backup") or {}).get("last_backup_run_id"),
            "recorded_at": data.get("recorded_at"),
        },
        title=f"Health: {container_id}",
    )


@app.command()
def history(
    container_id: str = typer.Argument(..., help="Container ID"),
    hours: int = typer.Option(24, "--hours", "-H", help="Hours of history"),
):
    """Health history with stats."""
    data = client.get(
        f"/containers/{container_id}/health/history", params={"hours": hours}
    )
    stats = data.get("stats", {})
    if stats:
        display.detail(
            {
                "period": f"{data.get('hours')}h ({data.get('points')} points)",
                "cpu_avg": f"{stats.get('cpu_avg', 0)}%",
                "cpu_peak": f"{stats.get('cpu_peak', 0)}%",
                "mem_avg": f"{stats.get('mem_avg', 0)}%",
                "mem_peak": f"{stats.get('mem_peak', 0)}%",
                "disk_avg": f"{stats.get('disk_avg', 0)}%",
                "disk_peak": f"{stats.get('disk_peak', 0)}%",
            },
            title=f"Health Stats: {container_id}",
        )

    history = data.get("history", [])
    if history:
        cols = [
            ("Time", "recorded_at"),
            ("CPU%", "_cpu"),
            ("Mem%", "_mem"),
            ("Disk%", "_disk"),
            ("RX B/s", "_rx"),
            ("TX B/s", "_tx"),
            ("Agent", "agent_status"),
        ]
        for h in history:
            h["_cpu"] = f"{h.get('cpu', 0):.1f}"
            h["_mem"] = f"{h.get('mem', 0):.1f}"
            h["_disk"] = f"{h.get('disk', 0):.1f}"
            h["_rx"] = f"{(h.get('net_rx_rate', h.get('net_rx_bps', 0)) or 0):.0f}"
            h["_tx"] = f"{(h.get('net_tx_rate', h.get('net_tx_bps', 0)) or 0):.0f}"
        display.table(history, cols)
