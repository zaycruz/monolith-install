from __future__ import annotations

import typer

from raava import client, display
from raava.commands.migrations import (
    _raise_if_operation_unsuccessful,
    _render_operation,
    _wait_for_operation,
)

app = typer.Typer(no_args_is_help=True)


@app.command("version")
def version(
    container_id: str = typer.Argument(..., help="Container ID running Hermes"),
):
    resolved = client.resolve_container_id(container_id)
    data = client.get(f"/containers/{resolved}/hermes/version")
    display.detail(data, title=f"Hermes Version: {resolved}")


@app.command("update")
def update(
    container_id: str = typer.Argument(..., help="Container ID running Hermes"),
    check: bool = typer.Option(
        False,
        "--check",
        help="Check whether an update is available without applying it",
    ),
    config_check_after: bool = typer.Option(
        True,
        "--config-check-after/--skip-config-check-after",
        help="Run `hermes config check` after a real update",
    ),
    timeout_seconds: int = typer.Option(
        900,
        "--timeout-seconds",
        min=30,
        max=3600,
        help="Timeout for the Hermes update command inside the container",
    ),
    wait: bool = typer.Option(
        False,
        "--wait",
        help="Poll until the update operation finishes and print the final result",
    ),
    wait_timeout: int = typer.Option(
        900,
        "--wait-timeout",
        min=30,
        max=3600,
        help="How long the CLI should wait for the async operation to finish",
    ),
):
    resolved = client.resolve_container_id(container_id)
    payload = {
        "check_only": check,
        "timeout_seconds": timeout_seconds,
        "config_check_after": config_check_after,
    }
    accepted = client.post(f"/containers/{resolved}/hermes/update", json=payload)
    title = (
        f"Hermes Update Check Queued: {resolved}"
        if check
        else f"Hermes Update Queued: {resolved}"
    )
    _render_operation(accepted, title=title)

    if wait:
        try:
            operation = _wait_for_operation(
                accepted["operation_id"], timeout=float(wait_timeout)
            )
        except TimeoutError as exc:
            display.print_error(str(exc))
            raise typer.Exit(1) from exc

        result_title = (
            f"Hermes Update Check Result: {resolved}"
            if check
            else f"Hermes Update Result: {resolved}"
        )
        _render_operation(operation, title=result_title)
        _raise_if_operation_unsuccessful(operation)
