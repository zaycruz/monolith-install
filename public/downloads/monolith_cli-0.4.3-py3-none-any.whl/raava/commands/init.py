"""Interactive wizard for configuring Hermes on a provisioned container."""

from __future__ import annotations

import getpass
from typing import Optional

import typer

from raava import client, display
from raava.commands.wizard import validate_op_ref, DEFAULT_MODELS, KNOWN_PROVIDERS

app = typer.Typer(no_args_is_help=True)


def _prompt_provider() -> str:
    """Step 1: model provider selection."""
    display.console.print("\n[bold]Step 1 of 5 — Model Provider[/bold]")
    display.console.print("Available providers:")
    for i, p in enumerate(KNOWN_PROVIDERS, 1):
        display.console.print(f"  [cyan]{i}[/cyan]. {p}")

    while True:
        raw = typer.prompt(
            "Select provider (number or name)",
            default="openrouter",
        ).strip().lower()
        # Accept numeric selection
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(KNOWN_PROVIDERS):
                return KNOWN_PROVIDERS[idx]
            display.print_warning(f"Enter a number between 1 and {len(KNOWN_PROVIDERS)}")
            continue
        # Accept name directly (or prefix match)
        matches = [p for p in KNOWN_PROVIDERS if p.startswith(raw)]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            display.print_warning(f"Ambiguous: {', '.join(matches)}. Be more specific.")
            continue
        # Allow free-text values
        if raw:
            return raw
        display.print_warning("Provider cannot be empty.")


def _prompt_api_key(provider: str) -> str:
    """Step 2: API key (masked input)."""
    display.console.print(f"\n[bold]Step 2 of 5 — API Key ({provider})[/bold]")
    display.console.print("[dim]Input is hidden — key will not be shown.[/dim]")
    while True:
        # Use getpass for masked input; falls back gracefully in non-TTY.
        try:
            key = getpass.getpass(prompt=f"  {provider.capitalize()} API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            display.print_error("Aborted.")
            raise typer.Exit(1)
        if key:
            return key
        display.print_warning("API key cannot be empty.")


def _prompt_model(provider: str) -> str:
    """Step 3: model selection."""
    display.console.print(f"\n[bold]Step 3 of 5 — Model ({provider})[/bold]")
    default_model = DEFAULT_MODELS.get(provider, "")
    if default_model:
        display.console.print(f"[dim]Suggested default: {default_model}[/dim]")
    else:
        display.console.print("[dim]No preset model for this provider.[/dim]")

    while True:
        raw = typer.prompt(
            "Model ID",
            default=default_model if default_model else ...,
        ).strip()
        if raw:
            return raw
        display.print_warning("Model ID cannot be empty.")


def _prompt_op_reference() -> Optional[str]:
    """Step 4: optional 1Password vault reference."""
    display.console.print("\n[bold]Step 4 of 5 — 1Password Vault Reference (optional)[/bold]")
    display.console.print(
        "[dim]If this API key is stored in 1Password, enter the op:// reference.\n"
        "The reference will be stored in the config instead of the raw key.[/dim]"
    )
    use_op = typer.confirm("  Use a 1Password op:// reference?", default=False)
    if not use_op:
        return None

    while True:
        ref = typer.prompt("  1Password reference (e.g. op://vault/item/field)").strip()
        ok, err = validate_op_ref(ref)
        if not ok:
            display.print_error(
                "[red]❌[/red] Invalid 1Password reference format. "
                "Expected: op://vault-name/item-name/field-name"
            )
            continue
        return ref


def _build_hermes_config_payload(provider: str, api_key: str, model: str, op_ref: str | None) -> dict:
    payload: dict = {
        "model_provider": provider,
        "model": model,
        "api_key": op_ref if op_ref else api_key,
        "timezone": "America/New_York",
        "restart_after": True,
    }
    return payload


def _show_summary(container_id: str, provider: str, model: str, op_ref: Optional[str]) -> None:
    """Print a confirmation summary before applying."""
    display.console.print("\n[bold]Step 5 of 5 — Confirm & Apply[/bold]")
    display.console.print("\n[bold underline]Summary[/bold underline]")
    display.console.print(f"  Container : [cyan]{container_id}[/cyan]")
    display.console.print(f"  Provider  : [cyan]{provider}[/cyan]")
    display.console.print(f"  Model     : [cyan]{model}[/cyan]")
    if op_ref:
        display.console.print(f"  API Key   : [cyan]{op_ref}[/cyan] (1Password)")
    else:
        display.console.print("  API Key   : [cyan]<provided>[/cyan]")
    display.console.print()


@app.command()
def init(
    container_id: str = typer.Argument(..., help="Container ID to configure Hermes on"),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Run the wizard and print the payload without sending",
    ),
):
    """Interactive wizard to configure Hermes on a provisioned container.

    Walks through provider selection, API key entry, model selection, and an
    optional 1Password vault reference, then applies the config via the hardened
    hermes/config endpoint which handles writing and restarting the service.
    """
    display.console.print(
        f"\n[bold green]Monolith Agent Init Wizard[/bold green] — container: [cyan]{container_id}[/cyan]"
    )
    display.console.print(
        "[dim]This wizard configures Hermes on an already-provisioned container.\n"
        "Press Ctrl+C at any time to abort.[/dim]"
    )

    # Resolve the container ID early so we fail fast on typos.
    resolved = client.resolve_container_id(container_id)
    if resolved != container_id:
        display.console.print(f"[dim]Resolved container: {resolved}[/dim]")

    # --- Wizard steps ---
    provider = _prompt_provider()
    api_key = _prompt_api_key(provider)
    model = _prompt_model(provider)
    op_ref = _prompt_op_reference()

    # --- Summary & confirm ---
    _show_summary(resolved, provider, model, op_ref)

    if not typer.confirm("Apply this configuration?", default=True):
        display.print_warning("Aborted — no changes made.")
        raise typer.Exit(0)

    payload = _build_hermes_config_payload(provider, api_key, model, op_ref)

    if dry_run:
        import json
        safe = {**payload, "api_key": "<redacted>"}
        display.console.print("\n[bold yellow]Dry run — payload (not sent):[/bold yellow]")
        display.console.print(json.dumps(safe, indent=2))
        return

    display.console.print(f"\n[dim]Applying config to {resolved}...[/dim]")
    try:
        resp = client.post(f"/containers/{resolved}/hermes/config", json=payload)
        config_path = resp.get("config_path", "/home/agent/.hermes/config.yaml")
        restart_status = resp.get("restart_status", "unknown")
        display.console.print(f"  [dim]Config written to {config_path} — restart: {restart_status}[/dim]")
    except Exception as exc:
        display.print_error(f"Failed to apply config: {exc}")
        raise typer.Exit(1) from exc

    display.console.print(
        f"\n[bold green]Done![/bold green] Hermes is configured on [cyan]{resolved}[/cyan]."
    )
