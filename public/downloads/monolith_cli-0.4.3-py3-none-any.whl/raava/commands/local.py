"""Local runtime commands for developer-local deployments."""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

import typer

from raava import display

app = typer.Typer(no_args_is_help=True)

DEFAULT_RUNTIME = "docker"
DEFAULT_DOCKER_IMAGE = "python:3.12-slim"
DEFAULT_DOCKER_COMMAND = "python -m http.server 8080 --bind 0.0.0.0"
DEFAULT_LXD_IMAGE = "images:ubuntu/22.04"
LOCAL_LABEL = "com.thisismonolith.local"
LOCAL_CONFIG_DIR = Path.home() / ".config" / "monolith"
LOCAL_CONFIG_FILE = LOCAL_CONFIG_DIR / "local.toml"


class LocalRuntimeError(RuntimeError):
    """Raised when a local runtime command cannot continue."""


def _run(argv: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        argv,
        check=False,
        capture_output=True,
        text=True,
    )


def _command_detail(proc: subprocess.CompletedProcess[str]) -> str:
    return (proc.stderr or proc.stdout or "").strip()


def _validate_runtime(runtime: str) -> str:
    value = runtime.lower().strip()
    if value not in {"docker", "lxd"}:
        raise LocalRuntimeError("runtime must be either 'docker' or 'lxd'")
    return value


def _load_local_config() -> dict[str, Any]:
    if not LOCAL_CONFIG_FILE.exists():
        return {}
    try:
        import tomllib

        with open(LOCAL_CONFIG_FILE, "rb") as f:
            data = tomllib.load(f)
    except Exception:
        return {}
    if isinstance(data, dict):
        return data
    return {}


def _save_local_config(data: dict[str, Any]) -> None:
    LOCAL_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        LOCAL_CONFIG_DIR.chmod(0o700)
    except OSError:
        pass

    lines = []
    for key, value in data.items():
        escaped = str(value).replace("\\", "\\\\").replace('"', '\\"')
        lines.append(f'{key} = "{escaped}"')
    LOCAL_CONFIG_FILE.write_text("\n".join(lines) + "\n")
    try:
        LOCAL_CONFIG_FILE.chmod(0o600)
    except OSError:
        pass


def _runtime_check(runtime: str) -> dict[str, str]:
    runtime = _validate_runtime(runtime)
    if runtime == "docker":
        docker = shutil.which("docker")
        if not docker:
            return {
                "check": "docker",
                "status": "missing",
                "detail": "Install Docker Desktop or Docker Engine, then rerun.",
            }
        proc = _run(["docker", "info", "--format", "{{json .ServerVersion}}"])
        if proc.returncode != 0:
            return {
                "check": "docker daemon",
                "status": "not-ready",
                "detail": _command_detail(proc) or "Docker daemon is not reachable.",
            }
        return {
            "check": "docker daemon",
            "status": "ok",
            "detail": f"docker={docker}",
        }

    lxc = shutil.which("lxc")
    if not lxc:
        return {
            "check": "lxc",
            "status": "missing",
            "detail": "Install and initialize LXD, then rerun.",
        }
    proc = _run(["lxc", "info"])
    if proc.returncode != 0:
        return {
            "check": "lxd daemon",
            "status": "not-ready",
            "detail": _command_detail(proc) or "LXD daemon is not reachable.",
        }
    return {
        "check": "lxd daemon",
        "status": "ok",
        "detail": f"lxc={lxc}",
    }


def _ensure_runtime_ready(runtime: str) -> None:
    check = _runtime_check(runtime)
    if check["status"] != "ok":
        raise LocalRuntimeError(f"{check['check']} {check['status']}: {check['detail']}")


def _container_exists(runtime: str, name: str) -> bool:
    if runtime == "docker":
        return _run(["docker", "inspect", name]).returncode == 0
    return _run(["lxc", "info", name]).returncode == 0


def _deploy_docker(
    name: str,
    image: str,
    command: str,
    host_port: int,
    container_port: int,
    replace: bool,
) -> dict[str, str]:
    _ensure_runtime_ready("docker")
    if _container_exists("docker", name):
        if not replace:
            raise LocalRuntimeError(
                f"Docker container '{name}' already exists; rerun with --replace."
            )
        rm = _run(["docker", "rm", "-f", name])
        if rm.returncode != 0:
            raise LocalRuntimeError(_command_detail(rm) or f"Could not replace {name}.")

    argv = [
        "docker",
        "run",
        "-d",
        "--name",
        name,
        "--label",
        f"{LOCAL_LABEL}=true",
        "--label",
        "com.thisismonolith.runtime=docker",
        "-p",
        f"127.0.0.1:{host_port}:{container_port}",
        image,
        "/bin/sh",
        "-lc",
        command,
    ]
    proc = _run(argv)
    if proc.returncode != 0:
        raise LocalRuntimeError(_command_detail(proc) or "Docker deploy failed.")
    return {
        "name": name,
        "runtime": "docker",
        "status": "running",
        "image": image,
        "ports": f"127.0.0.1:{host_port}:{container_port}",
        "id": proc.stdout.strip(),
    }


def _deploy_lxd(name: str, image: str, replace: bool) -> dict[str, str]:
    _ensure_runtime_ready("lxd")
    if _container_exists("lxd", name):
        if not replace:
            raise LocalRuntimeError(
                f"LXD container '{name}' already exists; rerun with --replace."
            )
        stop = _run(["lxc", "stop", name, "--force"])
        if stop.returncode not in {0, 1}:
            raise LocalRuntimeError(_command_detail(stop) or f"Could not stop {name}.")
        delete = _run(["lxc", "delete", name])
        if delete.returncode != 0:
            raise LocalRuntimeError(_command_detail(delete) or f"Could not delete {name}.")

    proc = _run(
        [
            "lxc",
            "launch",
            image,
            name,
            "-c",
            "user.monolith.local=true",
        ]
    )
    if proc.returncode != 0:
        raise LocalRuntimeError(_command_detail(proc) or "LXD deploy failed.")
    return {
        "name": name,
        "runtime": "lxd",
        "status": "running",
        "image": image,
        "ports": "",
        "id": name,
    }


def _docker_rows() -> list[dict[str, str]]:
    _ensure_runtime_ready("docker")
    proc = _run(
        [
            "docker",
            "ps",
            "-a",
            "--filter",
            f"label={LOCAL_LABEL}=true",
            "--format",
            "{{json .}}",
        ]
    )
    if proc.returncode != 0:
        raise LocalRuntimeError(_command_detail(proc) or "Could not list Docker containers.")
    rows = []
    for line in proc.stdout.splitlines():
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except json.JSONDecodeError as exc:
            raise LocalRuntimeError(
                f"Could not parse Docker container list output: {exc}"
            ) from exc
        rows.append(
            {
                "name": item.get("Names", ""),
                "runtime": "docker",
                "status": item.get("State", ""),
                "image": item.get("Image", ""),
                "ports": item.get("Ports", ""),
            }
        )
    return rows


def _lxd_rows() -> list[dict[str, str]]:
    _ensure_runtime_ready("lxd")
    proc = _run(["lxc", "list", "--format", "json"])
    if proc.returncode != 0:
        raise LocalRuntimeError(_command_detail(proc) or "Could not list LXD containers.")
    try:
        items = json.loads(proc.stdout or "[]")
    except json.JSONDecodeError as exc:
        raise LocalRuntimeError(f"Could not parse LXD container list output: {exc}") from exc
    rows = []
    for item in items:
        config = item.get("config") or {}
        name = item.get("name", "")
        if config.get("user.monolith.local") != "true" and not name.startswith("monolith-"):
            continue
        rows.append(
            {
                "name": name,
                "runtime": "lxd",
                "status": item.get("status", ""),
                "image": item.get("image") or item.get("fingerprint") or "",
                "ports": "",
            }
        )
    return rows


def _print_rows(rows: list[dict[str, str]], title: str = "Local deployments") -> None:
    display.table(
        rows,
        [
            ("NAME", "name"),
            ("RUNTIME", "runtime"),
            ("STATUS", "status"),
            ("IMAGE", "image"),
            ("PORTS", "ports"),
        ],
        title=title,
    )


def _handle_runtime_error(exc: LocalRuntimeError) -> None:
    display.print_error(str(exc))
    raise typer.Exit(1)


@app.command("doctor")
def doctor(
    runtime: str = typer.Option(
        DEFAULT_RUNTIME,
        "--runtime",
        "-r",
        help="Local runtime to check: docker or lxd",
    ),
) -> None:
    """Check whether the local runtime can launch Monolith containers."""
    try:
        check = _runtime_check(runtime)
    except LocalRuntimeError as exc:
        _handle_runtime_error(exc)
    display.table([check], [("CHECK", "check"), ("STATUS", "status"), ("DETAIL", "detail")], title="Local Runtime")
    if check["status"] != "ok":
        raise typer.Exit(1)


@app.command("init")
def init(
    runtime: str = typer.Option(
        DEFAULT_RUNTIME,
        "--runtime",
        "-r",
        help="Local runtime to configure: docker or lxd",
    ),
    image: str | None = typer.Option(
        None,
        "--image",
        help="Default image for local deploys",
    ),
) -> None:
    """Persist the default local runtime settings."""
    try:
        runtime = _validate_runtime(runtime)
        _ensure_runtime_ready(runtime)
    except LocalRuntimeError as exc:
        _handle_runtime_error(exc)

    selected_image = image or (
        DEFAULT_DOCKER_IMAGE if runtime == "docker" else DEFAULT_LXD_IMAGE
    )
    _save_local_config({"runtime": runtime, "image": selected_image})
    display.print_success(f"Local runtime configured: {runtime} ({selected_image})")
    typer.echo("Next: monolith local deploy --name monolith-local-1")


@app.command("deploy")
def deploy(
    name: str = typer.Option(
        "monolith-local-1",
        "--name",
        "-n",
        help="Local container name",
    ),
    runtime: str | None = typer.Option(
        None,
        "--runtime",
        "-r",
        help="Local runtime: docker or lxd. Defaults to local config, then docker.",
    ),
    image: str | None = typer.Option(
        None,
        "--image",
        help="Container image. Defaults to local config, then a runtime default.",
    ),
    command: str = typer.Option(
        DEFAULT_DOCKER_COMMAND,
        "--command",
        help="Docker command to run inside the local container",
    ),
    host_port: int = typer.Option(
        8080,
        "--host-port",
        min=1,
        max=65535,
        help="Host port for Docker local demo traffic",
    ),
    container_port: int = typer.Option(
        8080,
        "--container-port",
        min=1,
        max=65535,
        help="Container port for Docker local demo traffic",
    ),
    replace: bool = typer.Option(
        False,
        "--replace",
        help="Replace an existing local container with the same name",
    ),
) -> None:
    """Launch the first local Docker or LXD container."""
    config = _load_local_config()
    try:
        config_runtime = str(config.get("runtime") or DEFAULT_RUNTIME)
        selected_runtime = _validate_runtime(runtime or config_runtime)
        try:
            normalized_config_runtime = _validate_runtime(config_runtime)
        except LocalRuntimeError:
            normalized_config_runtime = None
        default_image = (
            DEFAULT_DOCKER_IMAGE if selected_runtime == "docker" else DEFAULT_LXD_IMAGE
        )
        config_image = str(config.get("image") or "")
        selected_image = image or (
            config_image if normalized_config_runtime == selected_runtime else ""
        ) or default_image

        if selected_runtime == "docker":
            row = _deploy_docker(
                name=name,
                image=selected_image,
                command=command,
                host_port=host_port,
                container_port=container_port,
                replace=replace,
            )
        else:
            row = _deploy_lxd(name=name, image=selected_image, replace=replace)
    except LocalRuntimeError as exc:
        _handle_runtime_error(exc)
    _print_rows([row], title="Local deploy")
    if selected_runtime == "docker":
        typer.echo(f"Open: http://127.0.0.1:{host_port}")


@app.command("list")
def list_deployments(
    runtime: str = typer.Option(
        DEFAULT_RUNTIME,
        "--runtime",
        "-r",
        help="Local runtime to list: docker or lxd",
    ),
) -> None:
    """List containers created by Monolith local deploy."""
    try:
        runtime = _validate_runtime(runtime)
        rows = _docker_rows() if runtime == "docker" else _lxd_rows()
    except LocalRuntimeError as exc:
        _handle_runtime_error(exc)
    _print_rows(rows)


@app.command("stop")
def stop(
    name: str = typer.Argument(..., help="Local container name"),
    runtime: str = typer.Option(
        DEFAULT_RUNTIME,
        "--runtime",
        "-r",
        help="Local runtime: docker or lxd",
    ),
    remove: bool = typer.Option(
        False,
        "--remove",
        help="Remove the local container after stopping it",
    ),
) -> None:
    """Stop a local Docker or LXD deployment."""
    try:
        runtime = _validate_runtime(runtime)
        _ensure_runtime_ready(runtime)
        if runtime == "docker":
            proc = _run(["docker", "stop", name])
            if proc.returncode != 0:
                raise LocalRuntimeError(_command_detail(proc) or f"Could not stop {name}.")
            if remove:
                rm = _run(["docker", "rm", name])
                if rm.returncode != 0:
                    raise LocalRuntimeError(_command_detail(rm) or f"Could not remove {name}.")
        else:
            proc = _run(["lxc", "stop", name, "--force"])
            if proc.returncode != 0:
                raise LocalRuntimeError(_command_detail(proc) or f"Could not stop {name}.")
            if remove:
                delete = _run(["lxc", "delete", name])
                if delete.returncode != 0:
                    raise LocalRuntimeError(
                        _command_detail(delete) or f"Could not delete {name}."
                    )
    except LocalRuntimeError as exc:
        _handle_runtime_error(exc)
    display.print_success(f"Stopped local {runtime} deployment: {name}")
