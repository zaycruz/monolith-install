"""Messaging platform configuration (Discord, etc)."""


import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("discord")
def discord_config(
    container_id: str = typer.Argument(..., help="Container ID"),
    users: str | None = typer.Option(
        None, "--users", help="Comma-separated list of allowed user IDs"
    ),
    home: str | None = typer.Option(None, "--home", help="Home channel ID"),
    home_name: str | None = typer.Option(
        None, "--home-name", help="Home channel name"
    ),
    free: str | None = typer.Option(
        None, "--free", help="Comma-separated free response channels"
    ),
    mention: bool | None = typer.Option(
        None, "--require-mention/--no-mention", help="Require @mention to respond"
    ),
    apply: bool = typer.Option(
        True, "--apply/--stage-only", help="Apply immediately and restart"
    ),
):
    """View or patch Hermes Discord configuration."""
    if not any(v is not None for v in (users, home, home_name, free, mention)):
        # Just view
        data = client.get(f"/containers/{container_id}/messaging/discord")
        display.detail(data, title=f"Discord Config: {container_id}")
        return

    # Patch
    payload = {"apply": apply, "restart": apply}
    if users is not None:
        payload["authorized_user_ids"] = [
            u.strip() for u in users.split(",") if u.strip()
        ]
    if home is not None:
        payload["home_channel_id"] = home
    if home_name is not None:
        payload["home_channel_name"] = home_name
    if free is not None:
        payload["free_response_channel_ids"] = [
            c.strip() for c in free.split(",") if c.strip()
        ]
    if mention is not None:
        payload["require_mention"] = mention

    data = client.patch(f"/containers/{container_id}/messaging/discord", json=payload)
    display.detail(data, title=f"Discord Config Updated: {container_id}")
