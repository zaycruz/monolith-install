"""Token usage and utilization metrics."""


import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


def _resolved_container(container_id: str | None) -> str | None:
    if not container_id:
        return None
    return client.resolve_container_id(container_id)


def _format_cost(value) -> str:
    try:
        amount = float(value or 0)
    except (TypeError, ValueError):
        return "N/A"
    return f"${amount:.4f}"


@app.command()
def tokens(
    container_id: str | None = typer.Option(None, "--container", "-c"),
    hours: int = typer.Option(24, "--hours", "-H"),
):
    """Token usage summary."""
    params = {"hours": hours}
    resolved = _resolved_container(container_id)
    if resolved:
        params["container_id"] = resolved
    data = client.get("/metrics/tokens", params=params)
    detail = dict(data)
    if resolved:
        detail["container_id"] = resolved
    display.detail(detail, title="Token Usage")


@app.command("tokens-timeseries")
def tokens_timeseries(
    container_id: str | None = typer.Option(None, "--container", "-c"),
    hours: int = typer.Option(24, "--hours", "-H"),
    bucket: int = typer.Option(60, "--bucket", help="Bucket size in minutes"),
):
    """Token usage over time (bucketed)."""
    params = {"hours": hours, "bucket_minutes": bucket}
    resolved = _resolved_container(container_id)
    if resolved:
        params["container_id"] = resolved
    data = client.get("/metrics/tokens/timeseries", params=params)
    if display.is_json_mode():
        display.print_json(data)
        return
    buckets = (
        data if isinstance(data, list) else data.get("buckets", data.get("data", []))
    )
    if isinstance(buckets, list):
        display_rows = [
            dict(row, _cost=_format_cost(row.get("cost_total"))) for row in buckets
        ]
        cols = [
            ("Time", "bucket"),
            ("Input", "input_tokens"),
            ("Output", "output_tokens"),
            ("Cost", "_cost"),
        ]
        display.table(display_rows, cols, title="Token Timeseries")
    else:
        display.print_json(data)


@app.command("by-container")
def tokens_by_container(hours: int = typer.Option(24, "--hours", "-H")):
    """Token usage breakdown by container."""
    data = client.get("/metrics/tokens/by-container", params={"hours": hours})
    if isinstance(data, list):
        display_rows = [
            dict(row, _cost=_format_cost(row.get("cost_total"))) for row in data
        ]
        cols = [
            ("Container", "container_id"),
            ("Agent", "agent_name"),
            ("Input", "input_tokens"),
            ("Output", "output_tokens"),
            ("Cost", "_cost"),
        ]
        display.table(display_rows, cols, title="Tokens by Container")
    else:
        display.print_json(data)


@app.command("by-unit")
def tokens_by_unit(hours: int = typer.Option(24, "--hours", "-H")):
    """Token usage breakdown by business unit."""
    data = client.get("/metrics/tokens/by-unit", params={"hours": hours})
    if isinstance(data, list):
        display_rows = [
            dict(row, _cost=_format_cost(row.get("cost_total"))) for row in data
        ]
        cols = [
            ("Unit", "unit_id"),
            ("Unit Name", "unit_name"),
            ("Input", "input_tokens"),
            ("Output", "output_tokens"),
            ("Cost", "_cost"),
        ]
        display.table(display_rows, cols, title="Tokens by Unit")
    else:
        display.print_json(data)


@app.command()
def heatmap(
    container_id: str = typer.Option(..., "--container", "-c", help="Container ID"),
    hours: int = typer.Option(24, "--hours", "-H"),
):
    """Utilization heatmap (hourly CPU/mem)."""
    resolved = client.resolve_container_id(container_id)
    data = client.get(
        "/metrics/utilization/heatmap",
        params={"container_id": resolved, "hours": hours},
    )
    if display.is_json_mode():
        display.print_json(data)
        return
    entries = data if isinstance(data, list) else data.get("data", [])
    if isinstance(entries, list):
        cols = [
            ("Hour", "hour"),
            ("CPU Avg", "cpu_avg"),
            ("CPU Peak", "cpu_peak"),
            ("Mem Avg", "mem_avg"),
            ("Mem Peak", "mem_peak"),
        ]
        display.table(entries, cols, title=f"Heatmap: {resolved}")
    else:
        display.print_json(data)


@app.command()
def restarts(
    container_id: str | None = typer.Option(None, "--container", "-c"),
    hours: int = typer.Option(24, "--hours", "-H"),
):
    """Process restart count."""
    params = {"hours": hours}
    resolved = _resolved_container(container_id)
    if resolved:
        params["container_id"] = resolved
    data = client.get("/metrics/restarts", params=params)
    display.detail(data, title="Restart Count")


@app.command("fleet-utilization")
def fleet_utilization():
    """Average CPU/mem utilization across running containers."""
    data = client.get("/metrics/fleet-utilization")
    display.detail(data, title="Fleet Utilization")
