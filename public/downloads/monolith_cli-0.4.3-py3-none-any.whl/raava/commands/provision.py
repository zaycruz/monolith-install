"""Template-based agent provisioning."""

import time

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command()
def templates():
    """List available provisioning templates."""
    data = client.get("/templates")
    if isinstance(data, list):
        display.table(
            data, [("Name", "name"), ("Description", "description")], title="Templates"
        )
    else:
        display.print_json(data)


@app.command()
def template(name: str = typer.Argument(..., help="Template name")):
    """Show template detail."""
    data = client.get(f"/templates/{name}")
    display.detail(data, title=f"Template: {name}")


@app.command()
def start(
    template_name: str = typer.Option(
        ...,
        "--template",
        "-t",
        help="Template: hermes, openclaw, smoke, or hermes-direct",
    ),
    tenant_id: str = typer.Option(..., "--tenant", help="Tenant ID"),
    agent_name: str = typer.Option(..., "--name", help="Agent display name"),
    agent_role: str = typer.Option(..., "--role", help="Agent role"),
    unit_id: str | None = typer.Option(None, "--unit"),
    model: str | None = typer.Option(None, "--model"),
    memory: str | None = typer.Option(None, "--memory"),
    cpu: str | None = typer.Option(None, "--cpu"),
    disk: str | None = typer.Option(None, "--disk"),
    provider: str | None = typer.Option(
        None, "--provider", help="Compute provider, e.g. lxd or gce"
    ),
    zone: str | None = typer.Option(
        None, "--zone", help="GCP zone override, e.g. us-east1-b"
    ),
    system_prompt: str | None = typer.Option(
        None, "--system-prompt", help="Custom SOUL.md content or @filepath"
    ),
    timezone_val: str | None = typer.Option(
        None, "--timezone", help="Container timezone, e.g. America/New_York"
    ),
    model_provider: str | None = typer.Option(
        None, "--model-provider", help="Model provider override"
    ),
    openrouter_api_key: str | None = typer.Option(
        None,
        "--openrouter-api-key",
        envvar="OPENROUTER_API_KEY",
        help="Optional direct OpenRouter API key for templates that do not use 1Password",
    ),
    personality: str | None = typer.Option(
        None, "--personality", help="Agent personality description"
    ),
    discord_channel: str | None = typer.Option(
        None, "--discord-channel", help="Discord channel link"
    ),
    gateway_port: str | None = typer.Option(
        None, "--gateway-port", help="Custom gateway port"
    ),
    test: bool = typer.Option(False, "--test", help="Test mode, skip GitHub repo"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for completion"),
):
    """Start provisioning a new agent."""
    body = {
        "template": template_name,
        "tenant_id": tenant_id,
        "agent_name": agent_name,
        "agent_role": agent_role,
    }
    if unit_id is not None:
        body["unit_id"] = unit_id
    if model is not None:
        body["model"] = model
    if memory is not None:
        body["memory"] = memory
    if cpu is not None:
        body["cpu"] = cpu
    if disk is not None:
        body["disk"] = disk
    if provider is not None:
        body["provider"] = provider
    if zone is not None:
        body["zone"] = zone
    if system_prompt is not None:
        # Support @filepath to read from file
        if system_prompt.startswith("@"):
            with open(system_prompt[1:]) as f:
                body["system_prompt"] = f.read()
        else:
            body["system_prompt"] = system_prompt
    if timezone_val is not None:
        body["timezone"] = timezone_val
    if model_provider is not None:
        body["model_provider"] = model_provider
    if openrouter_api_key is not None:
        body["openrouter_api_key"] = openrouter_api_key
    if personality is not None:
        body["personality"] = personality
    if discord_channel is not None:
        body["discord_channel"] = discord_channel
    if gateway_port is not None:
        body["gateway_port"] = gateway_port
    if test:
        body["test"] = True

    data = client.post("/provision", json=body)
    job_id = data.get("job_id")
    display.print_success(f"Provisioning started: {job_id}")

    if wait and job_id:
        with display.console.status("Provisioning..."):
            while True:
                job = client.get(f"/provision/{job_id}")
                s = job.get("status", "")
                if s in ("complete", "failed", "cancelled", "interrupted"):
                    break
                time.sleep(3)
        if job.get("status") == "complete":
            display.print_success(
                f"Provisioning complete: {job.get('container_name', '')}"
            )
        else:
            display.print_error(
                f"Provisioning {job.get('status')}: {job.get('error', '')}"
            )


@app.command("status")
def job_status(job_id: str = typer.Argument(..., help="Job ID")):
    """Get provisioning job status."""
    data = client.get(f"/provision/{job_id}")
    display.detail(
        {
            "id": data.get("id"),
            "status": data.get("status"),
            "template": data.get("template"),
            "agent_name": data.get("agent_name"),
            "container_name": data.get("container_name", "—"),
            "error": data.get("error", "—"),
            "started_at": data.get("started_at"),
            "completed_at": data.get("completed_at", "—"),
        },
        title="Provision Job",
    )

    steps = data.get("steps", [])
    if steps:
        cols = [("Step", "name"), ("Status", "status"), ("Duration", "duration")]
        display.table(steps, cols, title="Steps")


@app.command()
def jobs(limit: int = typer.Option(50, "--limit", "-n")):
    """List provisioning jobs."""
    data = client.get("/provision", params={"limit": limit})
    cols = [
        ("ID", "id"),
        ("Status", "status"),
        ("Template", "template"),
        ("Agent", "agent_name"),
        ("Container", "container_name"),
        ("Started", "started_at"),
    ]
    display.table(data, cols, title="Provision Jobs")


@app.command()
def cancel(job_id: str = typer.Argument(..., help="Job ID")):
    """Cancel a running provision job."""
    data = client.post(f"/provision/{job_id}/cancel")
    display.print_success(data.get("message", "Cancelled"))


@app.command()
def retry(job_id: str = typer.Argument(..., help="Job ID")):
    """Retry a failed provision job."""
    data = client.post(f"/provision/{job_id}/retry")
    display.print_success(f"Retrying as {data.get('job_id')}. Original: {job_id}")


@app.command("validate")
def validate_provision(
    template: str = typer.Option(
        ..., "--template", "-t", help="Template name (e.g. hermes)"
    ),
    tenant: str = typer.Option(..., "--tenant", help="Tenant ID"),
    name: str = typer.Option(..., "--name", "-n", help="Agent name"),
    unit: str | None = typer.Option(None, "--unit", help="Business Unit ID"),
    role: str = typer.Option("Agent", "--role", "-r", help="Agent role"),
    model: str = typer.Option(
        "minimax/minimax-m2.5", "--model", "-m", help="LLM model ID"
    ),
    provider: str = typer.Option("lxd", "--provider", "-p", help="Provider (e.g. lxd)"),
    discord_channel: str | None = typer.Option(
        None, "--discord-channel", help="Discord channel integration (Hermes)"
    ),
):
    """Validate a provision request before creating a VM."""
    payload = {
        "template": template,
        "tenant_id": tenant,
        "agent_name": name,
        "agent_role": role,
        "model": model,
        "provider": provider,
    }
    if unit is not None:
        payload["unit_id"] = unit
    if discord_channel:
        payload["integrations"] = {"discord": {"channel_id": discord_channel}}

    data = client.post("/provision/validate", json=payload)
    display.detail(data, title=f"Provision Validation: {name}")
