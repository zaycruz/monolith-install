"""Reconcile and drift repair commands."""

import urllib.parse

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("run")
def run_reconcile(container_id: str = typer.Argument(..., help="Container ID")):
    """Repair drift between DB, provider, and runtime state."""
    encoded_container_id = urllib.parse.quote(container_id, safe="")
    data = client.post(f"/containers/{encoded_container_id}/reconcile")
    display.detail(data, title=f"Reconcile: {container_id}")
