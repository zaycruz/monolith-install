"""Stack-aware service operations."""
import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)

@app.command("restart")
def restart_service(
    container_id: str = typer.Argument(..., help="Container ID"),
    service: str = typer.Argument(..., help="Service name (e.g. gateway, agent)"),
):
    """Restart a specific service in the container."""
    data = client.post(f"/containers/{container_id}/services/{service}/restart")
    display.detail(data, title=f"Restarted {service} in {container_id}")

@app.command("reload")
def reload_service(
    container_id: str = typer.Argument(..., help="Container ID"),
    service: str = typer.Argument(..., help="Service name (e.g. gateway, agent)"),
):
    """Reload a specific service in the container."""
    data = client.post(f"/containers/{container_id}/services/{service}/reload")
    display.detail(data, title=f"Reloaded {service} in {container_id}")

@app.command("logs")
def service_logs(
    container_id: str = typer.Argument(..., help="Container ID"),
    service: str = typer.Argument(..., help="Service name (e.g. gateway, agent)"),
    tail: int = typer.Option(100, "--tail", "-n", help="Lines to tail"),
):
    """View logs for a specific service."""
    data = client.get(f"/containers/{container_id}/services/{service}/logs", params={"tail": tail})
    lines = data.get("lines", [])
    if not lines:
        display.print_dim("No logs found.")
    else:
        for line in lines:
            print(line)
