"""LXD snapshot management."""


import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_snapshots(container_id: str = typer.Argument(..., help="Container ID")):
    """List snapshots for a container."""
    data = client.get(f"/containers/{container_id}/snapshots")
    if not data:
        display.print_success("No snapshots")
        return
    display.table(
        data,
        [("Name", "name"), ("Created", "created_at")],
        title=f"Snapshots: {container_id}",
    )


@app.command()
def create(
    container_id: str = typer.Argument(..., help="Container ID"),
    name: str | None = typer.Argument(
        None, help="Snapshot name (auto-generated if omitted)"
    ),
):
    """Create a snapshot."""
    body = {}
    if name:
        body["name"] = name
    data = client.post(f"/containers/{container_id}/snapshots", json=body)
    display.print_success(
        f"Snapshot '{data.get('name')}' created at {data.get('created_at')}"
    )


@app.command()
def restore(
    container_id: str = typer.Argument(..., help="Container ID"),
    name: str = typer.Argument(..., help="Snapshot name"),
):
    """Restore a snapshot."""
    typer.confirm(f"Restore {container_id} to snapshot '{name}'?", abort=True)
    client.post(f"/containers/{container_id}/snapshots/{name}/restore")
    display.print_success(f"Restored to snapshot '{name}'")


@app.command("backup-status")
def backup_status(container_id: str = typer.Argument(..., help="Container ID")):
    data = client.get(f"/containers/{container_id}/backup")
    display.detail(
        {
            "available": data.get("available"),
            "last_backup_at": data.get("last_backup_at"),
            "last_backup_run_id": data.get("last_backup_run_id"),
            "replication_status": data.get("replication_status"),
            "artifact_count": data.get("artifact_count"),
            "snapshot_name": data.get("snapshot_name"),
            "root_backup_mode": data.get("root_backup_mode"),
            "manifest_path": data.get("manifest_path"),
        },
        title=f"Backup Status: {container_id}",
    )


@app.command("restore-validation")
def restore_validation(container_id: str = typer.Argument(..., help="Container ID")):
    data = client.get(f"/containers/{container_id}/backup/restore-validation")
    display.detail(
        {
            "restore_available": data.get("restore_available"),
            "latest_restore_at": data.get("latest_restore_at"),
            "latest_restore_snapshot": data.get("latest_restore_snapshot"),
            "latest_snapshot_name": data.get("latest_snapshot_name"),
            "latest_snapshot_at": data.get("latest_snapshot_at"),
            "latest_restore_detail": data.get("latest_restore_detail"),
        },
        title=f"Restore Validation: {container_id}",
    )


@app.command()
def delete(
    container_id: str = typer.Argument(..., help="Container ID"),
    name: str = typer.Argument(..., help="Snapshot name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a snapshot."""
    if not yes:
        typer.confirm(f"Delete snapshot '{name}' from {container_id}?", abort=True)
    client.delete(f"/containers/{container_id}/snapshots/{name}")
    display.print_success(f"Snapshot '{name}' deleted")
