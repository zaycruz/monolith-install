"""Fleet status command — concise agent overview with optional watch mode."""

from __future__ import annotations

import time

import typer

from raava import client

app = typer.Typer(no_args_is_help=True)

_COL_NAME = 16
_COL_STATUS = 9
_COL_IP = 14
_COL_UPTIME = 8


def _fmt_uptime(seconds: int | float | None) -> str:
    if seconds is None:
        return "—"
    try:
        s = int(float(seconds))
    except (TypeError, ValueError):
        return str(seconds)
    h, rem = divmod(s, 3600)
    m = rem // 60
    if h:
        return f"{h}h {m}m"
    return f"{m}m"


def _render(rows: list[dict]) -> None:
    header = (
        f"{'NAME':<{_COL_NAME}}  "
        f"{'STATUS':<{_COL_STATUS}}  "
        f"{'IP':<{_COL_IP}}  "
        f"{'UPTIME':<{_COL_UPTIME}}"
    )
    typer.echo(header)
    for r in rows:
        name = str(r.get("agent_name") or r.get("id") or "")[:_COL_NAME]
        status = str(r.get("status") or "unknown")[:_COL_STATUS]
        ip = str(r.get("ip") or "—")[:_COL_IP]
        health = r.get("health") or {}
        uptime = _fmt_uptime(health.get("uptime_seconds") or health.get("uptime"))
        typer.echo(
            f"{name:<{_COL_NAME}}  "
            f"{status:<{_COL_STATUS}}  "
            f"{ip:<{_COL_IP}}  "
            f"{uptime:<{_COL_UPTIME}}"
        )


def _fetch_rows() -> list[dict]:
    data = client.get("/fleet/health")
    return data.get("containers", [])


@app.command()
def status(
    watch: bool = typer.Option(False, "--watch", "-w", help="Re-fetch every 5s until Ctrl+C"),
):
    """Show concise fleet-wide agent status."""
    if not watch:
        rows = _fetch_rows()
        _render(rows)
        return

    try:
        while True:
            rows = _fetch_rows()
            # Clear screen
            typer.echo("\033[2J\033[H", nl=False)
            _render(rows)
            time.sleep(5)
    except KeyboardInterrupt:
        pass
