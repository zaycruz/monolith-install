"""Real-time SSE streams."""

import typer
from rich.console import Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table

from raava import client, display

app = typer.Typer(no_args_is_help=True)


def _fleet_dashboard(
    stats: dict, health_rows: dict[str, dict], alerts: list[dict], hours: int
):
    summary = Table.grid(expand=True)
    summary.add_column(justify="right", style="bold cyan")
    summary.add_column()
    summary.add_row("Window", f"{hours}h")
    summary.add_row("Containers", str(stats.get("total_containers", 0)))
    summary.add_row("Running", str(stats.get("running_containers", 0)))
    summary.add_row("Agents", str(stats.get("active_agents", 0)))
    summary.add_row("Alerts", str(stats.get("total_alerts", len(alerts))))
    freshness = stats.get("_freshness") or {}
    backup = stats.get("backup") or {}
    if freshness:
        summary.add_row("Freshness", f"{freshness.get('staleness_ms', '?')} ms")
        summary.add_row("Updated", str(freshness.get("updated_at", "")))
    if backup:
        summary.add_row("Backup Run", str(backup.get("latest_run_id", "")))
        summary.add_row(
            "Replication",
            f"ok={backup.get('latest_run_replication_ok', 0)} failed={backup.get('latest_run_replication_failed', 0)}",
        )

    fleet = Table(
        title="Fleet Health",
        show_lines=False,
        pad_edge=True,
        padding=(0, 1),
        row_styles=["none", "dim"],
    )
    fleet.add_column("Container", style="bold")
    fleet.add_column("Agent")
    fleet.add_column("Status")
    fleet.add_column("CPU")
    fleet.add_column("Mem")
    fleet.add_column("Disk")
    fleet.add_column("RX B/s")
    fleet.add_column("TX B/s")
    fleet.add_column("Updated")

    for container in sorted(health_rows.keys()):
        row = health_rows[container]
        fleet.add_row(
            container,
            str(row.get("agent_name", "")),
            display.status_style(str(row.get("agent_status", "unknown"))),
            display.percent_bar(row.get("cpu", 0), color="cyan"),
            display.percent_bar(row.get("mem", 0), color="green"),
            display.percent_bar(row.get("disk", 0), color="magenta"),
            str(int(row.get("net_rx_rate", row.get("net_rx_bps", 0)) or 0)),
            str(int(row.get("net_tx_rate", row.get("net_tx_bps", 0)) or 0)),
            str(row.get("recorded_at", "")),
        )

    if alerts:
        alert_lines = []
        for alert in alerts[:8]:
            message = alert.get("message", str(alert))
            alert_lines.append(f"[yellow]•[/] {message}")
        alerts_panel = Panel(
            "\n".join(alert_lines), title="Alerts", border_style="yellow", expand=False
        )
    else:
        alerts_panel = Panel(
            "[green]No active alerts[/green]", title="Alerts", expand=False
        )

    return Group(
        Panel(summary, title="Fleet Stream", border_style="blue", expand=False),
        fleet,
        alerts_panel,
    )


@app.command("fleet")
def stream_fleet(hours: int = typer.Option(24, "--hours", "-H")):
    """Live fleet-wide stream (Ctrl+C to stop)."""
    if display.is_json_mode():
        for event in client.stream_sse("/stream/fleet", params={"hours": hours}):
            display.print_json(event)
        return

    stats: dict = {}
    alerts: list[dict] = []
    health_rows: dict[str, dict] = {}

    display.console.clear()
    try:
        with Live(
            _fleet_dashboard(stats, health_rows, alerts, hours),
            console=display.console,
            refresh_per_second=4,
            screen=True,
        ) as live:
            for event in client.stream_sse("/stream/fleet", params={"hours": hours}):
                event_type = event.get("type", "")
                payload = event.get("data", event)

                if event_type == "stats" and isinstance(payload, dict):
                    stats.update(payload)
                    stats["_freshness"] = event.get("freshness", {})
                elif event_type == "alerts" and isinstance(payload, list):
                    alerts = payload
                elif event_type == "health" and isinstance(payload, list):
                    for item in payload:
                        container = item.get("id") or item.get("container_id")
                        if container:
                            health_rows[str(container)] = item
                elif event_type == "error":
                    message = event.get("message", str(event))
                    alerts = [{"message": message, "level": "error"}] + alerts

                live.update(_fleet_dashboard(stats, health_rows, alerts, hours))
    except KeyboardInterrupt:
        display.console.print("\n[dim]Stream closed[/dim]")


@app.command("container")
def stream_container(
    container_id: str = typer.Argument(..., help="Container ID"),
    hours: int = typer.Option(24, "--hours", "-H"),
):
    """Live single-container stream (Ctrl+C to stop)."""
    resolved = client.resolve_container_id(container_id)
    display.console.print(f"[dim]Streaming {resolved}... (Ctrl+C to stop)[/dim]")
    try:
        for event in client.stream_sse(
            f"/stream/container/{resolved}", params={"hours": hours}
        ):
            event_type = event.get("type", "")
            payload = event.get("data", event)

            if event_type == "health":
                name = payload.get("agent_name", resolved)
                state = display.status_style(payload.get("agent_status", "unknown"))
                cpu = payload.get("cpu", 0)
                mem = payload.get("mem", 0)
                disk = payload.get("disk", 0)
                rx = payload.get("net_rx_rate", payload.get("net_rx_bps", 0)) or 0
                tx = payload.get("net_tx_rate", payload.get("net_tx_bps", 0)) or 0
                freshness = event.get("freshness", {})
                display.console.print(
                    f"[bold]{name}[/] status={state} cpu={cpu:.0f}% mem={mem:.0f}% disk={disk:.0f}% rx={rx:.0f}B/s tx={tx:.0f}B/s freshness={freshness.get('staleness_ms', '?')}ms"
                )
            elif event_type == "tokens":
                freshness = event.get("freshness", {})
                display.console.print(
                    f"[dim]tokens window={hours}h freshness={freshness.get('staleness_ms', '?')}ms[/dim]"
                )
            elif event_type == "error":
                display.print_error(payload.get("message", str(payload)))
    except KeyboardInterrupt:
        display.console.print("\n[dim]Stream closed[/dim]")
