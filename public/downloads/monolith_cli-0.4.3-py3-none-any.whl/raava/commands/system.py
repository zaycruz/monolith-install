"""Container system introspection."""

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command()
def processes(
    container_id: str = typer.Argument(..., help="Container ID"),
    limit: int = typer.Option(25, "--limit", "-n"),
):
    """List processes inside a container."""
    data = client.get(
        f"/containers/{container_id}/system/processes", params={"limit": limit}
    )
    summary = data.get("summary", {})
    procs = data.get("processes", [])
    cols = [
        ("PID", "pid"),
        ("Name", "name"),
        ("CPU%", "cpu"),
        ("Mem MB", "mem_mb"),
        ("Mem%", "mem_pct"),
        ("Command", "command"),
    ]
    display.table(
        procs,
        cols,
        title=f"Processes: {container_id} (CPU: {summary.get('cpu', 0)}%, Mem: {summary.get('mem_mb', 0)}MB)",
    )


@app.command()
def env(container_id: str = typer.Argument(..., help="Container ID")):
    """Get environment variables (sensitive values redacted)."""
    data = client.get(f"/containers/{container_id}/system/env")
    if display.is_json_mode():
        display.print_json(data)
        return
    display.console.print(f"[dim]Service: {data.get('service_name', 'unknown')}[/dim]")
    for k, v in data.get("environment", {}).items():
        if v == "***":
            display.console.print(f"  [bold]{k}[/bold] = [dim red]***[/dim red]")
        else:
            display.console.print(f"  [bold]{k}[/bold] = {v}")


@app.command()
def connections(container_id: str = typer.Argument(..., help="Container ID")):
    """Check service connectivity from inside a container."""
    data = client.get(f"/containers/{container_id}/system/connections")
    conns = data.get("connections", [])
    for c in conns:
        s = c.get("status", "unknown")
        if s == "connected":
            c["_status"] = f"[green]connected[/green] ({c.get('latency_ms', '?')}ms)"
        elif s == "down":
            c["_status"] = "[red]down[/red]"
        elif s == "not_configured":
            c["_status"] = "[dim]not configured[/dim]"
        else:
            c["_status"] = f"[yellow]{s}[/yellow]"
    cols = [
        ("Service", "name"),
        ("Description", "description"),
        ("Status", "_status"),
    ]
    display.table(conns, cols, title=f"Connections: {container_id}")


@app.command()
def info(
    container_id: str = typer.Argument(..., help="Container ID"),
    hours: int = typer.Option(24, "--hours", "-H"),
):
    """OS and system info."""
    data = client.get(
        f"/containers/{container_id}/system/info", params={"hours": hours}
    )
    display.detail(
        {
            "container": data.get("container_name"),
            "os": data.get("os_name"),
            "kernel": data.get("kernel"),
            "hostname": data.get("hostname"),
            "uptime": data.get("uptime"),
            "image": data.get("image"),
            "arch": data.get("arch"),
            "memory_limit": data.get("memory_limit"),
            "cpu_limit": data.get("cpu_limit"),
            "disk_limit": data.get("disk_limit"),
            "restarts": f"{data.get('restarts_count', 0)} (last {hours}h)",
        },
        title=f"System: {container_id}",
    )


@app.command("host")
def host():
    """Host-level CPU, memory, disk, load averages, and LXD status."""
    data = client.get("/system/host/health")
    backup = data.get("backup", {})
    display.detail(
        {
            "verdict": data.get("verdict"),
            "cpu_count": data.get("load", {}).get("cpu_count", 0),
            "load": f"{data.get('load', {}).get('load_1', 0):.2f} / {data.get('load', {}).get('load_5', 0):.2f} / {data.get('load', {}).get('load_15', 0):.2f}",
            "memory": f"{display.format_bytes(data.get('memory', {}).get('used_bytes', 0))} / {display.format_bytes(data.get('memory', {}).get('total_bytes', 0))}",
            "memory_available": display.format_bytes(
                data.get("memory", {}).get("available_bytes", 0)
            ),
            "root_disk": f"{data.get('root_disk', {}).get('used_percent', 0):.1f}%",
            "backup_disk": f"{backup.get('used_percent', 0):.1f}%",
            "backup_latest_run": backup.get("latest_run_id"),
            "backup_replication": f"ok={backup.get('latest_run_replication_ok', 0)} failed={backup.get('latest_run_replication_failed', 0)}",
            "snapshot_total": data.get("snapshots", {}).get("total", 0),
            "problem_instances": ", ".join(
                data.get("lxd", {}).get("problem_instances", [])
            )
            or "—",
            "alerts": len(data.get("alerts", [])),
            "checked_at": data.get("checked_at"),
        },
        title="Host Health",
    )


@app.command("host-history")
def host_history(
    hours: int = typer.Option(24, "--hours", "-H", help="Hours of history"),
):
    """Host metrics time-series history."""
    data = client.get("/system/host/history", params={"hours": hours})
    history = data.get("history", [])
    if not history:
        display.print_warning(f"No host metrics in the last {hours}h")
        return
    cols = [
        ("Time", "recorded_at"),
        ("CPU%", "_cpu"),
        ("Mem%", "_mem"),
        ("Disk%", "_disk"),
        ("Load 1m", "_load"),
        ("VMs", "_vms"),
    ]
    for h in history:
        h["_cpu"] = f"{h.get('cpu', 0):.1f}"
        h["_mem"] = f"{h.get('mem', 0):.1f}"
        h["_disk"] = f"{h.get('disk', 0):.1f}"
        h["_load"] = f"{h.get('load_1', 0):.2f}"
        h["_vms"] = f"{h.get('running_vm_count', 0)}/{h.get('vm_count', 0)}"
    display.table(
        history,
        cols,
        title=f"Host History: {data.get('hours')}h ({data.get('points')} points)",
    )
