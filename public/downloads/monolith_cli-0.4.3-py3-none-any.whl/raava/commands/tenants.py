"""Tenant and business unit management."""


import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_tenants():
    """List all tenants."""
    data = client.get("/tenants")
    cols = [
        ("ID", "id"),
        ("Name", "name"),
        ("Contact", "contact"),
        ("Status", "status"),
        ("Created", "created_at"),
    ]
    display.table(data, cols, title="Tenants")


@app.command()
def create(
    tenant_id: str = typer.Option(..., "--id", help="Tenant slug/ID"),
    name: str = typer.Option(..., "--name"),
    contact: str | None = typer.Option(None, "--contact"),
    notes: str | None = typer.Option(None, "--notes"),
    op_token: str | None = typer.Option(None, "--op-token", help="1Password service account token"),
    op_vault: str | None = typer.Option(None, "--op-vault", help="1Password vault name"),
):
    """Create a tenant."""
    body = {"id": tenant_id, "name": name}
    if contact is not None:
        body["contact"] = contact
    if notes is not None:
        body["notes"] = notes
    if op_token is not None:
        body["op_token"] = op_token
    if op_vault is not None:
        body["op_vault_name"] = op_vault
    client.post("/tenants", json=body)
    display.print_success(f"Tenant '{tenant_id}' created")


@app.command()
def show(tenant_id: str = typer.Argument(..., help="Tenant ID")):
    """Show tenant detail with containers."""
    data = client.get(f"/tenants/{tenant_id}")
    display.detail(data, title=f"Tenant: {tenant_id}")


@app.command()
def update(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
    name: str | None = typer.Option(None, "--name"),
    contact: str | None = typer.Option(None, "--contact"),
    notes: str | None = typer.Option(None, "--notes"),
    tenant_status: str | None = typer.Option(None, "--status"),
    op_token: str | None = typer.Option(None, "--op-token", help="1Password service account token"),
    op_vault: str | None = typer.Option(None, "--op-vault", help="1Password vault name"),
):
    """Update tenant fields."""
    body = {}
    if name is not None:
        body["name"] = name
    if contact is not None:
        body["contact"] = contact
    if notes is not None:
        body["notes"] = notes
    if tenant_status is not None:
        body["status"] = tenant_status
    if op_token is not None:
        body["op_token"] = op_token
    if op_vault is not None:
        body["op_vault_name"] = op_vault
    if not body:
        display.print_error("No fields specified")
        raise typer.Exit(1)
    client.patch(f"/tenants/{tenant_id}", json=body)
    display.print_success(f"Tenant '{tenant_id}' updated")


@app.command("delete")
def delete_tenant(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Offboard a tenant (soft-delete, sets status to offboarded)."""
    if not yes:
        typer.confirm(f"Offboard tenant '{tenant_id}'? This will mark it as inactive", abort=True)
    client.delete(f"/tenants/{tenant_id}")
    display.print_success(f"Tenant '{tenant_id}' offboarded")


@app.command()
def units(tenant_id: str = typer.Argument(..., help="Tenant ID")):
    """List business units for a tenant."""
    data = client.get(f"/tenants/{tenant_id}/units")
    cols = [
        ("ID", "id"),
        ("Name", "name"),
        ("Description", "description"),
        ("Created", "created_at"),
    ]
    display.table(data, cols, title=f"Units: {tenant_id}")


@app.command("add-unit")
def add_unit(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
    unit_id: str = typer.Option(..., "--id", help="Unit slug/ID"),
    name: str = typer.Option(..., "--name"),
    description: str | None = typer.Option(None, "--desc"),
):
    """Create a business unit."""
    body = {"id": unit_id, "name": name}
    if description:
        body["description"] = description
    client.post(f"/tenants/{tenant_id}/units", json=body)
    display.print_success(f"Unit '{unit_id}' created under {tenant_id}")


@app.command("update-unit")
def update_unit(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
    unit_id: str = typer.Argument(..., help="Unit ID"),
    name: str | None = typer.Option(None, "--name"),
    description: str | None = typer.Option(None, "--desc"),
):
    """Update a business unit."""
    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if not body:
        display.print_error("No fields specified")
        raise typer.Exit(1)
    client.patch(f"/tenants/{tenant_id}/units/{unit_id}", json=body)
    display.print_success(f"Unit '{unit_id}' updated")


@app.command("delete-unit")
def delete_unit(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
    unit_id: str = typer.Argument(..., help="Unit ID"),
    yes: bool = typer.Option(False, "--yes", "-y"),
):
    """Delete a business unit."""
    if not yes:
        typer.confirm(f"Delete unit '{unit_id}'?", abort=True)
    client.delete(f"/tenants/{tenant_id}/units/{unit_id}")
    display.print_success(f"Unit '{unit_id}' deleted")


@app.command("generate-key")
def generate_key(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
):
    """Generate an API key for a tenant."""
    data = client.post(f"/tenants/{tenant_id}/api-key")
    if isinstance(data, dict) and data.get("api_key"):
        display.print_success(f"API key for '{tenant_id}': {data['api_key']}")
    else:
        display.detail(data, title=f"API Key: {tenant_id}")


@app.command("revoke-key")
def revoke_key(
    tenant_id: str = typer.Argument(..., help="Tenant ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Revoke (rotate) the API key for a tenant."""
    if not yes:
        typer.confirm(f"Revoke API key for tenant '{tenant_id}'?", abort=True)
    data = client.post(f"/tenants/{tenant_id}/api-key/rotate")
    if isinstance(data, dict) and data.get("api_key"):
        display.print_success(f"New API key for '{tenant_id}': {data['api_key']}")
    else:
        display.print_success(f"API key for '{tenant_id}' revoked")
