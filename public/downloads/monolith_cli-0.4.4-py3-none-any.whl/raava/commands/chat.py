"""Interactive CLI chat with the fleet agent — like Claude Code but for your fleet."""

import json

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=False)


def _render_blocks(blocks: list[dict]):
    """Render agent response blocks to the terminal."""
    for block in blocks:
        btype = block.get("type", "")
        if btype == "text":
            text = block.get("text", "")
            try:
                from rich.markdown import Markdown
                display.console.print(Markdown(text))
            except Exception:
                display.console.print(text)
        elif btype == "thinking":
            text = block.get("text", "")
            preview = text[:300] + ("..." if len(text) > 300 else "")
            display.console.print(f"[dim italic]  > thinking: {preview}[/dim italic]")
        elif btype in ("tool_call", "tool_use"):
            name = block.get("name", "?")
            tool_input = block.get("input", "")
            input_str = ""
            if tool_input:
                if isinstance(tool_input, dict):
                    input_str = f" {json.dumps(tool_input)[:150]}"
                else:
                    input_str = f" {str(tool_input)[:150]}"
            display.console.print(f"  [yellow]> tool:[/yellow] [bold]{name}[/bold][dim]{input_str}[/dim]")
        elif btype == "tool_result":
            content = block.get("content", "")
            preview = str(content)[:200]
            display.console.print(f"  [green]< result:[/green] [dim]{preview}[/dim]")


def _stream_response(content: str, session_id: str | None, context: str | None):
    """Stream SSE response from the agent, return session_id."""
    import httpx

    from raava.client import _auth_headers, _base_url

    body = {"content": content}
    if session_id:
        body["session_id"] = session_id
    if context:
        body["context"] = context

    result_session_id = session_id

    # Agent can take a while: thinking + multiple tool calls + response generation
    # Connect fast (10s), but allow up to 5 min between SSE chunks (tool execution time)
    stream_timeout = httpx.Timeout(connect=10.0, read=300.0, write=10.0, pool=10.0)

    with httpx.Client(base_url=_base_url(), timeout=stream_timeout, headers=_auth_headers()) as c:
        with c.stream("POST", "/api/terminal/message/stream", json=body) as resp:
            if resp.status_code >= 400:
                display.print_error(f"API error: {resp.status_code}")
                return session_id

            for line in resp.iter_lines():
                if not line.startswith("data: "):
                    continue
                try:
                    event = json.loads(line[6:])
                except json.JSONDecodeError:
                    continue

                etype = event.get("type", "")

                if etype == "session":
                    result_session_id = event.get("session_id", session_id)

                elif etype == "text_delta":
                    # Real-time streaming text token
                    text = event.get("text", "")
                    print(text, end="", flush=True)

                elif etype == "text":
                    # Complete text block (fallback from non-streaming)
                    text = event.get("text", "")
                    try:
                        from rich.markdown import Markdown
                        display.console.print(Markdown(text))
                    except Exception:
                        display.console.print(text)

                elif etype == "thinking_start":
                    display.console.print("[dim italic]  > thinking...[/dim italic]", end="")

                elif etype == "thinking_delta":
                    # Stream thinking tokens (dimmed)
                    text = event.get("text", "")
                    print(text, end="", flush=True)

                elif etype == "thinking":
                    # Complete thinking block (fallback)
                    text = event.get("text", "")
                    preview = text[:300] + ("..." if len(text) > 300 else "")
                    display.console.print(f"[dim italic]  > thinking: {preview}[/dim italic]")

                elif etype == "tool_start":
                    name = event.get("name", "?")
                    tool_input = event.get("input", "")
                    input_str = ""
                    if tool_input:
                        if isinstance(tool_input, dict):
                            input_str = f" {json.dumps(tool_input)[:150]}"
                        else:
                            input_str = f" {str(tool_input)[:150]}"
                    display.console.print(f"\n  [yellow]> tool:[/yellow] [bold]{name}[/bold][dim]{input_str}[/dim]")

                elif etype == "tool_result":
                    content_str = event.get("content", "")
                    preview = str(content_str)[:200]
                    display.console.print(f"  [green]< result:[/green] [dim]{preview}[/dim]")

                elif etype == "error":
                    display.print_error(event.get("message", "Unknown error"))

                elif etype == "done":
                    print()  # newline after streaming
                    break

    return result_session_id


@app.callback(invoke_without_command=True)
def chat(
    message: str | None = typer.Argument(None, help="One-shot message (omit for interactive REPL)"),
    context: str | None = typer.Option(None, "--context", "-c", help="Container ID for context"),
    session: str | None = typer.Option(None, "--session", "-s", help="Resume a session ID"),
    no_stream: bool = typer.Option(False, "--no-stream", help="Disable streaming (get full response at once)"),
):
    """Chat with the fleet management agent.

    Interactive REPL mode (no arguments):
        monolith chat

    One-shot mode:
        monolith chat "what containers are running?"
        monolith chat --context raava-kei "restart the agent"

    Direct shell commands (! prefix):
        monolith chat "!lxc list"
    """
    session_id = session

    # One-shot mode
    if message:
        if no_stream:
            data = client.post("/terminal/message", timeout=300.0, json={
                "content": message,
                "session_id": session_id,
                "context": context,
            })
            if data.get("mode") == "direct":
                stdout = data.get("stdout", "")
                stderr = data.get("stderr", "")
                rc = data.get("exit_code", 0)
                output = stdout or stderr or "(no output)"
                if rc != 0:
                    display.print_error(f"Exit code {rc}: {output}")
                else:
                    display.console.print(output)
            else:
                _render_blocks(data.get("blocks", []))
        else:
            _stream_response(message, session_id, context)
        return

    # Interactive REPL mode
    display.console.print(
        "[bold]Monolith Fleet Agent[/bold] [dim](Ctrl+C to exit, ! prefix for shell commands)[/dim]\n"
    )

    if context:
        display.console.print(f"[dim]Context: {context}[/dim]\n")

    while True:
        try:
            user_input = display.console.input("[bold cyan]> [/bold cyan]")
        except (KeyboardInterrupt, EOFError):
            display.console.print("\n[dim]Goodbye[/dim]")
            break

        user_input = user_input.strip()
        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "/quit", "/exit"):
            display.console.print("[dim]Goodbye[/dim]")
            break

        if user_input.startswith("/context "):
            context = user_input[9:].strip() or None
            display.console.print(f"[dim]Context: {context or 'fleet-wide'}[/dim]")
            continue

        if user_input == "/session":
            display.console.print(f"[dim]Session: {session_id or 'none'}[/dim]")
            continue

        display.console.print()

        if no_stream:
            try:
                data = client.post("/terminal/message", timeout=300.0, json={
                    "content": user_input,
                    "session_id": session_id,
                    "context": context,
                })
                if data.get("mode") == "direct":
                    stdout = data.get("stdout", "")
                    stderr = data.get("stderr", "")
                    rc = data.get("exit_code", 0)
                    output = stdout or stderr or "(no output)"
                    if rc != 0:
                        display.print_error(f"Exit code {rc}: {output}")
                    else:
                        display.console.print(output)
                else:
                    session_id = data.get("session_id", session_id)
                    _render_blocks(data.get("blocks", []))
            except Exception as e:
                display.print_error(str(e))
        else:
            try:
                session_id = _stream_response(user_input, session_id, context)
            except Exception as e:
                display.print_error(str(e))

        display.console.print()
