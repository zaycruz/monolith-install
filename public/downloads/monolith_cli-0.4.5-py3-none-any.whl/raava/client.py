"""HTTP client for the Raava Fleet API."""

from __future__ import annotations

import difflib

import httpx

from raava import config


class APIError(Exception):
    def __init__(self, status: int, detail: str):
        self.status = status
        self.detail = detail
        super().__init__(f"HTTP {status}: {detail}")


def _base_url() -> str:
    return config.get("api_url", "http://ubuntu-server.local:8400")


def _timeout() -> float:
    return float(config.get("timeout", 30))


def _auth_headers() -> dict[str, str]:
    """Build auth headers from RAAVA_API_KEY env var or config api_key."""
    import os
    api_key = os.environ.get("RAAVA_API_KEY") or config.get("api_key", "")
    if api_key:
        return {"Authorization": f"Bearer {api_key}"}
    return {}


def _client() -> httpx.Client:
    return httpx.Client(
        base_url=_base_url(),
        timeout=_timeout(),
        headers=_auth_headers(),
    )


def _handle(resp: httpx.Response):
    if resp.status_code >= 400:
        try:
            body = resp.json()
            if "error" in body:
                msg = body["error"]
            elif "detail" in body:
                detail = body["detail"]
                if isinstance(detail, dict):
                    msg = detail.get("error", str(detail))
                else:
                    msg = str(detail)
            else:
                msg = resp.text
        except Exception:
            msg = resp.text
        raise APIError(resp.status_code, msg)
    return resp.json()


def resolve_container_id(container_id: str) -> str:
    """Resolve partial container IDs (for example: kei -> raava-kei)."""
    query = (container_id or "").strip()
    if not query:
        return container_id

    data = get("/containers")
    containers = data.get("containers", []) if isinstance(data, dict) else []
    containers = [c for c in containers if c.get("status") != "deleted"]
    ids = [c.get("id") for c in containers if c.get("id")]

    if not ids:
        raise APIError(404, "No containers available for ID resolution")

    if query in ids:
        return query

    lower_map = {cid.lower(): cid for cid in ids}
    lowered = query.lower()
    if lowered in lower_map:
        return lower_map[lowered]

    prefix_matches = [cid for cid in ids if cid.lower().startswith(lowered)]
    if len(prefix_matches) == 1:
        return prefix_matches[0]
    if len(prefix_matches) > 1:
        matches = ", ".join(prefix_matches[:8])
        raise APIError(400, f"Ambiguous container {query}. Matches: {matches}")

    contains_matches = [cid for cid in ids if lowered in cid.lower()]
    if len(contains_matches) == 1:
        return contains_matches[0]
    if len(contains_matches) > 1:
        matches = ", ".join(contains_matches[:8])
        raise APIError(400, f"Ambiguous container {query}. Matches: {matches}")

    close = difflib.get_close_matches(
        lowered, [cid.lower() for cid in ids], n=1, cutoff=0.45
    )
    if close:
        return lower_map[close[0]]

    raise APIError(404, f"No container matching {query}")


def _resolve_container_in_path(path: str) -> str:
    marker = "/containers/"
    idx = path.find(marker)
    if idx == -1:
        return path

    start = idx + len(marker)
    remainder = path[start:]
    if not remainder:
        return path

    container_id, sep, tail = remainder.partition("/")
    if not container_id:
        return path

    resolved = resolve_container_id(container_id)
    if resolved == container_id:
        return path

    return f"{path[:start]}{resolved}{sep}{tail}"


def get(path: str, params: dict | None = None):
    with _client() as c:
        api_path = _resolve_container_in_path(path)
        return _handle(c.get(f"/api{api_path}", params=params))


def post(path: str, json: dict | None = None, timeout: float | None = None):
    with _client() as c:
        api_path = _resolve_container_in_path(path)
        return _handle(c.post(f"/api{api_path}", json=json, timeout=timeout))


def put(path: str, json: dict | None = None):
    with _client() as c:
        api_path = _resolve_container_in_path(path)
        return _handle(c.put(f"/api{api_path}", json=json))


def patch(path: str, json: dict | None = None):
    with _client() as c:
        api_path = _resolve_container_in_path(path)
        return _handle(c.patch(f"/api{api_path}", json=json))


def delete(path: str):
    with _client() as c:
        api_path = _resolve_container_in_path(path)
        return _handle(c.delete(f"/api{api_path}"))


def stream_sse(path: str, params: dict | None = None):
    """Yield SSE data lines from a streaming endpoint."""
    import json as jsonlib

    with _client() as c:
        with c.stream("GET", f"/api{path}", params=params) as resp:
            if resp.status_code >= 400:
                raise APIError(resp.status_code, "Stream failed")
            for line in resp.iter_lines():
                if line.startswith("data: "):
                    try:
                        yield jsonlib.loads(line[6:])
                    except Exception:
                        pass
