"""Authentication commands for the Monolith CLI."""

import typer

from raava import config, display

app = typer.Typer(no_args_is_help=True)

# Default production portal URL for token exchange.
_DEFAULT_PORTAL_URL = "https://thisismonolith.com"


@app.command("login")
def login(
    token: str = typer.Option(
        None, "--token", "-t", help="One-time token from the portal"
    ),
    key: str = typer.Option(None, "--key", "-k", help="API key (rk_...) directly"),
    url: str = typer.Option(
        None,
        "--url",
        help="Fleet API URL (saved alongside the key)",
    ),
    portal_url: str = typer.Option(
        _DEFAULT_PORTAL_URL,
        "--portal-url",
        help="Portal base URL for token exchange",
    ),
):
    """Authenticate the CLI with your Monolith account.

    Provide either --token (one-time token from the portal) or --key (API key
    directly).  When using --token the CLI exchanges it with the portal for a
    permanent API key and fleet URL.
    """
    import httpx

    if token:
        exchange_endpoint = (
            f"{portal_url.rstrip('/')}/api/auth/cli-exchange"
        )
        try:
            resp = httpx.get(exchange_endpoint, params={"token": token}, timeout=15)
        except httpx.HTTPError as exc:
            display.print_error(f"Token exchange request failed: {exc}")
            raise typer.Exit(1)

        if resp.status_code != 200:
            display.print_error(f"Token exchange failed (HTTP {resp.status_code}): {resp.text}")
            raise typer.Exit(1)

        data = resp.json()
        api_key: str = data["apiKey"]
        fleet_url: str = data.get("fleetApiUrl", "")
        tenant_id: str = data.get("tenantId", "")

        config.set_value("api_key", api_key)
        if fleet_url:
            config.set_value("api_url", fleet_url)
        if tenant_id:
            config.set_value("tenant_id", tenant_id)

        display.print_success("Authenticated successfully.")
        display.console.print(f"  [bold]API URL:[/]  {fleet_url or config.get('api_url')}")
        display.console.print(f"  [bold]Key:[/]      {api_key[:8]}...")
        if tenant_id:
            display.console.print(f"  [bold]Tenant:[/]   {tenant_id}")

    elif key:
        api_key = key
        config.set_value("api_key", api_key)
        if url:
            config.set_value("api_url", url)

        display.print_success("Authenticated successfully.")
        display.console.print(f"  [bold]API URL:[/]  {url or config.get('api_url')}")
        display.console.print(f"  [bold]Key:[/]      {api_key[:8]}...")

    else:
        display.print_error("Provide --token (from portal) or --key (API key directly).")
        raise typer.Exit(1)

    display.console.print(f"\nConfig saved to {config.CONFIG_FILE}")


@app.command("status")
def status():
    """Show current authentication status."""
    api_key = config.get("api_key", "")
    api_url = config.get("api_url", "")
    tenant_id = config.get("tenant_id", "")

    if not api_key:
        display.print_warning("Not authenticated. Run [bold]raava auth login[/] to authenticate.")
        raise typer.Exit(1)

    display.console.print("[bold green]Authenticated[/]")
    display.console.print(f"  [bold]API URL:[/]  {api_url}")
    display.console.print(f"  [bold]Key:[/]      {api_key[:8]}...")
    if tenant_id:
        display.console.print(f"  [bold]Tenant:[/]   {tenant_id}")
    display.console.print(f"  [bold]Config:[/]   {config.CONFIG_FILE}")


@app.command("logout")
def logout():
    """Remove saved credentials."""
    api_key = config.get("api_key", "")
    if not api_key:
        display.print_warning("Already logged out.")
        return

    config.delete_key("api_key")
    config.delete_key("tenant_id")
    display.print_success("Credentials removed.")
