"""Monolith Fleet API — MCP Server.

Exposes fleet management tools to Claude Code and other MCP clients.
Run via: python -m raava.mcp_server
Or register in .mcp.json / settings.json
"""

from __future__ import annotations

import os

import httpx
from mcp.server.fastmcp import FastMCP

server = FastMCP(
    name="monolith-fleet",
    instructions=(
        "Monolith Fleet API — manage LXC containers and AI agents. "
        "Use these tools to check fleet health, manage containers and agents, "
        "view logs, provision new agents, manage tenants, and more."
    ),
)

API_URL = (
    os.environ.get("MONOLITH_API_URL")
    or os.environ.get("RAAVA_API_URL")
    or "http://127.0.0.1:8400"
)
TIMEOUT = 30.0


def _client() -> httpx.Client:
    api_key = os.environ.get("MONOLITH_API_KEY") or os.environ.get("RAAVA_API_KEY", "")
    headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
    return httpx.Client(base_url=API_URL, timeout=TIMEOUT, headers=headers)


def _get(path: str, params: dict | None = None) -> dict | list:
    with _client() as c:
        resp = c.get(f"/api{path}", params=params)
        resp.raise_for_status()
        return resp.json()


def _post(path: str, body: dict | None = None) -> dict:
    with _client() as c:
        resp = c.post(f"/api{path}", json=body or {})
        resp.raise_for_status()
        return resp.json()


def _patch(path: str, body: dict | None = None) -> dict:
    with _client() as c:
        resp = c.patch(f"/api{path}", json=body or {})
        resp.raise_for_status()
        return resp.json()


def _delete(path: str) -> dict:
    with _client() as c:
        resp = c.delete(f"/api{path}")
        resp.raise_for_status()
        return resp.json()


# ═══════════════════════════════════════════
# Fleet
# ═══════════════════════════════════════════

@server.tool(description="Get fleet-wide health overview — all containers with CPU, memory, disk, and agent status")
def fleet_health() -> dict:
    return _get("/fleet/health")


@server.tool(description="Get fleet aggregate stats — total containers, running count, active agents, alert count")
def fleet_stats() -> dict:
    return _get("/fleet/stats")


@server.tool(description="Get current threshold alerts across the fleet")
def fleet_alerts() -> list:
    return _get("/fleet/alerts")


@server.tool(description="Get cross-tenant audit feed of recent actions")
def fleet_audit(hours: int = 1, limit: int = 50) -> list:
    return _get("/fleet/audit", params={"hours": hours, "limit": limit})


@server.tool(description="Filter agents across the fleet by status, tenant, or unit")
def fleet_agents(status: str | None = None, tenant: str | None = None, unit: str | None = None) -> dict:
    params = {}
    if status:
        params["status"] = status
    if tenant:
        params["tenant"] = tenant
    if unit:
        params["unit"] = unit
    return _get("/fleet/agents", params=params)


# ═══════════════════════════════════════════
# Containers
# ═══════════════════════════════════════════

@server.tool(description="List all managed containers with their health snapshots")
def containers_list() -> dict:
    return _get("/containers")


@server.tool(description="Get detailed info for a specific container including health, snapshots, and audit log")
def container_detail(container_id: str) -> dict:
    return _get(f"/containers/{container_id}")


@server.tool(description="Start a stopped container")
def container_start(container_id: str) -> dict:
    return _post(f"/containers/{container_id}/start")


@server.tool(description="Stop a running container. Use force=True to force-kill.")
def container_stop(container_id: str, force: bool = False) -> dict:
    return _post(f"/containers/{container_id}/stop", body={"force": force})


@server.tool(description="Restart a container")
def container_restart(container_id: str) -> dict:
    return _post(f"/containers/{container_id}/restart")


@server.tool(description="Delete a container permanently")
def container_delete(container_id: str) -> dict:
    return _delete(f"/containers/{container_id}")


@server.tool(description="Update container metadata — agent_name, agent_role, model, memory_limit, cpu_limit")
def container_update(
    container_id: str,
    agent_name: str | None = None,
    agent_role: str | None = None,
    model: str | None = None,
    memory_limit: str | None = None,
    cpu_limit: str | None = None,
) -> dict:
    body = {}
    if agent_name:
        body["agent_name"] = agent_name
    if agent_role:
        body["agent_role"] = agent_role
    if model:
        body["model"] = model
    if memory_limit:
        body["memory_limit"] = memory_limit
    if cpu_limit:
        body["cpu_limit"] = cpu_limit
    return _patch(f"/containers/{container_id}", body=body)


# ═══════════════════════════════════════════
# Agent (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="Get the agent process status inside a container (PID, uptime, stack type)")
def agent_status(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/agent")


@server.tool(description="Get agent logs from inside a container")
def agent_logs(container_id: str, lines: int = 100, since: str | None = None) -> dict:
    params = {"lines": lines}
    if since:
        params["since"] = since
    return _get(f"/containers/{container_id}/agent/logs", params=params)


@server.tool(description="Start the agent service inside a container")
def agent_start(container_id: str) -> dict:
    return _post(f"/containers/{container_id}/agent/start")


@server.tool(description="Stop the agent service inside a container")
def agent_stop(container_id: str) -> dict:
    return _post(f"/containers/{container_id}/agent/stop")


@server.tool(description="Restart the agent service inside a container")
def agent_restart(container_id: str) -> dict:
    return _post(f"/containers/{container_id}/agent/restart")


# ═══════════════════════════════════════════
# Health
# ═══════════════════════════════════════════

@server.tool(description="Get the latest health snapshot for a container (CPU, mem, disk, network)")
def container_health(container_id: str) -> dict:
    with _client() as c:
        resp = c.get(f"/api/containers/{container_id}/health")
        if resp.status_code == 404:
            return {"message": "No health data available yet", "container_id": container_id}
        resp.raise_for_status()
        return resp.json()


@server.tool(description="Get health history with avg/peak stats for charting")
def container_health_history(container_id: str, hours: int = 24) -> dict:
    return _get(f"/containers/{container_id}/health/history", params={"hours": hours})


# ═══════════════════════════════════════════
# Snapshots
# ═══════════════════════════════════════════

@server.tool(description="List LXD snapshots for a container")
def snapshots_list(container_id: str) -> list:
    return _get(f"/containers/{container_id}/snapshots")


@server.tool(description="Create an LXD snapshot of a container")
def snapshot_create(container_id: str, name: str | None = None) -> dict:
    body = {}
    if name:
        body["name"] = name
    return _post(f"/containers/{container_id}/snapshots", body=body)


@server.tool(description="Restore a container from a snapshot")
def snapshot_restore(container_id: str, snapshot_name: str) -> dict:
    return _post(f"/containers/{container_id}/snapshots/{snapshot_name}/restore")


@server.tool(description="Delete a snapshot")
def snapshot_delete(container_id: str, snapshot_name: str) -> dict:
    return _delete(f"/containers/{container_id}/snapshots/{snapshot_name}")


# ═══════════════════════════════════════════
# Files (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="List directory contents inside a container")
def files_list(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/files", params={"path": path})


@server.tool(description="Read a file from inside a container")
def file_read(container_id: str, path: str) -> dict:
    return _get(f"/containers/{container_id}/files/{path.lstrip('/')}")


@server.tool(description="Write content to a file inside a container")
def file_write(container_id: str, path: str, content: str) -> dict:
    from raava.client import put
    return put(f"/containers/{container_id}/files/{path.lstrip('/')}", json={"content": content})


@server.tool(description="Delete a file or directory inside a container")
def file_delete(container_id: str, path: str) -> dict:
    return _delete(f"/containers/{container_id}/files/{path.lstrip('/')}")


# ═══════════════════════════════════════════
# Git (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="Get git status inside a container (branch, modified/staged/untracked files)")
def git_status(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/git/status", params={"path": path})


@server.tool(description="Git commit all changes inside a container")
def git_commit(container_id: str, message: str, path: str = "/home/agent") -> dict:
    return _post(f"/containers/{container_id}/git/commit", body={"message": message, "path": path})


@server.tool(description="Get git log from inside a container")
def git_log(container_id: str, path: str = "/home/agent", limit: int = 20) -> dict:
    return _get(f"/containers/{container_id}/git/log", params={"path": path, "limit": limit})


@server.tool(description="Git push from inside a container")
def git_push(container_id: str, path: str = "/home/agent") -> dict:
    return _post(f"/containers/{container_id}/git/push", body={"path": path})


@server.tool(description="Git pull inside a container")
def git_pull(container_id: str, path: str = "/home/agent") -> dict:
    return _post(f"/containers/{container_id}/git/pull", body={"path": path})


@server.tool(description="List git branches inside a container")
def git_branches(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/git/branches", params={"path": path})


@server.tool(description="Show uncommitted git diff inside a container")
def git_diff(container_id: str, path: str = "/home/agent") -> dict:
    return _get(f"/containers/{container_id}/git/diff", params={"path": path})


# ═══════════════════════════════════════════
# Provisioning
# ═══════════════════════════════════════════

@server.tool(description="List available provisioning templates (hermes, openclaw, etc)")
def templates_list() -> list:
    return _get("/templates")


@server.tool(description="Start provisioning a new agent container from a template")
def provision_start(
    template: str,
    tenant_id: str,
    agent_name: str,
    agent_role: str,
    unit_id: str | None = None,
    model: str | None = None,
    memory: str | None = None,
    cpu: str | None = None,
    disk: str | None = None,
    test: bool = False,
) -> dict:
    body = {
        "template": template,
        "tenant_id": tenant_id,
        "agent_name": agent_name,
        "agent_role": agent_role,
    }
    if unit_id:
        body["unit_id"] = unit_id
    if model:
        body["model"] = model
    if memory:
        body["memory"] = memory
    if cpu:
        body["cpu"] = cpu
    if disk:
        body["disk"] = disk
    if test:
        body["test"] = True
    return _post("/provision", body=body)


@server.tool(description="Get the status of a provisioning job (steps, progress, errors)")
def provision_status(job_id: str) -> dict:
    return _get(f"/provision/{job_id}")


@server.tool(description="List recent provisioning jobs")
def provision_jobs(limit: int = 50) -> list:
    return _get("/provision", params={"limit": limit})


@server.tool(description="Cancel a running provisioning job")
def provision_cancel(job_id: str) -> dict:
    return _post(f"/provision/{job_id}/cancel")


@server.tool(description="Retry a failed provisioning job")
def provision_retry(job_id: str) -> dict:
    return _post(f"/provision/{job_id}/retry")


# ═══════════════════════════════════════════
# Tenants
# ═══════════════════════════════════════════

@server.tool(description="List all tenants")
def tenants_list() -> list:
    return _get("/tenants")


@server.tool(description="Get tenant detail with containers and units")
def tenant_detail(tenant_id: str) -> dict:
    return _get(f"/tenants/{tenant_id}")


@server.tool(description="Create a new tenant")
def tenant_create(tenant_id: str, name: str, contact: str | None = None, notes: str | None = None) -> dict:
    body = {"id": tenant_id, "name": name}
    if contact:
        body["contact"] = contact
    if notes:
        body["notes"] = notes
    return _post("/tenants", body=body)


@server.tool(description="List business units for a tenant")
def tenant_units(tenant_id: str) -> list:
    return _get(f"/tenants/{tenant_id}/units")


# ═══════════════════════════════════════════
# Metrics
# ═══════════════════════════════════════════

@server.tool(description="Get token usage summary — total tokens, cost, message count")
def metrics_tokens(container_id: str | None = None, hours: int = 24) -> dict:
    params = {"hours": hours}
    if container_id:
        params["container_id"] = container_id
    return _get("/metrics/tokens", params=params)


@server.tool(description="Get token usage broken down by container")
def metrics_tokens_by_container(hours: int = 24) -> list:
    return _get("/metrics/tokens/by-container", params={"hours": hours})


@server.tool(description="Get average fleet CPU and memory utilization")
def metrics_fleet_utilization() -> dict:
    return _get("/metrics/fleet-utilization")


@server.tool(description="Get agent/container restart count from audit log")
def metrics_restarts(container_id: str | None = None, hours: int = 24) -> dict:
    params = {"hours": hours}
    if container_id:
        params["container_id"] = container_id
    return _get("/metrics/restarts", params=params)


# ═══════════════════════════════════════════
# System (inside containers)
# ═══════════════════════════════════════════

@server.tool(description="List processes running inside a container (CPU, memory per process)")
def system_processes(container_id: str, limit: int = 25) -> dict:
    return _get(f"/containers/{container_id}/system/processes", params={"limit": limit})


@server.tool(description="Get environment variables from a container (sensitive values redacted)")
def system_env(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/system/env")


@server.tool(description="Check service connectivity from inside a container (inference API, 1Password, MCP, etc)")
def system_connections(container_id: str) -> dict:
    return _get(f"/containers/{container_id}/system/connections")


@server.tool(description="Get OS and system info from a container (uptime, kernel, restart count)")
def system_info(container_id: str, hours: int = 24) -> dict:
    return _get(f"/containers/{container_id}/system/info", params={"hours": hours})


# ═══════════════════════════════════════════
# Sessions
# ═══════════════════════════════════════════

@server.tool(description="List active WebSocket terminal sessions")
def sessions_list() -> list:
    return _get("/sessions")


@server.tool(description="Kill an active terminal session")
def session_kill(session_id: str) -> dict:
    return _delete(f"/sessions/{session_id}")


# ═══════════════════════════════════════════
# Terminal / Chat Agent
# ═══════════════════════════════════════════

@server.tool(description="Send a message to the fleet management agent and get a response. The agent can execute fleet operations autonomously.")
def chat(message: str, session_id: str | None = None, context: str | None = None) -> dict:
    body = {"content": message}
    if session_id:
        body["session_id"] = session_id
    if context:
        body["context"] = context
    return _post("/terminal/message", body=body)


def main():
    server.run("stdio")


if __name__ == "__main__":
    main()
