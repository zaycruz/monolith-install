"""Rich REPL — prompt_toolkit backed with history, completion, and style."""

from __future__ import annotations

import shlex
import subprocess
from collections.abc import Iterable
from pathlib import Path

import click
import httpx
from prompt_toolkit import PromptSession
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import Completer, Completion
from prompt_toolkit.history import FileHistory
from prompt_toolkit.lexers import Lexer
from prompt_toolkit.styles import Style as PtStyle

from raava import display
from raava.client import APIError

BANNER = (
    "\n"
    "[bold cyan]✦[/]\n"
    "\n"
    "[bold cyan]  ██████╗  █████╗  █████╗ ██╗   ██╗ █████╗[/]   [dim]v{version}[/dim]\n"
    "[bold cyan] ██╔══██╗██╔══██╗██╔══██╗██║   ██║██╔══██╗[/]  [dim]Fleet Management CLI[/dim]\n"
    "[bold cyan] ██████╔╝███████║███████║██║   ██║███████║[/]\n"
    "[bold cyan] ██╔══██╗██╔══██║██╔══██║╚██╗ ██╔╝██╔══██║[/]\n"
    "[bold cyan] ██║  ██║██║  ██║██║  ██║ ╚████╔╝ ██║  ██║[/]\n"
    "[bold cyan] ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝[/]\n"
    "\n"
    "[dim]Type [bold]help[/bold] or a command. [bold]quit[/bold] to exit.[/dim]\n"
)

_HISTORY_DIR = Path.home() / ".config" / "raava"
_HISTORY_FILE = _HISTORY_DIR / "history"

_ALIASES: dict[str, list[str]] = {
    "c": ["containers"],
    "f": ["fleet"],
    "ls": ["containers", "list"],
    "a": ["agent"],
    "h": ["health"],
    "s": ["snapshots"],
    "p": ["provision"],
    "m": ["metrics"],
    "t": ["tenants"],
    "sys": ["system"],
    "cfg": ["config"],
    "ch": ["chat"],
    "st": ["stream"],
    "g": ["git"],
    "doc": ["doctor", "run"],
    "rec": ["reconcile", "run"],
    "svc": ["services"],
    "msg": ["messaging"],
    "rt": ["runtime"],
    "mig": ["migrations"],
    "hm": ["hermes"],
}

_CONTAINER_CACHE: list[str] = []
_CONTAINER_CACHE_STALE: bool = True

PT_STYLE = PtStyle.from_dict(
    {
        "prompt": "bold cyan",
        "completion-menu.completion": "bg:#1a1a2e #e0e0e0",
        "completion-menu.completion.current": "bg:#0f3460 bold",
        "scrollbar.background": "bg:#1a1a2e",
        "scrollbar.button": "bg:#0f3460",
        "auto-suggestion": "#555555",
    }
)

_KEYWORDS = {
    "fleet",
    "containers",
    "agent",
    "health",
    "snapshots",
    "files",
    "git",
    "provision",
    "sessions",
    "tenants",
    "metrics",
    "system",
    "stream",
    "config",
    "chat",
    "doctor",
    "reconcile",
    "runtime",
    "services",
    "messaging",
    "migrations",
    "hermes",
    "help",
    "quit",
    "exit",
}


class RaavaLexer(Lexer):
    def lex_document(self, document):
        lines = document.lines

        def get_line(lineno):
            line = lines[lineno] if lineno < len(lines) else ""
            tokens = []
            for raw in line.split(" "):
                if not raw:
                    tokens.append(("", " "))
                    continue
                if raw in _KEYWORDS or raw in _ALIASES:
                    tokens.append(("class:prompt", raw))
                elif raw.startswith("--") or (raw.startswith("-") and len(raw) == 2):
                    tokens.append(("ansiyellow", raw))
                else:
                    tokens.append(("", raw))
                tokens.append(("", " "))
            return tokens

        return get_line


def _refresh_container_cache():
    global _CONTAINER_CACHE, _CONTAINER_CACHE_STALE
    try:
        from raava import client

        data = client.get("/containers")
        containers = data.get("containers", []) if isinstance(data, dict) else []
        _CONTAINER_CACHE = [
            c.get("id", "")
            for c in containers
            if c.get("status") != "deleted" and c.get("id")
        ]
        _CONTAINER_CACHE_STALE = False
    except Exception:
        _CONTAINER_CACHE_STALE = False


class RaavaCompleter(Completer):
    """Group -> subcommand -> flags completion via Click app introspection."""

    def __init__(self, app: click.Group):
        self._tree: dict[str, dict[str, list[str]]] = {}
        self._build_tree(app)

    def _build_tree(self, app: click.Group):
        for group_name, group_cmd in app.commands.items():
            group_cmd = _unwrap_typer(group_cmd)
            if isinstance(group_cmd, click.Group):
                subcmds: dict[str, list[str]] = {}
                for sc_name, sc_cmd in group_cmd.commands.items():
                    subcmds[sc_name] = self._param_names(sc_cmd)
                self._tree[group_name] = subcmds
            elif isinstance(group_cmd, click.Command):
                self._tree[group_name] = {"": self._param_names(group_cmd)}

    @staticmethod
    def _param_names(cmd: click.Command) -> list[str]:
        names: list[str] = []
        for p in cmd.params:
            if isinstance(p, click.Option):
                names.extend(p.opts + p.secondary_opts)
        return names

    def get_completions(self, document, complete_event) -> Iterable[Completion]:
        text = document.text_before_cursor
        parts = _split_partial(text)

        at_space = text.endswith(" ")
        if not parts:
            parts_for_ctx, completing = [], ""
        elif at_space:
            parts_for_ctx, completing = parts, ""
        else:
            parts_for_ctx, completing = parts[:-1], parts[-1]

        # Expand aliases for context resolution
        if parts_for_ctx and parts_for_ctx[0] in _ALIASES:
            expanded = _ALIASES[parts_for_ctx[0]]
            parts_for_ctx = expanded + parts_for_ctx[1:]

        # Level 1: group or alias
        if len(parts_for_ctx) == 0:
            candidates = sorted(set(list(self._tree.keys()) + list(_ALIASES.keys())))
            yield from self._complete_from(completing, candidates)
            return

        group_name = parts_for_ctx[0]
        if group_name not in self._tree:
            return

        # Level 2: subcommand
        if len(parts_for_ctx) == 1:
            yield from self._complete_from(
                completing, list(self._tree[group_name].keys())
            )
            return

        # Level 3+: flags and container IDs
        subcmd_name = parts_for_ctx[1]
        flags = self._tree[group_name].get(subcmd_name, [])
        group_flags = self._tree[group_name].get("", [])
        all_flags = list(dict.fromkeys(flags + group_flags))

        if completing.startswith("-"):
            yield from self._complete_from(completing, all_flags)
        else:
            if _CONTAINER_CACHE_STALE:
                _refresh_container_cache()
            if _CONTAINER_CACHE:
                yield from self._complete_from(completing, _CONTAINER_CACHE)
            yield from self._complete_from(completing, all_flags)

    @staticmethod
    def _complete_from(prefix: str, candidates: Iterable[str]):
        for c in candidates:
            if c.startswith(prefix):
                yield Completion(c, start_position=-len(prefix))


def _unwrap_typer(cmd):
    while hasattr(cmd, "registered_group") and cmd.registered_group is not None:
        cmd = cmd.registered_group
    while hasattr(cmd, "click_command") and cmd.click_command is not None:
        cmd = cmd.click_command
    if hasattr(cmd, "registered_context"):
        ctx = cmd.registered_context
        if ctx and hasattr(ctx, "command"):
            cmd = ctx.command
    return cmd


def _split_partial(text: str) -> list[str]:
    text = text.lstrip()
    if not text:
        return []
    try:
        return shlex.split(text)
    except ValueError:
        return text.split()


def _expand_aliases(args: list[str]) -> list[str]:
    if not args or args[0] not in _ALIASES:
        return args
    return _ALIASES[args[0]] + args[1:]


def run_repl(typer_app, version: str = "0.3.0"):
    from typer.main import get_command

    click_app = get_command(typer_app)
    completer = RaavaCompleter(click_app)
    _HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    _refresh_container_cache()

    session: PromptSession = PromptSession(
        history=FileHistory(str(_HISTORY_FILE)),
        auto_suggest=AutoSuggestFromHistory(),
        completer=completer,
        lexer=RaavaLexer(),
        style=PT_STYLE,
        complete_while_typing=True,
        enable_open_in_editor=True,
        multiline=False,
        prompt_continuation="... ",
    )

    display.console.print(BANNER.format(version=version))
    display.console.print()

    from raava.main import _run_app  # late import to avoid circular dependency

    while True:
        try:
            raw = session.prompt([("class:prompt", "raava> ")])
        except KeyboardInterrupt:
            continue
        except EOFError:
            display.console.print("[dim]Goodbye[/dim]")
            break

        line = (raw or "").strip()
        if not line:
            continue
        if line in {"exit", "quit"}:
            display.console.print("[dim]Goodbye[/dim]")
            break

        # Shell escape: !<cmd> runs in subprocess
        if line.startswith("!"):
            shell_cmd = line[1:].strip()
            if shell_cmd:
                try:
                    subprocess.run(shell_cmd, shell=True)
                except Exception as e:
                    display.print_error(str(e))
            continue

        # Invalidate container cache on mutations
        if line == "help":
            line = "--help"

        try:
            args = shlex.split(line)
        except ValueError as e:
            display.print_error(f"Malformed input: {e}")
            continue

        if args and args[0] == "help":
            if len(args) == 1:
                args = ["--help"]
            else:
                args = args[1:] + ["--help"]

        args = _expand_aliases(args)

        mutation_words = {"start", "stop", "restart", "delete", "provision", "create"}
        global _CONTAINER_CACHE_STALE
        if args and (
            args[0] in mutation_words or (len(args) > 1 and args[1] in mutation_words)
        ):
            _CONTAINER_CACHE_STALE = True

        # Save the original JSON mode to restore after command execution
        original_json_mode = display._json_mode
        try:
            _run_app(args)
        except SystemExit:
            pass
        except APIError as e:
            display.print_error(f"API error (HTTP {e.status}): {e.detail}")
        except httpx.ConnectError:
            display.print_error(
                "Cannot connect to the Raava API. Is the server running?"
            )
        except httpx.TimeoutException:
            display.print_error(
                "Request timed out. Try increasing --timeout or check server status."
            )
        except httpx.HTTPError as e:
            display.print_error(f"HTTP error: {e}")
        except click.ClickException as e:
            e.show()
        except click.Abort:
            display.print_warning("Command aborted")
        finally:
            # Restore the original JSON mode to prevent leakage between commands
            display._json_mode = original_json_mode
