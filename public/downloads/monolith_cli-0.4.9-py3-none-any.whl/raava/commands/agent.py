"""Agent process commands (inside a container)."""

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


@app.command()
def status(container_id: str = typer.Argument(..., help="Container ID")):
    """Get agent status inside a container."""
    data = client.get(f"/containers/{container_id}/agent")
    display.detail({
        "status": data.get("status"),
        "stack": data.get("stack", "—"),
        "pid": data.get("pid", "—"),
        "uptime": data.get("uptime", "—"),
        "command": data.get("command", "—"),
    }, title=f"Agent: {container_id}")


@app.command()
def logs(
    container_id: str = typer.Argument(..., help="Container ID"),
    lines: int = typer.Option(100, "--lines", "-n", help="Number of log lines"),
    since: str = typer.Option(None, "--since", "-s", help="Time filter, e.g. 1h, 30m"),
):
    """Get agent logs."""
    params = {"lines": lines}
    if since:
        params["since"] = since
    data = client.get(f"/containers/{container_id}/agent/logs", params=params)
    if display.is_json_mode():
        display.print_json(data)
        return
    display.console.print(f"[dim]Source: {data.get('source', 'unknown')}[/dim]")
    for line in data.get("lines", []):
        display.console.print(line)


@app.command()
def start(container_id: str = typer.Argument(..., help="Container ID")):
    """Start the agent service."""
    client.post(f"/containers/{container_id}/agent/start")
    display.print_success(f"Agent started in {container_id}")


@app.command()
def stop(container_id: str = typer.Argument(..., help="Container ID")):
    """Stop the agent service."""
    client.post(f"/containers/{container_id}/agent/stop")
    display.print_success(f"Agent stopped in {container_id}")


@app.command()
def restart(container_id: str = typer.Argument(..., help="Container ID")):
    """Restart the agent service."""
    client.post(f"/containers/{container_id}/agent/restart")
    display.print_success(f"Agent restarted in {container_id}")


@app.command()
def stdout(
    container_id: str = typer.Argument(..., help="Container ID"),
    lines: int = typer.Option(50, "--lines", "-n", help="Initial lines to fetch"),
):
    """Live-tail agent stdout via SSE."""
    display.console.print(f"[dim]Streaming agent stdout for {container_id}... (Ctrl+C to stop)[/dim]")
    try:
        for event in client.stream_sse(f"/containers/{container_id}/agent/stdout", params={"lines": lines}):
            if event.get("type") == "log":
                display.console.print(event.get("text", ""))
            elif event.get("type") == "heartbeat":
                pass
    except KeyboardInterrupt:
        display.console.print("\n[dim]Stream closed[/dim]")
