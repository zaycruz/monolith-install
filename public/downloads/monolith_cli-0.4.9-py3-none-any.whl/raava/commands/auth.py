"""CLI authentication — exchange a portal JWT for a tenant API key."""

from __future__ import annotations

import os

import httpx
import typer

from raava import client, config, display

app = typer.Typer(no_args_is_help=True)

_DEFAULT_PORTAL_URL = "https://app.thisismonolith.com"
_EXCHANGE_TIMEOUT = 10.0
_PROBE_TIMEOUT = 10.0


def _mask(api_key: str) -> str:
    tail = api_key[-4:] if len(api_key) >= 4 else api_key
    return f"****{tail}"


def _resolve_portal_url(override: str | None) -> str:
    if override:
        return override.rstrip("/")
    env = os.environ.get("MONOLITH_PORTAL_URL")
    if env:
        return env.rstrip("/")
    return _DEFAULT_PORTAL_URL


@app.command()
def login(
    token: str = typer.Option(..., "--token", help="Short-lived portal JWT"),
    portal_url: str | None = typer.Option(
        None,
        "--portal-url",
        help="Portal base URL (default https://app.thisismonolith.com)",
    ),
):
    """Exchange a portal token for a tenant API key."""
    base = _resolve_portal_url(portal_url)
    url = f"{base}/api/auth/cli-exchange"

    try:
        resp = httpx.get(url, params={"token": token}, timeout=_EXCHANGE_TIMEOUT)
    except httpx.TimeoutException:
        display.print_error(f"Timed out contacting {base}")
        raise typer.Exit(1) from None
    except httpx.HTTPError as e:
        display.print_error(f"Cannot reach {base}: {e}")
        raise typer.Exit(1) from None

    if resp.status_code in (400, 401):
        display.print_error(
            f"Token expired or invalid — generate a fresh one at {base}/setup"
        )
        raise typer.Exit(1)
    if resp.status_code == 404:
        display.print_error("Tenant mismatch — regenerate the token")
        raise typer.Exit(1)
    if resp.status_code >= 400:
        display.print_error(f"Portal error (HTTP {resp.status_code}): {resp.text}")
        raise typer.Exit(1)

    try:
        data = resp.json()
    except ValueError:
        display.print_error("Portal returned a non-JSON response")
        raise typer.Exit(1) from None

    try:
        api_key = data["apiKey"]
        fleet_api_url = data["fleetApiUrl"]
        tenant_id = data["tenantId"]
    except (KeyError, TypeError):
        display.print_error("Portal response is missing required fields")
        raise typer.Exit(1) from None

    config.set_value("api_key", api_key)
    config.set_value("api_url", fleet_api_url)

    display.console.print(f"| Logged in as tenant {tenant_id}")
    display.console.print(f"| Key: {_mask(api_key)}")
    display.console.print(f"| Fleet API: {fleet_api_url}")


@app.command()
def logout():
    """Remove stored API credentials."""
    config.delete_key("api_key")
    config.delete_key("api_url")
    display.console.print("| Logged out")


def _status_impl():
    api_key = config.get("api_key", "") or ""
    api_url = config.get("api_url", "") or ""
    portal_base = _resolve_portal_url(None)

    if not api_key or not api_url:
        display.console.print(
            f"| Not logged in. Run 'monolith auth login --token <JWT>' "
            f"(get a token at {portal_base}/setup)."
        )
        raise typer.Exit(0)

    try:
        with client._client() as c:
            resp = c.get("/api/fleet/stats", timeout=_PROBE_TIMEOUT)
    except httpx.TimeoutException:
        display.print_error(f"Cannot reach {api_url} (timed out)")
        raise typer.Exit(1) from None
    except httpx.HTTPError:
        display.print_error(f"Cannot reach {api_url}")
        raise typer.Exit(1) from None

    if resp.status_code in (401, 403):
        display.print_error(
            "Stored key is rejected by the API — run 'monolith auth login' again"
        )
        raise typer.Exit(1)
    if resp.status_code >= 400:
        display.print_error(f"API probe failed (HTTP {resp.status_code})")
        raise typer.Exit(1)

    display.console.print("| status: authenticated")
    display.console.print(f"| api_url: {api_url}")
    display.console.print(f"| api_key: {_mask(api_key)}")


@app.command()
def status():
    """Probe the Fleet API with the stored credentials."""
    _status_impl()


@app.command()
def whoami():
    """Alias for 'status'."""
    _status_impl()
