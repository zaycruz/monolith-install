"""Fleet-wide commands."""

import time

import typer
from rich.console import Group
from rich.panel import Panel
from rich.table import Table

from raava import client, display

app = typer.Typer(no_args_is_help=True)


def _fleet_health_rows() -> list[dict]:
    data = client.get("/fleet/health")
    rows = data.get("containers", [])
    for r in rows:
        h = r.get("health") or {}
        r["_cpu"] = display.percent_bar(h.get("cpu", 0), color="cyan")
        r["_mem"] = display.percent_bar(h.get("mem", 0), color="green")
        r["_disk"] = display.percent_bar(h.get("disk", 0), color="magenta")
        r["_agent_status"] = h.get("agent_status", "unknown") if h else "unknown"
        r["_updated"] = h.get("recorded_at", "") if h else ""
    return rows


def _render_fleet_health(rows: list[dict], title: str = "Fleet Health") -> None:
    if display.is_json_mode():
        display.print_json(rows)
        return

    if not rows:
        display.console.print("[dim]No fleet health data available[/dim]")
        return

    t = Table(
        title=title,
        show_lines=False,
        pad_edge=True,
        padding=(0, 1),
        row_styles=["none", "dim"],
    )
    t.add_column("ID", style="bold")
    t.add_column("Tenant")
    t.add_column("Agent")
    t.add_column("Status")
    t.add_column("IP")
    t.add_column("CPU")
    t.add_column("Mem")
    t.add_column("Disk")
    t.add_column("Agent Status")
    t.add_column("Updated")

    for r in rows:
        t.add_row(
            str(r.get("id", "")),
            str(r.get("tenant", "")),
            str(r.get("agent_name", "")),
            display.status_style(str(r.get("status", "unknown"))),
            str(r.get("ip", "")),
            r.get("_cpu"),
            r.get("_mem"),
            r.get("_disk"),
            display.status_style(str(r.get("_agent_status", "unknown"))),
            str(r.get("_updated", "")),
        )

    display.console.print(t)


def _to_float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


@app.command()
def health(
    watch: bool = typer.Option(False, "--watch", "-w", help="Auto-refresh output"),
    interval: int = typer.Option(
        5, "--interval", "-i", min=1, help="Refresh interval in seconds"
    ),
):
    """Fleet-wide health overview."""
    if display.is_json_mode() or not watch:
        rows = _fleet_health_rows()
        _render_fleet_health(rows)
        return

    try:
        while True:
            rows = _fleet_health_rows()
            display.console.clear()
            _render_fleet_health(rows, title=f"Fleet Health (refresh {interval}s)")
            time.sleep(interval)
    except KeyboardInterrupt:
        display.console.print("\n[dim]Watch stopped[/dim]")


@app.command()
def alerts():
    """Current threshold alerts."""
    data = client.get("/fleet/alerts")
    if not data:
        display.print_success("No active alerts")
        return
    cols = [
        ("Container", "container_id"),
        ("Level", "level"),
        ("Type", "type"),
        ("Value", "value"),
        ("Threshold", "threshold"),
        ("Message", "message"),
    ]
    display.table(data, cols, title="Active Alerts", row_styles=["none", "dim"])


@app.command()
def stats():
    """Show fleet aggregate stats."""
    data = client.get("/fleet/stats")
    if display.is_json_mode():
        display.print_json(data)
        return

    cpu = _to_float(data.get("cpu", data.get("cpu_avg", data.get("avg_cpu", 0))))
    mem = _to_float(data.get("mem", data.get("mem_avg", data.get("avg_mem", 0))))

    metrics = Table.grid(padding=(0, 2))
    metrics.add_column(style="bold cyan", justify="right")
    metrics.add_column(style="white")

    preferred_order = [
        "total_containers",
        "running_containers",
        "stopped_containers",
        "active_agents",
        "idle_agents",
        "total_alerts",
    ]
    used = set()
    for key in preferred_order:
        if key in data:
            metrics.add_row(key.replace("_", " "), str(data.get(key)))
            used.add(key)

    for key, value in data.items():
        if key in used or key in {
            "cpu",
            "cpu_avg",
            "avg_cpu",
            "mem",
            "mem_avg",
            "avg_mem",
            "backup",
        }:
            continue
        metrics.add_row(key.replace("_", " "), str(value))

    backup = data.get("backup") or {}
    if backup:
        metrics.add_row("backup used %", str(backup.get("used_percent")))
        metrics.add_row("backup latest run", str(backup.get("latest_run_id")))
        metrics.add_row(
            "backup replication",
            f"ok={backup.get('latest_run_replication_ok', 0)} failed={backup.get('latest_run_replication_failed', 0)}",
        )

    util = Table.grid(padding=(0, 1))
    util.add_column(style="bold")
    util.add_column()
    util.add_row("CPU Utilization", display.percent_bar(cpu, width=24, color="cyan"))
    util.add_row(
        "Memory Utilization", display.percent_bar(mem, width=24, color="green")
    )

    body = Group(metrics, "", util)
    display.console.print(
        Panel(body, title="Fleet Stats", border_style="blue", expand=False)
    )


@app.command()
def top(
    limit: int = typer.Option(
        10, "--limit", "-n", min=1, help="Number of containers to show"
    ),
    sort: str = typer.Option("cpu", "--sort", "-s", help="Sort key: cpu|mem|disk"),
):
    """Show top N containers by utilization."""
    sort_key = sort.lower()
    if sort_key not in {"cpu", "mem", "disk"}:
        display.print_error("--sort must be one of: cpu, mem, disk")
        raise typer.Exit(1)

    rows = _fleet_health_rows()

    for r in rows:
        h = r.get("health") or {}
        r["_sort_value"] = _to_float(h.get(sort_key, 0))

    ranked = sorted(rows, key=lambda r: r.get("_sort_value", 0), reverse=True)[:limit]

    if display.is_json_mode():
        display.print_json(ranked)
        return

    table = Table(
        title=f"Fleet Top {limit} by {sort_key.upper()}",
        show_lines=False,
        pad_edge=True,
        padding=(0, 1),
        row_styles=["none", "dim"],
    )
    table.add_column("#", justify="right", style="bold")
    table.add_column("ID", style="bold")
    table.add_column("Tenant")
    table.add_column("Agent")
    table.add_column("Status")
    table.add_column("CPU")
    table.add_column("Mem")
    table.add_column("Disk")

    for i, r in enumerate(ranked, start=1):
        h = r.get("health") or {}
        table.add_row(
            str(i),
            str(r.get("id", "")),
            str(r.get("tenant", "")),
            str(r.get("agent_name", "")),
            display.status_style(str(r.get("status", "unknown"))),
            display.percent_bar(h.get("cpu", 0), color="cyan"),
            display.percent_bar(h.get("mem", 0), color="green"),
            display.percent_bar(h.get("disk", 0), color="magenta"),
        )

    display.console.print(table)


@app.command()
def audit(
    hours: int = typer.Option(1, "--hours", "-H", help="Hours to look back"),
    limit: int = typer.Option(50, "--limit", "-n", help="Max entries"),
):
    """Cross-tenant audit feed."""
    data = client.get("/fleet/audit", params={"hours": hours, "limit": limit})
    cols = [
        ("Time", "performed_at"),
        ("Container", "container_id"),
        ("Tenant", "tenant"),
        ("Agent", "agent_name"),
        ("Action", "action"),
        ("Detail", "detail"),
    ]
    display.table(
        data, cols, title=f"Audit Feed (last {hours}h)", row_styles=["none", "dim"]
    )


@app.command()
def agents(
    status: str | None = typer.Option(
        None, "--status", "-s", help="Filter: active, idle, stopped, error"
    ),
    tenant: str | None = typer.Option(None, "--tenant", "-t"),
    unit: str | None = typer.Option(None, "--unit", "-u"),
):
    """Filter agents across fleet."""
    params = {}
    if status:
        params["status"] = status
    if tenant:
        params["tenant"] = tenant
    if unit:
        params["unit"] = unit
    data = client.get("/fleet/agents", params=params)
    rows = data.get("containers", [])
    cols = [
        ("ID", "id"),
        ("Tenant", "tenant"),
        ("Unit", "unit"),
        ("Agent", "agent_name"),
        ("Role", "agent_role"),
        ("Model", "model"),
        ("Status", "status"),
        ("CPU%", "_cpu"),
        ("Mem%", "_mem"),
    ]
    for r in rows:
        display.enrich_health(r)
    display.table(rows, cols, title="Fleet Agents", row_styles=["none", "dim"])
