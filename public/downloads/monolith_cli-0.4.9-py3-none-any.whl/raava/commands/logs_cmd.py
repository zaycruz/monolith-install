"""Logs command — fetch agent logs by name."""

from __future__ import annotations

import typer

from raava import client, display
from raava.client import APIError

app = typer.Typer(no_args_is_help=True)


def _resolve_agent_to_container(agent_name: str) -> str:
    """Resolve an agent name to a container ID via GET /containers."""
    data = client.get("/containers")
    containers = data.get("containers", []) if isinstance(data, dict) else []
    live = [c for c in containers if c.get("status") != "deleted"]

    matches = [c for c in live if c.get("agent_name") == agent_name]

    if not matches:
        lower = agent_name.lower()
        matches = [c for c in live if lower in str(c.get("agent_name") or "").lower()]

    if not matches:
        raise APIError(404, f"No agent named '{agent_name}' found")

    if len(matches) == 1:
        return str(matches[0]["id"])

    running = [c for c in matches if c.get("status") == "running"]
    if running:
        return str(running[0]["id"])

    names = ", ".join(
        f"{c.get('agent_name')} ({c.get('id')})" for c in matches[:8]
    )
    display.print_warning(f"Multiple matches: {names}")
    display.print_warning(f"Using {matches[0].get('id')}")
    return str(matches[0]["id"])


@app.command()
def logs(
    agent: str = typer.Option(..., "--agent", help="Agent name"),
    tail: int = typer.Option(100, "--tail", "-n", help="Number of log lines to fetch"),
    since: str = typer.Option(None, "--since", "-s", help="Time filter, e.g. 1h, 30m"),
):
    """Fetch log output for a named agent."""
    container_id = _resolve_agent_to_container(agent)

    params: dict = {"lines": tail}
    if since:
        params["since"] = since

    data = client.get(f"/containers/{container_id}/agent/logs", params=params)
    if display.is_json_mode():
        display.print_json(data)
        return
    for line in data.get("lines", []):
        display.console.print(line)
