import time

import typer
import yaml

from raava import client, display

app = typer.Typer(no_args_is_help=True)

@app.command("show")
def show_manifest(container_id: str = typer.Argument(..., help="Container ID")):
    """Show the stored manifest for an agent."""
    data = client.get(f"/manifests/{container_id}")
    display.detail(data, title=f"Manifest: {container_id}")

@app.command("validate")
def validate_manifest(
    file: str = typer.Argument(..., help="Path to manifest YAML file"),
):
    """Validate a manifest file without provisioning."""
    with open(file) as f:
        manifest = yaml.safe_load(f)
    data = client.post("/manifests/validate", json=manifest)
    # Display validation results
    display.detail(data, title=f"Validation: {file}")
    if not data.get("valid"):
        raise typer.Exit(1)

@app.command("apply")
def apply_manifest(
    file: str = typer.Argument(..., help="Path to manifest YAML file"),
    provision: bool = typer.Option(False, "--provision", "-p", help="Provision the agent"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for provision to complete"),
):
    """Store a manifest and optionally provision the agent."""
    with open(file) as f:
        manifest = yaml.safe_load(f)

    validation = client.post("/manifests/validate", json=manifest)
    if not validation.get("valid"):
        display.print_error("Manifest validation failed:")
        for check in validation.get("checks", []):
            if check.get("status") == "fail":
                display.print_error(f"  - [{check.get('name')}] {check.get('detail', '')}")
        for err in validation.get("errors", []):
            display.print_error(f"  - {err}")
        raise typer.Exit(1)

    manifest = validation.get("manifest", manifest)

    data = client.post("/manifests", json=manifest)
    display.detail(data, title="Manifest Applied")

    if not provision:
        return

    body = {
        "template": manifest.get("template", "hermes"),
        "tenant_id": manifest["tenant_id"],
        "agent_name": manifest["agent_name"],
        "agent_role": manifest["agent_role"],
    }

    if manifest.get("unit_id"):
        body["unit_id"] = manifest["unit_id"]
    if manifest.get("model"):
        body["model"] = manifest["model"]
    if manifest.get("system_prompt"):
        body["system_prompt"] = manifest["system_prompt"]
    if manifest.get("memory"):
        body["memory"] = manifest["memory"]
    if manifest.get("cpu"):
        body["cpu"] = manifest["cpu"]
    if manifest.get("disk"):
        body["disk"] = manifest["disk"]
    if manifest.get("provider"):
        body["provider"] = manifest["provider"]
    if manifest.get("zone"):
        body["zone"] = manifest["zone"]
    if manifest.get("integrations"):
        raw = manifest["integrations"]
        if isinstance(raw, list):
            body["integrations"] = {name: {} for name in raw}
        else:
            body["integrations"] = raw
    if manifest.get("discord_channel"):
        body["discord_channel"] = manifest["discord_channel"]

    if manifest.get("timezone"):
        body["timezone"] = manifest["timezone"]
    if manifest.get("personality"):
        body["personality"] = manifest["personality"]
    if manifest.get("model_provider"):
        body["model_provider"] = manifest["model_provider"]

    extra = {}
    if manifest.get("secrets_mode"):
        extra["secrets_mode"] = manifest["secrets_mode"]
    if manifest.get("hermes_ref"):
        extra["hermes_ref"] = manifest["hermes_ref"]
    if manifest.get("extra"):
        extra.update(manifest["extra"])
    if extra:
        body["extra_fields"] = extra

    prov_data = client.post("/provision", json=body)
    job_id = prov_data.get("job_id")
    if not job_id:
        display.print_error(f"Provisioning request failed: no job_id in response: {prov_data}")
        raise typer.Exit(1)
    display.print_success(f"Provisioning started: {job_id}")

    if wait and job_id:
        with display.console.status("Provisioning..."):
            while True:
                job = client.get(f"/provision/{job_id}")
                s = job.get("status", "")
                if s in ("complete", "failed", "cancelled", "interrupted"):
                    break
                time.sleep(3)
        if job.get("status") == "complete":
            display.print_success(
                f"Provisioning complete: {job.get('container_name', '')}"
            )
        else:
            display.print_error(
                f"Provisioning {job.get('status')}: {job.get('error', '')}"
            )
            raise typer.Exit(1)
