"""Fleet status command — concise agent overview with optional watch mode."""

from __future__ import annotations

import time

import typer

from raava import client, display

app = typer.Typer(no_args_is_help=True)


def _fmt_uptime(seconds: int | float | None) -> str:
    if seconds is None:
        return "—"
    try:
        s = int(float(seconds))
    except (TypeError, ValueError):
        return str(seconds)
    h, rem = divmod(s, 3600)
    m = rem // 60
    if h:
        return f"{h}h {m}m"
    return f"{m}m"


def _render(rows: list[dict]) -> None:
    if display.is_json_mode():
        display.print_json(rows)
        return

    cols = [
        ("Name", "agent_name"),
        ("Status", "status"),
        ("IP", "ip"),
        ("Uptime", "_uptime"),
    ]
    for r in rows:
        r["agent_name"] = str(r.get("agent_name") or r.get("id") or "")
        r["status"] = str(r.get("status") or "unknown")
        r["ip"] = str(r.get("ip") or "—")
        health = r.get("health") or {}
        r["_uptime"] = _fmt_uptime(health.get("uptime_seconds") or health.get("uptime"))
    display.table(rows, cols, title="Fleet Status")


def _fetch_rows() -> list[dict]:
    data = client.get("/fleet/health")
    return data.get("containers", [])


@app.command()
def status(
    watch: bool = typer.Option(False, "--watch", "-w", help="Re-fetch every 5s until Ctrl+C"),
):
    """Show concise fleet-wide agent status."""
    if not watch:
        rows = _fetch_rows()
        _render(rows)
        return

    try:
        while True:
            rows = _fetch_rows()
            display.console.clear()
            _render(rows)
            time.sleep(5)
    except KeyboardInterrupt:
        pass
