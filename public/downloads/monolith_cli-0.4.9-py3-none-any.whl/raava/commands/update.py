"""Update the Monolith CLI via the hosted install script."""

from __future__ import annotations

import os
import shutil
import subprocess
from urllib.parse import urlparse

import typer

from raava import display

_DEFAULT_INSTALL_URL = "https://app.thisismonolith.com/install.sh"

# Characters that have no business in an install URL. Even though we run
# curl via an argument list (no shell), we reject these defensively so a
# mistake downstream (e.g. someone interpolating the value into a shell
# command) cannot escalate into injection.
_URL_FORBIDDEN_CHARS = ("`", "$", ";", "&", "|", ">", "<", "\n", "\r", '"', "'", "\\")

# Hosts for which plain http is permitted (local dev/testing only).
_LOCALHOST_HOSTS = {"localhost", "127.0.0.1", "::1"}


def _validate_install_url(url: str) -> str | None:
    """Return an error message if `url` is unsafe, else None."""
    try:
        parsed = urlparse(url)
    except ValueError as e:
        return f"not a valid URL ({e})"

    if parsed.scheme == "https":
        pass
    elif parsed.scheme == "http" and parsed.hostname in _LOCALHOST_HOSTS:
        pass
    else:
        if parsed.scheme == "http":
            return (
                "plain http is only allowed for localhost "
                f"(got host {parsed.hostname!r})"
            )
        return f"unsupported scheme {parsed.scheme!r} (must be https)"
    if not parsed.netloc:
        return "missing host"

    for ch in _URL_FORBIDDEN_CHARS:
        if ch in url:
            display_ch = repr(ch)
            return f"contains forbidden character {display_ch}"

    return None


def update():
    """Re-run the hosted install script to upgrade in place."""
    from raava.main import __version__

    display.console.print(f"| Current version: {__version__}")

    curl_path = shutil.which("curl")
    if curl_path is None:
        display.print_error("curl is required to run the installer")
        raise typer.Exit(1)
    sh_path = shutil.which("sh")
    if sh_path is None:
        display.print_error("sh is required to run the installer")
        raise typer.Exit(1)

    install_url = os.environ.get("MONOLITH_INSTALL_URL", _DEFAULT_INSTALL_URL)

    err = _validate_install_url(install_url)
    if err is not None:
        display.print_error(f"Invalid MONOLITH_INSTALL_URL: {err}")
        raise typer.Exit(1)

    # Display only — not passed through any shell.
    display.console.print(f"| Running: curl -fsSL {install_url} | sh")

    # Run curl and pipe its stdout into sh via Python, not the shell.
    # `install_url` is always an argv element, never part of a shell-parsed
    # string, so a hostile value cannot escape into shell syntax.
    curl_proc = subprocess.Popen(
        [curl_path, "-fsSL", install_url],
        stdout=subprocess.PIPE,
    )
    try:
        sh_proc = subprocess.Popen(
            [sh_path],
            stdin=curl_proc.stdout,
        )
    except Exception:
        curl_proc.kill()
        curl_proc.wait()
        raise

    # Allow curl to receive SIGPIPE if sh exits early.
    if curl_proc.stdout is not None:
        curl_proc.stdout.close()

    sh_rc = sh_proc.wait()
    curl_rc = curl_proc.wait()
    rc = curl_rc if curl_rc != 0 else sh_rc
    if rc != 0:
        raise typer.Exit(rc or 1)
