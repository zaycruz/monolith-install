"""Three-phase interactive wizard for provisioning and configuring a new agent.

Usage:
    monolith agent create --wizard
"""

from __future__ import annotations

import getpass
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional

import typer
from rich.panel import Panel
from rich.table import Table

from raava import client, display
from raava.client import APIError

app = typer.Typer(no_args_is_help=True)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Real provider list from config.yaml.j2 / Isaac's endpoint spec.
KNOWN_PROVIDERS = ["openrouter", "moonshot", "minimax", "anthropic", "openai"]

# base_url per provider (mirrors config.yaml.j2 logic)
PROVIDER_BASE_URLS: dict[str, str] = {
    "openrouter": "https://openrouter.ai/api/v1",
    "moonshot": "https://api.moonshot.ai/v1",
    "minimax": "https://api.minimax.io/anthropic",
}

# Good defaults per provider; models are free-form strings.
DEFAULT_MODELS: dict[str, str] = {
    "openrouter": "google/gemini-2.5-pro-exp-03-25",
    "anthropic": "claude-sonnet-4-6",
    "openai": "gpt-4o",
    "moonshot": "moonshot-v1-8k",
    "minimax": "abab6.5s-chat",
}

KNOWN_TEMPLATES = ["hermes"]

DRAFTS_DIR = Path.home() / ".config" / "monolith" / "wizard-drafts"

# Resource presets: (label, cpu, ram_mb, disk_gb)
RESOURCE_PRESETS = [
    ("Small  — 1 CPU, 2 GB RAM, 20 GB disk", 1, 2048, 20),
    ("Medium — 2 CPU, 4 GB RAM, 40 GB disk", 2, 4096, 40),
    ("Large  — 4 CPU, 8 GB RAM, 80 GB disk", 4, 8192, 80),
    ("Custom — enter values manually", None, None, None),
]


# ---------------------------------------------------------------------------
# op:// reference validation
# ---------------------------------------------------------------------------


def validate_op_ref(ref: str) -> tuple[bool, str]:
    """Validate an op:// vault reference. Returns (is_valid, error_message)."""
    if not ref.startswith("op://"):
        return False, "Must start with op://"
    # Reject newlines
    if "\n" in ref or "\r" in ref:
        return False, "Invalid op:// reference format"
    # Reject shell metacharacters
    if any(c in ref for c in ('$', '`', '|', ';', '&', '>', '<', '!')):
        return False, "Invalid op:// reference format"
    # Reject path traversal
    if "../" in ref or "/.." in ref:
        return False, "Invalid op:// reference format"
    # Basic structure: op://vault/item/field
    if ref.count("/") < 3:
        return False, "Expected format: op://vault-name/item-name/field-name"
    return True, ""


# ---------------------------------------------------------------------------
# Draft persistence helpers
# ---------------------------------------------------------------------------

# Fields that must never be persisted to disk in draft files.
_DRAFT_SECRET_FIELDS = {"api_key", "telegram_token", "discord_token", "slack_token"}


def _draft_path(draft_id: str) -> Path:
    """Return the path for a wizard draft file."""
    DRAFTS_DIR.mkdir(parents=True, exist_ok=True)
    return DRAFTS_DIR / f"{draft_id}.json"


def _save_draft(draft_id: str, data: dict) -> None:
    """Persist wizard progress to disk for interrupt recovery.

    API keys are NEVER written to draft files — drafts are metadata only.
    Files are created with 0600 permissions (owner read/write only).
    """
    # Strip all secret fields before serialising
    safe_data = {k: v for k, v in data.items() if k not in _DRAFT_SECRET_FIELDS}
    path = _draft_path(draft_id)
    serialised = json.dumps(safe_data, indent=2)
    # Write with O_CREAT | O_WRONLY | O_TRUNC and mode 0600 so the file is
    # never readable by other users, even momentarily.
    fd = os.open(str(path), os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    try:
        os.write(fd, serialised.encode())
    finally:
        os.close(fd)
    # Ensure permissions are correct even if the file already existed.
    os.chmod(str(path), 0o600)


def _load_draft(draft_id: str) -> Optional[dict]:
    """Load an existing wizard draft, or None if it doesn't exist."""
    path = _draft_path(draft_id)
    if path.exists():
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            return None
    return None


def _delete_draft(draft_id: str) -> None:
    """Remove the draft file on successful completion."""
    path = _draft_path(draft_id)
    if path.exists():
        try:
            path.unlink()
        except OSError:
            pass


# Compute provider choices for Phase 1 provider selection.
# Maps display label -> internal value sent to POST /api/provision.
COMPUTE_PROVIDER_CHOICES = [
    ("Bare Metal", "lxd"),
    ("AWS", "aws"),
    ("GCP", "gcp"),
]


# ---------------------------------------------------------------------------
# Phase 1 — Provision
# ---------------------------------------------------------------------------


def _select_compute_provider() -> str:
    """Phase 1, Step 1 — select where the agent should run.

    Returns the internal provider value: 'lxd', 'aws', or 'gcp'.
    Default is 'lxd' (Bare Metal) to preserve existing behaviour.
    """
    display.console.print("\n[bold]Step 1 — Compute Provider[/bold]")
    display.console.print("Where should this agent run?")
    for i, (label, _value) in enumerate(COMPUTE_PROVIDER_CHOICES, 1):
        default_marker = " [dim](default)[/dim]" if i == 1 else ""
        display.console.print(f"  [cyan]{i}[/cyan]. {label}{default_marker}")

    while True:
        raw = typer.prompt("Select provider (number)", default="1").strip()
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(COMPUTE_PROVIDER_CHOICES):
                return COMPUTE_PROVIDER_CHOICES[idx][1]
            display.print_warning(f"Enter a number between 1 and {len(COMPUTE_PROVIDER_CHOICES)}")
        else:
            display.print_warning(f"Enter a number between 1 and {len(COMPUTE_PROVIDER_CHOICES)}")


def _phase1_collect() -> dict:
    """Interactively collect provisioning parameters."""
    display.console.print("\n[bold cyan]=== Phase 1 of 3 — Provision ===[/bold cyan]")
    display.console.print(
        "[dim]We'll create a new agent container. Press Ctrl+C at any time to abort.[/dim]\n"
    )

    # Step 1: Compute provider (where the agent runs)
    compute_provider = _select_compute_provider()

    # Template
    display.console.print("\nAvailable templates:")
    for i, t in enumerate(KNOWN_TEMPLATES, 1):
        display.console.print(f"  [cyan]{i}[/cyan]. {t}")
    while True:
        raw = typer.prompt("Template (number or name)", default="hermes").strip().lower()
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(KNOWN_TEMPLATES):
                template = KNOWN_TEMPLATES[idx]
                break
            display.print_warning(f"Enter a number between 1 and {len(KNOWN_TEMPLATES)}")
            continue
        matches = [t for t in KNOWN_TEMPLATES if t.lower().startswith(raw)]
        if len(matches) == 1:
            template = matches[0]
            break
        if len(matches) > 1:
            display.print_warning(f"Ambiguous: {', '.join(matches)}. Be more specific.")
            continue
        if raw:
            template = raw
            break
        display.print_warning("Template cannot be empty.")

    display.console.print("[dim]Your organization ID — shown in the Monolith dashboard under Settings[/dim]")
    tenant_id = typer.prompt("Tenant ID").strip()
    while not tenant_id:
        display.print_warning("Tenant ID cannot be empty.")
        tenant_id = typer.prompt("Tenant ID").strip()

    agent_name = typer.prompt("Agent name").strip()
    while not agent_name:
        display.print_warning("Agent name cannot be empty.")
        agent_name = typer.prompt("Agent name").strip()

    agent_role = typer.prompt("Agent role", default="Agent").strip()

    return {
        "compute_provider": compute_provider,
        "template": template,
        "tenant_id": tenant_id,
        "agent_name": agent_name,
        "agent_role": agent_role,
    }


def _phase1_provision(params: dict) -> str:
    """POST /api/provision and poll until complete. Returns container_id."""
    from rich.progress import Progress, SpinnerColumn, TextColumn

    display.console.print()

    # Step labels mirror the real provisioning pipeline stages.
    steps_display = [
        ("Creating container...", "Creating container"),
        ("Installing Hermes...", "Installing"),
        ("Configuring agent...", "Configuring"),
        ("Starting agent...", "Starting"),
    ]

    # Build provision payload: rename compute_provider -> provider for the API.
    provision_payload = {k: v for k, v in params.items() if k != "compute_provider"}
    provision_payload["provider"] = params.get("compute_provider", "lxd")
    data = client.post("/provision", json=provision_payload)
    job_id = data.get("job_id")
    if not job_id:
        display.print_error("API did not return a job_id. Cannot continue.")
        raise typer.Exit(1)

    display.print_success(f"Provisioning job started: {job_id}")

    job: dict = {}
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold green]{task.description}"),
        transient=True,
        console=display.console,
    ) as progress:
        task = progress.add_task("Creating container...", total=None)
        last_step = ""
        while True:
            job = client.get(f"/provision/{job_id}")
            s = job.get("status", "")

            api_steps = job.get("steps", [])
            if api_steps:
                active = next(
                    (st for st in reversed(api_steps) if st.get("status") == "running"),
                    None,
                )
                if not active:
                    active = next(
                        (st for st in reversed(api_steps) if st.get("status") == "complete"),
                        None,
                    )
                if active:
                    raw_label = active.get("name", "")
                    # Map raw API step names to human-friendly labels
                    friendly = raw_label
                    for display_label, keyword in steps_display:
                        if keyword.lower() in raw_label.lower():
                            friendly = display_label
                            break
                    if friendly != last_step:
                        progress.update(task, description=friendly)
                        last_step = friendly

            if s in ("complete", "failed", "cancelled", "interrupted"):
                break
            time.sleep(3)

    final_status = job.get("status", "")
    if final_status != "complete":
        error = job.get("error", "unknown error")
        display.print_error(f"Provisioning {final_status}: {error}")
        raise typer.Exit(1)

    container_id = job.get("container_name") or job.get("container_id", "")
    if not container_id:
        display.print_error("Provisioning complete but no container_id returned.")
        raise typer.Exit(1)

    display.console.print("  [green]✓[/green] Agent live")
    display.print_success(f"Provisioning complete — container: {container_id}")
    return container_id


# ---------------------------------------------------------------------------
# Phase 2 — Config wizard
# ---------------------------------------------------------------------------


def _phase2_provider() -> str:
    """Step 1: model provider selection."""
    display.console.print("\n[bold]Step 1 of 7 — Model Provider[/bold]")
    display.console.print("Available providers:")
    for i, p in enumerate(KNOWN_PROVIDERS, 1):
        default_marker = " [dim](default)[/dim]" if p == "openrouter" else ""
        display.console.print(f"  [cyan]{i}[/cyan]. {p}{default_marker}")

    while True:
        raw = typer.prompt(
            "Select provider (number or name)", default="openrouter"
        ).strip().lower()
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(KNOWN_PROVIDERS):
                return KNOWN_PROVIDERS[idx]
            display.print_warning(f"Enter a number between 1 and {len(KNOWN_PROVIDERS)}")
            continue
        # Case-insensitive prefix match
        matches = [p for p in KNOWN_PROVIDERS if p.lower().startswith(raw.lower())]
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            display.print_warning(f"Ambiguous: {', '.join(matches)}. Be more specific.")
            continue
        if raw:
            return raw
        display.print_warning("Provider cannot be empty.")


def _phase2_model(provider: str) -> str:
    """Step 2: model selection (free-form string; good default offered)."""
    display.console.print(f"\n[bold]Step 2 of 7 — Model ({provider})[/bold]")
    default_model = DEFAULT_MODELS.get(provider, "")
    if default_model:
        display.console.print(f"[dim]Suggested default: {default_model}[/dim]")
    display.console.print("[dim]Enter any model ID supported by this provider.[/dim]")

    while True:
        prompt_default = default_model if default_model else ...
        raw = typer.prompt("Model ID", default=prompt_default).strip()  # type: ignore[arg-type]
        if raw:
            return raw
        display.print_warning("Model ID cannot be empty.")


def _phase2_api_key(provider: str) -> str:
    """Step 3: API key (masked input). Written to env file, not config.yaml."""
    display.console.print(f"\n[bold]Step 3 of 7 — API Key ({provider})[/bold]")
    display.console.print(
        "[dim]Input is hidden — key will not echo.\n"
        "The key is stored in the container env file, not in config.yaml.[/dim]"
    )
    while True:
        try:
            key = getpass.getpass(prompt=f"  {provider} API key (or op:// reference): ").strip()
        except (EOFError, KeyboardInterrupt):
            display.print_error("Aborted.")
            raise typer.Exit(1)
        if not key:
            display.print_warning("API key cannot be empty.")
            continue
        # If the user typed an op:// reference here, validate it before accepting.
        if key.startswith("op://"):
            ok, err = validate_op_ref(key)
            if not ok:
                display.print_error(
                    "[red]❌[/red] Invalid 1Password reference format. "
                    "Expected: op://vault-name/item-name/field-name"
                )
                continue
        return key


def _phase2_op_reference(raw_key: str) -> str:
    """Step 4a: optionally replace raw key with a 1Password op:// reference."""
    if raw_key.startswith("op://"):
        # User already entered an op:// reference in the key prompt — already validated.
        return raw_key

    display.console.print(
        "\n[bold]Step 3b of 7 — 1Password Reference (optional)[/bold]"
    )
    display.console.print(
        "[dim]If this key is stored in 1Password, enter the op:// reference to avoid\n"
        "storing the raw secret. Leave blank to use the key you just entered.[/dim]"
    )
    use_op = typer.confirm("  Use a 1Password op:// reference?", default=False)
    if not use_op:
        return raw_key

    while True:
        ref = typer.prompt("  1Password reference (e.g. op://vault/item/field)").strip()
        # Client-side validation before any network call or storage
        ok, err = validate_op_ref(ref)
        if not ok:
            display.print_error(
                "[red]❌[/red] Invalid 1Password reference format. "
                "Expected: op://vault-name/item-name/field-name"
            )
            continue
        # Optionally verify with the op CLI (best-effort — does not block)
        try:
            result = subprocess.run(
                ["op", "read", ref],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode != 0:
                display.print_warning(
                    "  `op read` returned an error. "
                    "Double-check the reference, or proceed anyway if `op` is misconfigured."
                )
        except FileNotFoundError:
            display.print_warning(
                "  `op` CLI not found — cannot validate reference.\n"
                "  The reference will be stored as-is."
            )
        except subprocess.TimeoutExpired:
            display.print_warning("  `op read` timed out — skipping validation.")
        except Exception as exc:
            display.print_warning(f"  Could not validate op reference: {exc}")
        return ref


def _phase2_personality() -> str:
    """Collect optional agent personality / system prompt flavour."""
    display.console.print("\n[bold]Personality (optional)[/bold]")
    display.console.print("[dim]Short description of how this agent should behave (e.g. 'professional', 'concise').[/dim]")
    personality = typer.prompt("Personality", default="professional").strip()
    return personality or "professional"


def _phase2_timezone() -> str:
    """Collect optional timezone."""
    tz = typer.prompt("Timezone", default="America/New_York").strip()
    return tz or "America/New_York"


def _phase2_gateways(draft: dict) -> dict:
    """Step 4: Messaging gateways (Telegram, Discord, Slack).

    At least one gateway must be configured. Loops until satisfied.
    Returns a dict of gateway fields to merge into draft.
    """
    display.console.print("\n[bold]Step 4 of 7 — Messaging Gateways[/bold]")
    display.console.print(
        "[dim]At least one messaging gateway is required to communicate with your agent.[/dim]"
    )

    while True:
        gateway_fields: dict = {}

        # --- Telegram ---
        want_telegram = typer.confirm("\nConfigure Telegram gateway?", default=False)
        if want_telegram:
            while True:
                try:
                    tg_token = getpass.getpass(
                        prompt="  Telegram bot token (from @BotFather): "
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    display.print_error("Aborted.")
                    raise typer.Exit(1)
                if tg_token:
                    break
                display.print_warning("Telegram bot token cannot be empty.")
            gateway_fields["telegram_token"] = tg_token

            tg_users = typer.prompt(
                "  Allowed Telegram user IDs (comma-separated, or * for open)",
                default="*",
            ).strip()
            gateway_fields["telegram_allowed_users"] = tg_users or "*"
            display.console.print(
                "  [dim](Tip: send /id to @userinfobot in Telegram to find your user ID)[/dim]"
            )

        # --- Discord ---
        want_discord = typer.confirm("\nConfigure Discord gateway?", default=False)
        if want_discord:
            while True:
                try:
                    dc_token = getpass.getpass(
                        prompt="  Discord bot token: "
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    display.print_error("Aborted.")
                    raise typer.Exit(1)
                if dc_token:
                    break
                display.print_warning("Discord bot token cannot be empty.")
            gateway_fields["discord_token"] = dc_token

            dc_channel = typer.prompt("  Discord channel name or ID").strip()
            gateway_fields["discord_channel"] = dc_channel

            dc_mention = typer.confirm(
                "  Require @mention to respond?", default=True
            )
            gateway_fields["discord_require_mention"] = dc_mention

        # --- Slack ---
        want_slack = typer.confirm("\nConfigure Slack gateway?", default=False)
        if want_slack:
            while True:
                try:
                    sl_token = getpass.getpass(
                        prompt="  Slack bot token (xoxb-...): "
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    display.print_error("Aborted.")
                    raise typer.Exit(1)
                if sl_token:
                    break
                display.print_warning("Slack bot token cannot be empty.")
            gateway_fields["slack_token"] = sl_token

            sl_thread = typer.confirm("  Reply in thread?", default=True)
            gateway_fields["slack_reply_in_thread"] = sl_thread

        # Gateway enforcement: at least one must be configured.
        has_gateway = (
            "telegram_token" in gateway_fields
            or "discord_token" in gateway_fields
            or "slack_token" in gateway_fields
        )
        if not has_gateway:
            display.print_error(
                "At least one messaging gateway is required. "
                "Please configure Telegram, Discord, or Slack."
            )
            # Loop back to gateway prompts
            continue

        return gateway_fields


def _phase2_resources(draft: dict) -> dict:
    """Step 5: Resource allocation preset or custom."""
    display.console.print("\n[bold]Step 5 of 7 — Resource Allocation[/bold]")
    for i, (label, *_) in enumerate(RESOURCE_PRESETS, 1):
        default_marker = " [dim](default)[/dim]" if i == 2 else ""
        display.console.print(f"  [cyan]{i}[/cyan]. {label}{default_marker}")

    while True:
        raw = typer.prompt("Resource preset", default="2").strip()
        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(RESOURCE_PRESETS):
                label, cpu, ram_mb, disk_gb = RESOURCE_PRESETS[idx]
                if cpu is None:
                    # Custom
                    while True:
                        try:
                            cpu = int(typer.prompt("  CPU count").strip())
                            if cpu > 0:
                                break
                            display.print_warning("CPU count must be a positive integer.")
                        except ValueError:
                            display.print_warning("Enter a valid integer for CPU count.")
                    while True:
                        try:
                            ram_gb_input = float(typer.prompt("  RAM (GB)").strip())
                            if ram_gb_input > 0:
                                ram_mb = int(ram_gb_input * 1024)
                                break
                            display.print_warning("RAM must be a positive number.")
                        except ValueError:
                            display.print_warning("Enter a valid number for RAM.")
                    while True:
                        try:
                            disk_gb = int(typer.prompt("  Disk (GB)").strip())
                            if disk_gb > 0:
                                break
                            display.print_warning("Disk size must be a positive integer.")
                        except ValueError:
                            display.print_warning("Enter a valid integer for disk size.")
                return {"cpu": cpu, "ram_mb": ram_mb, "disk_gb": disk_gb}
            display.print_warning(f"Enter a number between 1 and {len(RESOURCE_PRESETS)}")
        else:
            display.print_warning(f"Enter a number between 1 and {len(RESOURCE_PRESETS)}")


def _phase2_secrets_mode(draft: dict) -> tuple[str, Optional[str]]:
    """Step 6: Secrets storage mode.

    Returns (secrets_mode, op_vault_name_or_None).
    """
    display.console.print("\n[bold]Step 6 of 7 — Secrets Storage[/bold]")
    display.console.print("How should API keys and tokens be stored?")
    display.console.print(
        "  [cyan]1[/cyan]. 1Password (recommended) — op:// references, zero secrets on disk"
    )
    display.console.print(
        "  [cyan]2[/cyan]. Environment variables — stored in container env file"
    )
    display.console.print(
        "  [cyan]3[/cyan]. Inline config (not recommended) — stored in config.yaml"
    )

    # Determine default based on op CLI availability
    op_available = shutil.which("op") is not None
    default_mode = "1" if op_available else "2"
    display.console.print(
        f"[dim]Default: {'1Password (op CLI detected)' if op_available else 'env vars (op CLI not found)'}[/dim]"
    )

    while True:
        raw = typer.prompt("Secrets mode", default=default_mode).strip()
        if raw in ("1", "2", "3"):
            mode_num = int(raw)
            break
        display.print_warning("Enter 1, 2, or 3.")

    if mode_num == 1:
        op_vault = typer.prompt("  1Password vault name", default="monolith").strip()
        return "op", op_vault or "monolith"
    elif mode_num == 3:
        display.console.print(
            "[bold yellow]⚠ Secrets will be stored in plaintext in config.yaml. "
            "Anyone with container access can read your API keys. "
            "Not recommended for production agents.[/bold yellow]"
        )
        return "inline", None
    else:
        return "env", None


def _run_phase2(container_id: str, draft: dict) -> dict:
    """Run Phase 2 config wizard, saving draft after each step."""
    display.console.print("\n[bold cyan]=== Phase 2 of 3 — Configure Agent ===[/bold cyan]")
    display.console.print(
        "[dim]We'll collect model, credential, gateway, and resource settings for this agent.[/dim]"
    )

    provider = draft.get("provider") or _phase2_provider()
    draft["provider"] = provider
    _save_draft(container_id, draft)

    model = draft.get("model") or _phase2_model(provider)
    draft["model"] = model
    _save_draft(container_id, draft)

    # API key is never stored in drafts — always prompt for it.
    # (draft files are metadata-only; secrets must be re-entered on resume.)
    raw_key = _phase2_api_key(provider)
    api_key = _phase2_op_reference(raw_key)
    # Keep api_key in the in-memory draft so Phase 3 can send it to the API,
    # but _save_draft will strip it before writing to disk.
    draft["api_key"] = api_key
    _save_draft(container_id, draft)

    personality = draft.get("personality") or _phase2_personality()
    draft["personality"] = personality
    _save_draft(container_id, draft)

    timezone = draft.get("timezone") or _phase2_timezone()
    draft["timezone"] = timezone
    _save_draft(container_id, draft)

    # Step 4: Gateways (always re-collect tokens on resume — secrets not saved to disk)
    gateway_fields = _phase2_gateways(draft)
    draft.update(gateway_fields)
    _save_draft(container_id, draft)

    # Step 5: Resources
    if "resources" not in draft:
        resources = _phase2_resources(draft)
        draft["resources"] = resources
        _save_draft(container_id, draft)

    # Step 6: Secrets mode
    if "secrets_mode" not in draft:
        secrets_mode, op_vault = _phase2_secrets_mode(draft)
        draft["secrets_mode"] = secrets_mode
        if op_vault:
            draft["op_vault"] = op_vault
        _save_draft(container_id, draft)

    return draft


# ---------------------------------------------------------------------------
# Phase 3 — Apply config
# ---------------------------------------------------------------------------


def _build_config_yaml_preview(draft: dict) -> str:
    """Generate YAML preview for display. All secret values are [REDACTED]."""
    provider = draft.get("provider", "openrouter")
    model = draft.get("model", "")
    agent_name = draft.get("agent_name", "")
    agent_role = draft.get("agent_role", "Agent")
    personality = draft.get("personality", "professional")
    timezone = draft.get("timezone", "America/New_York")
    base_url = PROVIDER_BASE_URLS.get(provider, "")
    resources = draft.get("resources", {})
    secrets_mode = draft.get("secrets_mode", "env")
    op_vault = draft.get("op_vault", "monolith")
    compute_provider = draft.get("compute_provider", "lxd")

    lines = [
        "# Generated by `monolith agent create --wizard`",
        "# Written to: /home/agent/.hermes/config.yaml",
        "",
        "_config_version: 8",
        "",
        f"compute_provider: {compute_provider}",
        "",
        "model:",
        f"  provider: {provider}",
        f"  default: {model}",
    ]
    if base_url:
        lines.append(f"  base_url: {base_url}")
    lines += [
        "",
        "agent:",
        f"  name: {agent_name}",
        f"  role: {agent_role}",
        f"  personality: {personality}",
        "",
        f"timezone: {timezone}",
    ]

    # Gateway sections (tokens always [REDACTED] in preview)
    if draft.get("telegram_token") is not None:
        tg_users = draft.get("telegram_allowed_users", "*")
        lines += [
            "",
            "telegram:",
            "  token: [REDACTED]",
            f"  allowed_users: {tg_users}",
        ]
    if draft.get("discord_token") is not None:
        dc_channel = draft.get("discord_channel", "")
        dc_mention = draft.get("discord_require_mention", True)
        lines += [
            "",
            "discord:",
            "  token: [REDACTED]",
            f"  channel: {dc_channel}",
            f"  require_mention: {'true' if dc_mention else 'false'}",
        ]
    if draft.get("slack_token") is not None:
        sl_thread = draft.get("slack_reply_in_thread", True)
        lines += [
            "",
            "slack:",
            "  token: [REDACTED]",
            f"  reply_in_thread: {'true' if sl_thread else 'false'}",
        ]

    # Resources section
    if resources:
        ram_gb = resources.get("ram_mb", 0) / 1024
        lines += [
            "",
            "resources:",
            f"  cpu: {resources.get('cpu', 2)}",
            f"  ram_mb: {resources.get('ram_mb', 4096)}  # {ram_gb:.0f} GB",
            f"  disk_gb: {resources.get('disk_gb', 40)}",
        ]

    # Secrets mode comment
    secrets_comments = {
        "op": f"# Secrets: 1Password (vault: {op_vault}) — op:// references used",
        "env": "# Secrets: environment variables — stored in container env file",
        "inline": "# Secrets: inline config — stored in this file (NOT recommended)",
    }
    lines += [
        "",
        secrets_comments.get(secrets_mode, ""),
        "",
        "# API key is stored in /etc/hermes/<container_id>.env.tpl — NOT in this file.",
    ]
    return "\n".join(lines) + "\n"


def _run_preflight_validation(draft: dict, container_id: Optional[str] = None) -> bool:
    """Call POST /api/wizard/validate. Returns True if valid, False if failed."""
    integrations, secrets, discord_channel = _build_gateway_payload(draft)

    payload: dict = {
        "model_provider": draft["provider"],
        "model": draft["model"],
        "api_key": draft.get("api_key", ""),
        "agent_name": draft.get("agent_name", ""),
        "integrations": integrations,
        "secrets": secrets,
    }
    if discord_channel:
        payload["discord_channel"] = discord_channel
    if container_id:
        payload["container_id"] = container_id

    try:
        resp = client.post("/wizard/validate", json=payload)
        checks = resp.get("checks", {})
        fields = resp.get("fields", {})
        valid = resp.get("valid", False)

        if not valid:
            # Show specific failures
            for field, result in fields.items():
                if result.get("status") == "error":
                    msg = result.get("message", "validation failed")
                    display.print_error(f"{field}: {msg}")
                    # P1-5: Discord channel hint
                    if field == "discord_channel" and "discord_channel_not_found" in msg:
                        display.console.print(
                            "  [dim]Could not find channel — try the channel ID instead "
                            "(right-click channel in Discord → Copy ID).[/dim]"
                        )
            if not checks.get("at_least_one_gateway"):
                display.print_error("At least one messaging gateway must be configured.")
        return valid
    except Exception as exc:
        display.print_warning(f"Pre-flight validation failed: {exc}. Proceeding anyway.")
        return True  # Don't block on validate endpoint unavailability


def _build_gateway_payload(draft: dict) -> tuple[list[str], list[dict], str | None]:
    """Build backend-compatible integrations/secrets payload fragments."""
    integrations: list[str] = []
    secrets: list[dict] = []
    discord_channel = draft.get("discord_channel")

    gateway_secret_slots = {
        "telegram": ("telegram_token", "TELEGRAM_BOT_TOKEN"),
        "discord": ("discord_token", "DISCORD_BOT_TOKEN"),
        "slack": ("slack_token", "SLACK_BOT_TOKEN"),
    }

    for integration, (draft_key, env_var) in gateway_secret_slots.items():
        token = draft.get(draft_key)
        if not token:
            continue
        integrations.append(integration)
        secret: dict[str, str] = {"env_var": env_var}
        if isinstance(token, str) and token.startswith("op://"):
            secret["op_ref"] = token
        else:
            secret["value"] = token
        secrets.append(secret)

    return integrations, secrets, discord_channel


def _build_hermes_config_payload(draft: dict) -> dict:
    """Build the JSON payload for POST /api/containers/{id}/hermes/config.

    API key (raw or op://) goes here — not in config.yaml.
    """
    provider = draft["provider"]
    op_ref = draft.get("api_key", "") if draft.get("api_key", "").startswith("op://") else None
    api_key = draft.get("api_key", "")
    integrations, secrets, discord_channel = _build_gateway_payload(draft)

    payload: dict = {
        "model_provider": provider,
        "model": draft["model"],
        "api_key": op_ref if op_ref else api_key,
        "timezone": draft.get("timezone", "America/New_York"),
        "personality": draft.get("personality", "professional"),
        "restart_after": True,
        "integrations": integrations,
        "secrets": secrets,
    }
    if discord_channel:
        payload["discord_channel"] = discord_channel

    return payload


def _apply_via_hermes_config_endpoint(container_id: str, payload: dict) -> None:
    """POST /api/containers/{id}/hermes/config.

    Raises APIError on failure. Response confirms config_path and restart_status.
    """
    resp = client.post(f"/containers/{container_id}/hermes/config", json=payload)
    config_path = resp.get("config_path", "/home/agent/.hermes/config.yaml")
    restart_status = resp.get("restart_status", "unknown")
    display.console.print(
        f"  [dim]Config written to {config_path} — restart: {restart_status}[/dim]"
    )


def _run_phase3(container_id: str, draft: dict, dry_run: bool = False) -> None:
    """Apply config via Isaac's endpoint, with rich progress indicators."""
    from rich.progress import Progress, SpinnerColumn, TextColumn

    display.console.print("\n[bold cyan]=== Phase 3 of 3 — Review & Apply ===[/bold cyan]")

    # --- Step 7: YAML Preview ---
    display.console.print("\n[bold]Step 7 of 7 — Review & Provision[/bold]")
    display.console.print(
        "[dim]Review the configuration below. All secret values are masked.[/dim]\n"
    )
    yaml_preview = _build_config_yaml_preview(draft)
    display.console.print(
        Panel(
            yaml_preview,
            title="[bold]config.yaml preview[/bold]",
            subtitle="[dim]Secrets shown as [REDACTED][/dim]",
            expand=False,
        )
    )

    payload = _build_hermes_config_payload(draft)

    if dry_run:
        display.console.print(
            "\n[bold yellow]Dry run — payload that would be sent to "
            f"POST /api/containers/{container_id}/hermes/config:[/bold yellow]"
        )
        # Redact all secret fields from dry-run output — never print secret values.
        redacted_payload = dict(payload)
        if redacted_payload.get("api_key"):
            redacted_payload["api_key"] = "<redacted>"
        if redacted_payload.get("secrets"):
            redacted_payload["secrets"] = [
                {
                    "env_var": secret["env_var"],
                    **(
                        {"op_ref": secret["op_ref"]}
                        if secret.get("op_ref")
                        else {"value": "<redacted>"}
                    ),
                }
                for secret in redacted_payload["secrets"]
            ]
        display.console.print_json(json.dumps(redacted_payload, indent=2))
        display.console.print("[dim]Dry run complete — no changes made.[/dim]")
        return

    # Confirm before proceeding
    confirmed = typer.confirm("\nProceed with provisioning?", default=True)
    if not confirmed:
        display.console.print("[dim]Aborted by user.[/dim]")
        raise typer.Exit(0)

    # --- Pre-flight validation ---
    display.console.print("\n[dim]Running pre-flight validation...[/dim]")
    valid = _run_preflight_validation(draft, container_id=container_id)
    if not valid:
        display.console.print(
            f"\n[bold red]Pre-flight validation failed.[/bold red]\n"
            f"Container ID: [cyan]{container_id}[/cyan]\n"
            f"Resume with: [bold]monolith agent create --wizard --resume {container_id}[/bold]"
        )
        raise typer.Exit(1)

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold green]{task.description}"),
        transient=True,
        console=display.console,
    ) as progress:
        task = progress.add_task("Configuring agent...", total=None)
        try:
            _apply_config_step(container_id, payload, progress, task)
        except APIError as e:
            # P0-3: Surface container ID prominently on failure
            display.console.print(
                f"\n[bold red]Configuration failed.[/bold red]\n"
                f"Container ID: [cyan]{container_id}[/cyan]\n"
                f"Resume with: [bold]monolith agent create --wizard --resume {container_id}[/bold]"
            )
            _handle_config_api_error(e, draft.get("model", ""))
            raise typer.Exit(1)


def _apply_config_step(
    container_id: str,
    payload: dict,
    progress=None,  # type: ignore[type-arg]
    task=None,
) -> None:
    """Inner step: call the endpoint and update progress label."""
    if progress and task is not None:
        progress.update(task, description="Configuring agent...")
    _apply_via_hermes_config_endpoint(container_id, payload)
    if progress and task is not None:
        progress.update(task, description="Starting agent...")
    display.print_success("Config applied.")


def _handle_config_api_error(e: "APIError", model: str) -> None:
    """Convert API errors into specific, actionable messages."""
    if e.status == 422:
        display.print_error(
            f"Failed to apply config: invalid model '{model}'. "
            "Run `monolith model-providers` to see available models."
        )
    elif e.status == 404:
        display.print_error(
            "Configuration service unavailable. Contact your Monolith administrator."
        )
    elif e.status == 401:
        display.print_error(
            "Authentication failed (401). Check MONOLITH_API_KEY / RAAVA_API_KEY or run "
            "`monolith config set api_key <key>`."
        )
    elif e.status == 403:
        display.print_error(
            f"Permission denied (403). You may not have access to container {e}."
        )
    else:
        display.print_error(f"Failed to apply config: HTTP {e.status} — {e}")


# ---------------------------------------------------------------------------
# Summary card
# ---------------------------------------------------------------------------


def _print_summary_card(container_id: str, draft: dict) -> None:
    """Render a Rich Panel with key agent details."""
    # Compute provider: show human-readable label (e.g. "Bare Metal") from internal value.
    _compute_label_map = {val: label for label, val in COMPUTE_PROVIDER_CHOICES}
    compute_provider_val = draft.get("compute_provider", "lxd")
    compute_provider_display = _compute_label_map.get(compute_provider_val, compute_provider_val)

    provider = draft.get("provider", "—")
    model = draft.get("model", "—")
    timezone = draft.get("timezone", "—")
    personality = draft.get("personality", "—")
    api_key_val = draft.get("api_key", "")
    api_key_display = api_key_val if api_key_val.startswith("op://") else "<provided>"

    # Build list of configured gateways
    configured_gateways = []
    if draft.get("telegram_token") is not None:
        configured_gateways.append("Telegram")
    if draft.get("discord_token") is not None:
        configured_gateways.append("Discord")
    if draft.get("slack_token") is not None:
        configured_gateways.append("Slack")
    gateways_display = ", ".join(configured_gateways) if configured_gateways else "—"

    resources = draft.get("resources", {})
    if resources:
        ram_gb = resources.get("ram_mb", 0) / 1024
        resources_display = (
            f"{resources.get('cpu')} CPU, {ram_gb:.0f} GB RAM, "
            f"{resources.get('disk_gb')} GB disk"
        )
    else:
        resources_display = "—"

    secrets_mode = draft.get("secrets_mode", "env")
    secrets_display = {"op": "1Password (op://)", "env": "env vars", "inline": "inline (plaintext)"}.get(
        secrets_mode, secrets_mode
    )

    t = Table.grid(padding=(0, 2))
    t.add_column(style="bold dim", justify="right")
    t.add_column()
    t.add_row("Container", f"[cyan]{container_id}[/cyan]")
    t.add_row("Runs on", f"[cyan]{compute_provider_display}[/cyan]")
    t.add_row("Provider", f"[cyan]{provider}[/cyan]")
    t.add_row("Model", f"[cyan]{model}[/cyan]")
    t.add_row("API Key", f"[cyan]{api_key_display}[/cyan]")
    t.add_row("Timezone", f"[cyan]{timezone}[/cyan]")
    t.add_row("Personality", f"[cyan]{personality}[/cyan]")
    t.add_row("Gateways", f"[cyan]{gateways_display}[/cyan]")
    t.add_row("Resources", f"[cyan]{resources_display}[/cyan]")
    t.add_row("Secrets", f"[cyan]{secrets_display}[/cyan]")
    t.add_row("Config path", "[cyan]/home/agent/.hermes/config.yaml[/cyan]")
    t.add_row("Status", "[bold green]live ✓[/bold green]")

    display.console.print(
        Panel(t, title="[bold green]Agent Ready[/bold green]", expand=False)
    )
    # P0-1: Container ID + dashboard + gateways + reconfigure line
    display.console.print(
        f"[bold green]✓ Agent live — Container ID: {container_id}[/bold green]"
    )
    display.console.print(
        f"  Dashboard: [link]http://localhost:3100/agents/{container_id}[/link]"
    )
    display.console.print(f"  Gateway: {gateways_display}")
    display.console.print(
        f"[dim]To reconfigure: [bold]monolith agent init {container_id}[/bold][/dim]"
    )


# ---------------------------------------------------------------------------
# Main wizard command
# ---------------------------------------------------------------------------


@app.command()
def create(
    wizard: bool = typer.Option(
        False,
        "--wizard",
        is_flag=True,
        help="Run the interactive setup wizard (provision + configure + launch)",
    ),
    resume: Optional[str] = typer.Option(
        None,
        "--resume",
        help="Resume an interrupted wizard from a draft (pass container ID)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        is_flag=True,
        help="Show exactly what would be sent — does not call any APIs",
    ),
):
    """Create a new agent.

    With [bold]--wizard[/bold], runs a guided three-phase flow:
      Phase 1 — Provision a new container via the API
      Phase 2 — Configure model provider, API key, and integrations
      Phase 3 — Apply config and bring the agent online

    [dim]Use `monolith agent init <container_id>` to reconfigure an existing agent.[/dim]
    """
    if not wizard and resume is None:
        display.console.print(
            "[dim]Run with [bold]--wizard[/bold] for the guided setup flow, "
            "or [bold]--resume <container_id>[/bold] to continue an interrupted wizard.[/dim]"
        )
        raise typer.Exit(0)

    if resume:
        draft = _load_draft(resume)
        if not draft:
            display.print_error(
                f"No draft found for container '{resume}'. "
                f"Check {DRAFTS_DIR} or start a fresh wizard."
            )
            raise typer.Exit(1)
        container_id = resume
        display.console.print(
            f"\n[bold green]Resuming wizard for {container_id}[/bold green] from saved draft."
        )
        phase = draft.get("_phase", 2)
        try:
            if phase <= 2:
                draft = _run_phase2(container_id, draft)
            _run_phase3(container_id, draft, dry_run=dry_run)
            _delete_draft(container_id)
            _print_summary_card(container_id, draft)
        except KeyboardInterrupt:
            _on_interrupt(container_id, phase1_complete=True)
        return

    # --- Full wizard flow ---
    display.console.print(
        "\n[bold green]Monolith Agent Create Wizard[/bold green]"
    )
    display.console.print(
        "[dim]This wizard provisions a new agent, configures it, and brings it online.\n"
        "Press Ctrl+C at any time to abort. Progress is saved — use [bold]--resume[/bold] to continue.[/dim]"
    )

    container_id = "__pending__"
    phase1_complete = False
    try:
        # Phase 1: Collect params and provision
        provision_params = _phase1_collect()

        if dry_run:
            # Normalize to the same payload shape the backend receives.
            dry_run_payload = {k: v for k, v in provision_params.items() if k != "compute_provider"}
            dry_run_payload["provider"] = provision_params.get("compute_provider", "lxd")
            display.console.print(
                "\n[bold yellow]Dry run — Phase 1 payload (provision):[/bold yellow]"
            )
            display.console.print_json(json.dumps(dry_run_payload, indent=2))
            # For dry-run we still need to collect Phase 2 to show the full picture
            draft: dict = {"_phase": 2, "container_id": "dry-run", **provision_params}
            draft = _run_phase2("dry-run", draft)
            _run_phase3("dry-run", draft, dry_run=True)
            return

        container_id = _phase1_provision(provision_params)
        phase1_complete = True

        draft = {
            "_phase": 2,
            "container_id": container_id,
            **provision_params,
        }
        _save_draft(container_id, draft)

        # Phase 2: Config wizard
        draft = _run_phase2(container_id, draft)
        draft["_phase"] = 3
        _save_draft(container_id, draft)

        # Phase 3: Apply
        _run_phase3(container_id, draft, dry_run=False)

        _delete_draft(container_id)
        _print_summary_card(container_id, draft)

    except KeyboardInterrupt:
        _on_interrupt(
            container_id if container_id != "__pending__" else None,
            phase1_complete=phase1_complete,
        )
        raise typer.Exit(1)


def _on_interrupt(container_id: Optional[str], phase1_complete: bool = False) -> None:
    """Handle Ctrl+C: save draft and print resume instructions.

    P0-2: Tell the operator whether a container was created, the container ID
    if known, and the exact resume command.
    """
    display.console.print("\n\n[bold yellow]Wizard interrupted.[/bold yellow]")
    if container_id and phase1_complete:
        display.console.print(
            f"  A container [cyan]{container_id}[/cyan] was created and is running."
        )
        display.console.print("  Progress has been saved to a draft.")
        display.console.print(
            f"  Resume with: [bold]monolith agent create --wizard --resume {container_id}[/bold]"
        )
    elif container_id:
        # container_id known but phase1 may not have been flagged as complete
        display.console.print(
            f"  Container ID: [cyan]{container_id}[/cyan]"
        )
        display.console.print("  Progress has been saved.")
        display.console.print(
            f"  Resume with: [bold]monolith agent create --wizard --resume {container_id}[/bold]"
        )
    else:
        display.console.print(
            "  No container was created. "
            "Run [bold]monolith agent create --wizard[/bold] to start over."
        )
