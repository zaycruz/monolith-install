"""Configuration management for the Monolith CLI."""

import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "monolith"
CONFIG_FILE = CONFIG_DIR / "config.toml"

VALID_KEYS = {"api_url", "timeout", "output", "api_key"}
DEFAULT_API_URL = "http://127.0.0.1:8400"

_defaults = {
    "api_url": DEFAULT_API_URL,
    "timeout": 30,
    "output": "table",
    "api_key": "",
}


def load_toml(path: Path, default_data: dict | None = None) -> dict:
    if not path.exists():
        return dict(default_data) if default_data else {}
    try:
        import tomllib
        with open(path, "rb") as f:
            data = tomllib.load(f)
        if default_data:
            merged = dict(default_data)
            merged.update(data)
            return merged
        return dict(data) if isinstance(data, dict) else {}
    except Exception:
        return dict(default_data) if default_data else {}


def save_toml(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.parent.chmod(0o700)
    except OSError:
        pass
    lines = []
    for k, v in data.items():
        if isinstance(v, bool):
            lines.append(f"{k} = {'true' if v else 'false'}")
        elif isinstance(v, int):
            lines.append(f"{k} = {v}")
        elif isinstance(v, float):
            lines.append(f"{k} = {v}")
        elif isinstance(v, str):
            escaped = v.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{k} = "{escaped}"')
        else:
            lines.append(f'{k} = "{v}"')
    path.write_text("\n".join(lines) + "\n")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def _load_config() -> dict:
    return load_toml(CONFIG_FILE, _defaults)


def _save_config(data: dict):
    save_toml(CONFIG_FILE, data)


_config = _load_config()


def get(key: str, default=None):
    env_key = f"RAAVA_{key.upper()}"
    env_val = os.environ.get(env_key)
    if env_val is not None:
        return env_val
    return _config.get(key, default)


def set_value(key: str, value: str):
    # Type coercion
    if value.lower() in ("true", "false"):
        value = value.lower() == "true"
    else:
        try:
            value = int(value)
        except ValueError:
            try:
                value = float(value)
            except ValueError:
                pass
    _config[key] = value
    _save_config(_config)


def delete_key(key: str) -> bool:
    if key in _config and key not in _defaults:
        del _config[key]
        _save_config(_config)
        return True
    elif key in _config:
        _config[key] = _defaults[key]
        _save_config(_config)
        return True
    return False


def all_config() -> dict:
    return dict(_config)
