"""Rich display helpers for the Monolith CLI."""

from __future__ import annotations

import json

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()
err_console = Console(stderr=True)

_json_mode = False

_STATUS_KEYS = {"status", "agent_status", "health_status"}


def set_json_mode(enabled: bool):
    global _json_mode
    _json_mode = enabled


def is_json_mode() -> bool:
    return _json_mode


def print_json(data: dict | list | str | int | float | bool | None):
    console.print_json(json.dumps(data, default=str))


def print_error(msg: str):
    err_console.print(f"[bold red]Error:[/] {msg}")


def print_success(msg: str):
    console.print(f"[bold green]{msg}[/]")


def print_warning(msg: str):
    err_console.print(f"[bold yellow]Warning:[/] {msg}")


def format_bytes(n: int | float, precision: int = 0) -> str:
    """Format bytes to human-readable size."""
    if n < 1024:
        return f"{n}B"
    if n < 1048576:
        return f"{n // 1024}KB"
    if n < 1073741824:
        return f"{n // 1048576}MB"
    return f"{n / 1073741824:.{precision}f}GB"


def clamp_percent(value: str | int | float) -> float:
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0.0
    if v < 0:
        return 0.0
    if v > 100:
        return 100.0
    return v


def percent_bar(value: str | int | float, width: int = 14, color: str = "cyan") -> Text:
    """Return compact sparkline-style percent + bar text."""
    pct = clamp_percent(value)
    filled = int(round((pct / 100.0) * width))
    filled = max(0, min(width, filled))

    out = Text(f"{pct:5.1f}% ", style="bold")
    if filled:
        out.append("█" * filled, style=color)
    if width - filled:
        out.append("░" * (width - filled), style="dim")
    return out


def enrich_health(row: dict, precision: int = 0) -> None:
    """Add _cpu, _mem, _disk formatted fields from nested health dict."""
    health = row.get("health") or {}
    fmt = f".{precision}f"
    row["_cpu"] = format(health.get("cpu", 0), fmt) if health else "—"
    row["_mem"] = format(health.get("mem", 0), fmt) if health else "—"
    row["_disk"] = format(health.get("disk", 0), fmt) if health else "—"


def status_style(s: str) -> str:
    s = (s or "unknown").lower()
    colors = {
        "running": "green",
        "active": "green",
        "idle": "yellow",
        "stopped": "red",
        "deleted": "dim red",
        "error": "bold red",
        "failed": "bold red",
        "complete": "green",
        "cancelled": "dim yellow",
        "interrupted": "dim yellow",
        "offboarded": "dim red",
    }
    color = colors.get(s, "white")
    return f"[{color}]{s}[/{color}]"


def table(
    data: list[dict],
    columns: list[tuple[str, str]],
    title: str | None = None,
    row_styles: list[str] | None = None,
):
    """Render a Rich table. columns = [(header, dict_key), ...]"""
    if _json_mode:
        print_json(data)
        return

    if not data:
        target = f" for {title}" if title else ""
        console.print(f"[dim]No results{target}[/dim]")
        return

    t = Table(title=title, show_lines=False, pad_edge=True, padding=(0, 1), row_styles=row_styles or [])
    for header, _ in columns:
        t.add_column(header)

    for row in data:
        cells: list[str] = []
        for _, key in columns:
            val = row.get(key, "")
            if key in _STATUS_KEYS:
                cells.append(status_style(str(val)))
            elif val is None:
                cells.append("")
            elif isinstance(val, (str, int, float, bool)):
                cells.append(str(val))
            else:
                cells.append(str(val))
        t.add_row(*cells)

    console.print(t)


def detail(data: dict, title: str | None = None):
    """Render a key-value detail panel."""
    if _json_mode:
        print_json(data)
        return

    lines = []
    for k, v in data.items():
        if k in _STATUS_KEYS:
            v_str = status_style(str(v))
        else:
            v_str = str(v) if v is not None else "[dim]—[/dim]"
        lines.append(f"[bold]{k}:[/] {v_str}")

    console.print(Panel("\n".join(lines), title=title or None, expand=False))
